import"./_virtual_wxt-html-plugins-DPbbfBKe.js";import{a as lt,r as l,j as d,b as _i,c as qs,d as Js}from"./client-BtFrb4Ya.js";import{b as j,c as Pn,M as dr,O as hr,a as fr}from"./browser-BWGAiTJm.js";const pr=t=>{let e;const n=new Set,r=(u,h)=>{const p=typeof u=="function"?u(e):u;if(!Object.is(p,e)){const f=e;e=h??(typeof p!="object"||p===null)?p:Object.assign({},e,p),n.forEach(m=>m(e,f))}},i=()=>e,a={setState:r,getState:i,getInitialState:()=>c,subscribe:u=>(n.add(u),()=>n.delete(u))},c=e=t(r,i,a);return a},Xs=t=>t?pr(t):pr,Qs=t=>t;function eo(t,e=Qs){const n=lt.useSyncExternalStore(t.subscribe,()=>e(t.getState()),()=>e(t.getInitialState()));return lt.useDebugValue(n),n}const mr=t=>{const e=Xs(t),n=r=>eo(e,r);return Object.assign(n,e),n},Xt=t=>t?mr(t):mr;/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const to=()=>{};var gr={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wi=function(t){const e=[];let n=0;for(let r=0;r<t.length;r++){let i=t.charCodeAt(r);i<128?e[n++]=i:i<2048?(e[n++]=i>>6|192,e[n++]=i&63|128):(i&64512)===55296&&r+1<t.length&&(t.charCodeAt(r+1)&64512)===56320?(i=65536+((i&1023)<<10)+(t.charCodeAt(++r)&1023),e[n++]=i>>18|240,e[n++]=i>>12&63|128,e[n++]=i>>6&63|128,e[n++]=i&63|128):(e[n++]=i>>12|224,e[n++]=i>>6&63|128,e[n++]=i&63|128)}return e},no=function(t){const e=[];let n=0,r=0;for(;n<t.length;){const i=t[n++];if(i<128)e[r++]=String.fromCharCode(i);else if(i>191&&i<224){const s=t[n++];e[r++]=String.fromCharCode((i&31)<<6|s&63)}else if(i>239&&i<365){const s=t[n++],o=t[n++],a=t[n++],c=((i&7)<<18|(s&63)<<12|(o&63)<<6|a&63)-65536;e[r++]=String.fromCharCode(55296+(c>>10)),e[r++]=String.fromCharCode(56320+(c&1023))}else{const s=t[n++],o=t[n++];e[r++]=String.fromCharCode((i&15)<<12|(s&63)<<6|o&63)}}return e.join("")},Ei={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(t,e){if(!Array.isArray(t))throw Error("encodeByteArray takes an array as a parameter");this.init_();const n=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let i=0;i<t.length;i+=3){const s=t[i],o=i+1<t.length,a=o?t[i+1]:0,c=i+2<t.length,u=c?t[i+2]:0,h=s>>2,p=(s&3)<<4|a>>4;let f=(a&15)<<2|u>>6,m=u&63;c||(m=64,o||(f=64)),r.push(n[h],n[p],n[f],n[m])}return r.join("")},encodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(t):this.encodeByteArray(wi(t),e)},decodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(t):no(this.decodeStringToByteArray(t,e))},decodeStringToByteArray(t,e){this.init_();const n=e?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let i=0;i<t.length;){const s=n[t.charAt(i++)],a=i<t.length?n[t.charAt(i)]:0;++i;const u=i<t.length?n[t.charAt(i)]:64;++i;const p=i<t.length?n[t.charAt(i)]:64;if(++i,s==null||a==null||u==null||p==null)throw new ro;const f=s<<2|a>>4;if(r.push(f),u!==64){const m=a<<4&240|u>>2;if(r.push(m),p!==64){const _=u<<6&192|p;r.push(_)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let t=0;t<this.ENCODED_VALS.length;t++)this.byteToCharMap_[t]=this.ENCODED_VALS.charAt(t),this.charToByteMap_[this.byteToCharMap_[t]]=t,this.byteToCharMapWebSafe_[t]=this.ENCODED_VALS_WEBSAFE.charAt(t),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[t]]=t,t>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(t)]=t,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(t)]=t)}}};class ro extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const io=function(t){const e=wi(t);return Ei.encodeByteArray(e,!0)},bi=function(t){return io(t).replace(/\./g,"")},Yn=function(t){try{return Ei.decodeString(t,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function so(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oo=()=>so().__FIREBASE_DEFAULTS__,ao=()=>{if(typeof process>"u"||typeof gr>"u")return;const t=gr.__FIREBASE_DEFAULTS__;if(t)return JSON.parse(t)},co=()=>{if(typeof document>"u")return;let t;try{t=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=t&&Yn(t[1]);return e&&JSON.parse(e)},qn=()=>{try{return to()||oo()||ao()||co()}catch(t){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${t}`);return}},lo=t=>{var e,n;return(n=(e=qn())===null||e===void 0?void 0:e.emulatorHosts)===null||n===void 0?void 0:n[t]},Ii=()=>{var t;return(t=qn())===null||t===void 0?void 0:t.config},uo=t=>{var e;return(e=qn())===null||e===void 0?void 0:e[`_${t}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ho{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,n)=>{this.resolve=e,this.reject=n})}wrapCallback(e){return(n,r)=>{n?this.reject(n):this.resolve(r),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(n):e(n,r))}}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ge(t){try{return(t.startsWith("http://")||t.startsWith("https://")?new URL(t).hostname:t).endsWith(".cloudworkstations.dev")}catch{return!1}}async function fo(t){return(await fetch(t,{credentials:"include"})).ok}const st={};function po(){const t={prod:[],emulator:[]};for(const e of Object.keys(st))st[e]?t.emulator.push(e):t.prod.push(e);return t}function mo(t){let e=document.getElementById(t),n=!1;return e||(e=document.createElement("div"),e.setAttribute("id",t),n=!0),{created:n,element:e}}let vr=!1;function go(t,e){if(typeof window>"u"||typeof document>"u"||!Ge(window.location.host)||st[t]===e||st[t]||vr)return;st[t]=e;function n(f){return`__firebase__banner__${f}`}const r="__firebase__banner",s=po().prod.length>0;function o(){const f=document.getElementById(r);f&&f.remove()}function a(f){f.style.display="flex",f.style.background="#7faaf0",f.style.position="fixed",f.style.bottom="5px",f.style.left="5px",f.style.padding=".5em",f.style.borderRadius="5px",f.style.alignItems="center"}function c(f,m){f.setAttribute("width","24"),f.setAttribute("id",m),f.setAttribute("height","24"),f.setAttribute("viewBox","0 0 24 24"),f.setAttribute("fill","none"),f.style.marginLeft="-6px"}function u(){const f=document.createElement("span");return f.style.cursor="pointer",f.style.marginLeft="16px",f.style.fontSize="24px",f.innerHTML=" &times;",f.onclick=()=>{vr=!0,o()},f}function h(f,m){f.setAttribute("id",m),f.innerText="Learn more",f.href="https://firebase.google.com/docs/studio/preview-apps#preview-backend",f.setAttribute("target","__blank"),f.style.paddingLeft="5px",f.style.textDecoration="underline"}function p(){const f=mo(r),m=n("text"),_=document.getElementById(m)||document.createElement("span"),g=n("learnmore"),y=document.getElementById(g)||document.createElement("a"),w=n("preprendIcon"),E=document.getElementById(w)||document.createElementNS("http://www.w3.org/2000/svg","svg");if(f.created){const v=f.element;a(v),h(y,g);const A=u();c(E,w),v.append(E,_,y,A),document.body.appendChild(v)}s?(_.innerText="Preview backend disconnected.",E.innerHTML=`<g clip-path="url(#clip0_6013_33858)">
<path d="M4.8 17.6L12 5.6L19.2 17.6H4.8ZM6.91667 16.4H17.0833L12 7.93333L6.91667 16.4ZM12 15.6C12.1667 15.6 12.3056 15.5444 12.4167 15.4333C12.5389 15.3111 12.6 15.1667 12.6 15C12.6 14.8333 12.5389 14.6944 12.4167 14.5833C12.3056 14.4611 12.1667 14.4 12 14.4C11.8333 14.4 11.6889 14.4611 11.5667 14.5833C11.4556 14.6944 11.4 14.8333 11.4 15C11.4 15.1667 11.4556 15.3111 11.5667 15.4333C11.6889 15.5444 11.8333 15.6 12 15.6ZM11.4 13.6H12.6V10.4H11.4V13.6Z" fill="#212121"/>
</g>
<defs>
<clipPath id="clip0_6013_33858">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>`):(E.innerHTML=`<g clip-path="url(#clip0_6083_34804)">
<path d="M11.4 15.2H12.6V11.2H11.4V15.2ZM12 10C12.1667 10 12.3056 9.94444 12.4167 9.83333C12.5389 9.71111 12.6 9.56667 12.6 9.4C12.6 9.23333 12.5389 9.09444 12.4167 8.98333C12.3056 8.86111 12.1667 8.8 12 8.8C11.8333 8.8 11.6889 8.86111 11.5667 8.98333C11.4556 9.09444 11.4 9.23333 11.4 9.4C11.4 9.56667 11.4556 9.71111 11.5667 9.83333C11.6889 9.94444 11.8333 10 12 10ZM12 18.4C11.1222 18.4 10.2944 18.2333 9.51667 17.9C8.73889 17.5667 8.05556 17.1111 7.46667 16.5333C6.88889 15.9444 6.43333 15.2611 6.1 14.4833C5.76667 13.7056 5.6 12.8778 5.6 12C5.6 11.1111 5.76667 10.2833 6.1 9.51667C6.43333 8.73889 6.88889 8.06111 7.46667 7.48333C8.05556 6.89444 8.73889 6.43333 9.51667 6.1C10.2944 5.76667 11.1222 5.6 12 5.6C12.8889 5.6 13.7167 5.76667 14.4833 6.1C15.2611 6.43333 15.9389 6.89444 16.5167 7.48333C17.1056 8.06111 17.5667 8.73889 17.9 9.51667C18.2333 10.2833 18.4 11.1111 18.4 12C18.4 12.8778 18.2333 13.7056 17.9 14.4833C17.5667 15.2611 17.1056 15.9444 16.5167 16.5333C15.9389 17.1111 15.2611 17.5667 14.4833 17.9C13.7167 18.2333 12.8889 18.4 12 18.4ZM12 17.2C13.4444 17.2 14.6722 16.6944 15.6833 15.6833C16.6944 14.6722 17.2 13.4444 17.2 12C17.2 10.5556 16.6944 9.32778 15.6833 8.31667C14.6722 7.30555 13.4444 6.8 12 6.8C10.5556 6.8 9.32778 7.30555 8.31667 8.31667C7.30556 9.32778 6.8 10.5556 6.8 12C6.8 13.4444 7.30556 14.6722 8.31667 15.6833C9.32778 16.6944 10.5556 17.2 12 17.2Z" fill="#212121"/>
</g>
<defs>
<clipPath id="clip0_6083_34804">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>`,_.innerText="Preview backend running in this workspace."),_.setAttribute("id",m)}document.readyState==="loading"?window.addEventListener("DOMContentLoaded",p):p()}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function G(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function Ai(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(G())}function Ti(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function Si(){const t=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof t=="object"&&t.id!==void 0}function Ci(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function vo(){try{return typeof indexedDB=="object"}catch{return!1}}function yo(){return new Promise((t,e)=>{try{let n=!0;const r="validate-browser-context-for-indexeddb-analytics-module",i=self.indexedDB.open(r);i.onsuccess=()=>{i.result.close(),n||self.indexedDB.deleteDatabase(r),t(!0)},i.onupgradeneeded=()=>{n=!1},i.onerror=()=>{var s;e(((s=i.error)===null||s===void 0?void 0:s.message)||"")}}catch(n){e(n)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _o="FirebaseError";class se extends Error{constructor(e,n,r){super(n),this.code=e,this.customData=r,this.name=_o,Object.setPrototypeOf(this,se.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Ae.prototype.create)}}class Ae{constructor(e,n,r){this.service=e,this.serviceName=n,this.errors=r}create(e,...n){const r=n[0]||{},i=`${this.service}/${e}`,s=this.errors[e],o=s?wo(s,r):"Error",a=`${this.serviceName}: ${o} (${i}).`;return new se(i,a,r)}}function wo(t,e){return t.replace(Eo,(n,r)=>{const i=e[r];return i!=null?String(i):`<${r}?>`})}const Eo=/\{\$([^}]+)}/g;function Ze(t,e){if(t===e)return!0;const n=Object.keys(t),r=Object.keys(e);for(const i of n){if(!r.includes(i))return!1;const s=t[i],o=e[i];if(yr(s)&&yr(o)){if(!Ze(s,o))return!1}else if(s!==o)return!1}for(const i of r)if(!n.includes(i))return!1;return!0}function yr(t){return t!==null&&typeof t=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gt(t){const e=[];for(const[n,r]of Object.entries(t))Array.isArray(r)?r.forEach(i=>{e.push(encodeURIComponent(n)+"="+encodeURIComponent(i))}):e.push(encodeURIComponent(n)+"="+encodeURIComponent(r));return e.length?"&"+e.join("&"):""}function nt(t){const e={};return t.replace(/^\?/,"").split("&").forEach(r=>{if(r){const[i,s]=r.split("=");e[decodeURIComponent(i)]=decodeURIComponent(s)}}),e}function rt(t){const e=t.indexOf("?");if(!e)return"";const n=t.indexOf("#",e);return t.substring(e,n>0?n:void 0)}function Ri(t,e){const n=new bo(t,e);return n.subscribe.bind(n)}class bo{constructor(e,n){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=n,this.task.then(()=>{e(this)}).catch(r=>{this.error(r)})}next(e){this.forEachObserver(n=>{n.next(e)})}error(e){this.forEachObserver(n=>{n.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,n,r){let i;if(e===void 0&&n===void 0&&r===void 0)throw new Error("Missing Observer.");Io(e,["next","error","complete"])?i=e:i={next:e,error:n,complete:r},i.next===void 0&&(i.next=cn),i.error===void 0&&(i.error=cn),i.complete===void 0&&(i.complete=cn);const s=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?i.error(this.finalError):i.complete()}catch{}}),this.observers.push(i),s}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let n=0;n<this.observers.length;n++)this.sendOne(n,e)}sendOne(e,n){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{n(this.observers[e])}catch(r){typeof console<"u"&&console.error&&console.error(r)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function Io(t,e){if(typeof t!="object"||t===null)return!1;for(const n of e)if(n in t&&typeof t[n]=="function")return!0;return!1}function cn(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Y(t){return t&&t._delegate?t._delegate:t}class Ie{constructor(e,n,r){this.name=e,this.instanceFactory=n,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ce="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ao{constructor(e,n){this.name=e,this.container=n,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const n=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(n)){const r=new ho;if(this.instancesDeferred.set(n,r),this.isInitialized(n)||this.shouldAutoInitialize())try{const i=this.getOrInitializeService({instanceIdentifier:n});i&&r.resolve(i)}catch{}}return this.instancesDeferred.get(n).promise}getImmediate(e){var n;const r=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),i=(n=e==null?void 0:e.optional)!==null&&n!==void 0?n:!1;if(this.isInitialized(r)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:r})}catch(s){if(i)return null;throw s}else{if(i)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(So(e))try{this.getOrInitializeService({instanceIdentifier:Ce})}catch{}for(const[n,r]of this.instancesDeferred.entries()){const i=this.normalizeInstanceIdentifier(n);try{const s=this.getOrInitializeService({instanceIdentifier:i});r.resolve(s)}catch{}}}}clearInstance(e=Ce){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(n=>"INTERNAL"in n).map(n=>n.INTERNAL.delete()),...e.filter(n=>"_delete"in n).map(n=>n._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=Ce){return this.instances.has(e)}getOptions(e=Ce){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:n={}}=e,r=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const i=this.getOrInitializeService({instanceIdentifier:r,options:n});for(const[s,o]of this.instancesDeferred.entries()){const a=this.normalizeInstanceIdentifier(s);r===a&&o.resolve(i)}return i}onInit(e,n){var r;const i=this.normalizeInstanceIdentifier(n),s=(r=this.onInitCallbacks.get(i))!==null&&r!==void 0?r:new Set;s.add(e),this.onInitCallbacks.set(i,s);const o=this.instances.get(i);return o&&e(o,i),()=>{s.delete(e)}}invokeOnInitCallbacks(e,n){const r=this.onInitCallbacks.get(n);if(r)for(const i of r)try{i(e,n)}catch{}}getOrInitializeService({instanceIdentifier:e,options:n={}}){let r=this.instances.get(e);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:To(e),options:n}),this.instances.set(e,r),this.instancesOptions.set(e,n),this.invokeOnInitCallbacks(r,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,r)}catch{}return r||null}normalizeInstanceIdentifier(e=Ce){return this.component?this.component.multipleInstances?e:Ce:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function To(t){return t===Ce?void 0:t}function So(t){return t.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Co{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const n=this.getProvider(e.name);if(n.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);n.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const n=new Ao(e,this);return this.providers.set(e,n),n}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var U;(function(t){t[t.DEBUG=0]="DEBUG",t[t.VERBOSE=1]="VERBOSE",t[t.INFO=2]="INFO",t[t.WARN=3]="WARN",t[t.ERROR=4]="ERROR",t[t.SILENT=5]="SILENT"})(U||(U={}));const Ro={debug:U.DEBUG,verbose:U.VERBOSE,info:U.INFO,warn:U.WARN,error:U.ERROR,silent:U.SILENT},ko=U.INFO,Po={[U.DEBUG]:"log",[U.VERBOSE]:"log",[U.INFO]:"info",[U.WARN]:"warn",[U.ERROR]:"error"},No=(t,e,...n)=>{if(e<t.logLevel)return;const r=new Date().toISOString(),i=Po[e];if(i)console[i](`[${r}]  ${t.name}:`,...n);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Jn{constructor(e){this.name=e,this._logLevel=ko,this._logHandler=No,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in U))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?Ro[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,U.DEBUG,...e),this._logHandler(this,U.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,U.VERBOSE,...e),this._logHandler(this,U.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,U.INFO,...e),this._logHandler(this,U.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,U.WARN,...e),this._logHandler(this,U.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,U.ERROR,...e),this._logHandler(this,U.ERROR,...e)}}const Lo=(t,e)=>e.some(n=>t instanceof n);let _r,wr;function xo(){return _r||(_r=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Oo(){return wr||(wr=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const ki=new WeakMap,Nn=new WeakMap,Pi=new WeakMap,ln=new WeakMap,Xn=new WeakMap;function Mo(t){const e=new Promise((n,r)=>{const i=()=>{t.removeEventListener("success",s),t.removeEventListener("error",o)},s=()=>{n(we(t.result)),i()},o=()=>{r(t.error),i()};t.addEventListener("success",s),t.addEventListener("error",o)});return e.then(n=>{n instanceof IDBCursor&&ki.set(n,t)}).catch(()=>{}),Xn.set(e,t),e}function Do(t){if(Nn.has(t))return;const e=new Promise((n,r)=>{const i=()=>{t.removeEventListener("complete",s),t.removeEventListener("error",o),t.removeEventListener("abort",o)},s=()=>{n(),i()},o=()=>{r(t.error||new DOMException("AbortError","AbortError")),i()};t.addEventListener("complete",s),t.addEventListener("error",o),t.addEventListener("abort",o)});Nn.set(t,e)}let Ln={get(t,e,n){if(t instanceof IDBTransaction){if(e==="done")return Nn.get(t);if(e==="objectStoreNames")return t.objectStoreNames||Pi.get(t);if(e==="store")return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return we(t[e])},set(t,e,n){return t[e]=n,!0},has(t,e){return t instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in t}};function Uo(t){Ln=t(Ln)}function Fo(t){return t===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...n){const r=t.call(un(this),e,...n);return Pi.set(r,e.sort?e.sort():[e]),we(r)}:Oo().includes(t)?function(...e){return t.apply(un(this),e),we(ki.get(this))}:function(...e){return we(t.apply(un(this),e))}}function Vo(t){return typeof t=="function"?Fo(t):(t instanceof IDBTransaction&&Do(t),Lo(t,xo())?new Proxy(t,Ln):t)}function we(t){if(t instanceof IDBRequest)return Mo(t);if(ln.has(t))return ln.get(t);const e=Vo(t);return e!==t&&(ln.set(t,e),Xn.set(e,t)),e}const un=t=>Xn.get(t);function jo(t,e,{blocked:n,upgrade:r,blocking:i,terminated:s}={}){const o=indexedDB.open(t,e),a=we(o);return r&&o.addEventListener("upgradeneeded",c=>{r(we(o.result),c.oldVersion,c.newVersion,we(o.transaction),c)}),n&&o.addEventListener("blocked",c=>n(c.oldVersion,c.newVersion,c)),a.then(c=>{s&&c.addEventListener("close",()=>s()),i&&c.addEventListener("versionchange",u=>i(u.oldVersion,u.newVersion,u))}).catch(()=>{}),a}const Ho=["get","getKey","getAll","getAllKeys","count"],$o=["put","add","delete","clear"],dn=new Map;function Er(t,e){if(!(t instanceof IDBDatabase&&!(e in t)&&typeof e=="string"))return;if(dn.get(e))return dn.get(e);const n=e.replace(/FromIndex$/,""),r=e!==n,i=$o.includes(n);if(!(n in(r?IDBIndex:IDBObjectStore).prototype)||!(i||Ho.includes(n)))return;const s=async function(o,...a){const c=this.transaction(o,i?"readwrite":"readonly");let u=c.store;return r&&(u=u.index(a.shift())),(await Promise.all([u[n](...a),i&&c.done]))[0]};return dn.set(e,s),s}Uo(t=>({...t,get:(e,n,r)=>Er(e,n)||t.get(e,n,r),has:(e,n)=>!!Er(e,n)||t.has(e,n)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bo{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(n=>{if(Zo(n)){const r=n.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(n=>n).join(" ")}}function Zo(t){const e=t.getComponent();return(e==null?void 0:e.type)==="VERSION"}const xn="@firebase/app",br="0.13.2";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const de=new Jn("@firebase/app"),Wo="@firebase/app-compat",zo="@firebase/analytics-compat",Go="@firebase/analytics",Ko="@firebase/app-check-compat",Yo="@firebase/app-check",qo="@firebase/auth",Jo="@firebase/auth-compat",Xo="@firebase/database",Qo="@firebase/data-connect",ea="@firebase/database-compat",ta="@firebase/functions",na="@firebase/functions-compat",ra="@firebase/installations",ia="@firebase/installations-compat",sa="@firebase/messaging",oa="@firebase/messaging-compat",aa="@firebase/performance",ca="@firebase/performance-compat",la="@firebase/remote-config",ua="@firebase/remote-config-compat",da="@firebase/storage",ha="@firebase/storage-compat",fa="@firebase/firestore",pa="@firebase/ai",ma="@firebase/firestore-compat",ga="firebase",va="11.10.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const On="[DEFAULT]",ya={[xn]:"fire-core",[Wo]:"fire-core-compat",[Go]:"fire-analytics",[zo]:"fire-analytics-compat",[Yo]:"fire-app-check",[Ko]:"fire-app-check-compat",[qo]:"fire-auth",[Jo]:"fire-auth-compat",[Xo]:"fire-rtdb",[Qo]:"fire-data-connect",[ea]:"fire-rtdb-compat",[ta]:"fire-fn",[na]:"fire-fn-compat",[ra]:"fire-iid",[ia]:"fire-iid-compat",[sa]:"fire-fcm",[oa]:"fire-fcm-compat",[aa]:"fire-perf",[ca]:"fire-perf-compat",[la]:"fire-rc",[ua]:"fire-rc-compat",[da]:"fire-gcs",[ha]:"fire-gcs-compat",[fa]:"fire-fst",[ma]:"fire-fst-compat",[pa]:"fire-vertex","fire-js":"fire-js",[ga]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Dt=new Map,_a=new Map,Mn=new Map;function Ir(t,e){try{t.container.addComponent(e)}catch(n){de.debug(`Component ${e.name} failed to register with FirebaseApp ${t.name}`,n)}}function Ne(t){const e=t.name;if(Mn.has(e))return de.debug(`There were multiple attempts to register component ${e}.`),!1;Mn.set(e,t);for(const n of Dt.values())Ir(n,t);for(const n of _a.values())Ir(n,t);return!0}function Ni(t,e){const n=t.container.getProvider("heartbeat").getImmediate({optional:!0});return n&&n.triggerHeartbeat(),t.container.getProvider(e)}function K(t){return t==null?!1:t.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wa={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},Ee=new Ae("app","Firebase",wa);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ea{constructor(e,n,r){this._isDeleted=!1,this._options=Object.assign({},e),this._config=Object.assign({},n),this._name=n.name,this._automaticDataCollectionEnabled=n.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new Ie("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw Ee.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ke=va;function Li(t,e={}){let n=t;typeof e!="object"&&(e={name:e});const r=Object.assign({name:On,automaticDataCollectionEnabled:!0},e),i=r.name;if(typeof i!="string"||!i)throw Ee.create("bad-app-name",{appName:String(i)});if(n||(n=Ii()),!n)throw Ee.create("no-options");const s=Dt.get(i);if(s){if(Ze(n,s.options)&&Ze(r,s.config))return s;throw Ee.create("duplicate-app",{appName:i})}const o=new Co(i);for(const c of Mn.values())o.addComponent(c);const a=new Ea(n,r,o);return Dt.set(i,a),a}function ba(t=On){const e=Dt.get(t);if(!e&&t===On&&Ii())return Li();if(!e)throw Ee.create("no-app",{appName:t});return e}function be(t,e,n){var r;let i=(r=ya[t])!==null&&r!==void 0?r:t;n&&(i+=`-${n}`);const s=i.match(/\s|\//),o=e.match(/\s|\//);if(s||o){const a=[`Unable to register library "${i}" with version "${e}":`];s&&a.push(`library name "${i}" contains illegal characters (whitespace or "/")`),s&&o&&a.push("and"),o&&a.push(`version name "${e}" contains illegal characters (whitespace or "/")`),de.warn(a.join(" "));return}Ne(new Ie(`${i}-version`,()=>({library:i,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ia="firebase-heartbeat-database",Aa=1,ut="firebase-heartbeat-store";let hn=null;function xi(){return hn||(hn=jo(Ia,Aa,{upgrade:(t,e)=>{switch(e){case 0:try{t.createObjectStore(ut)}catch(n){console.warn(n)}}}}).catch(t=>{throw Ee.create("idb-open",{originalErrorMessage:t.message})})),hn}async function Ta(t){try{const n=(await xi()).transaction(ut),r=await n.objectStore(ut).get(Oi(t));return await n.done,r}catch(e){if(e instanceof se)de.warn(e.message);else{const n=Ee.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});de.warn(n.message)}}}async function Ar(t,e){try{const r=(await xi()).transaction(ut,"readwrite");await r.objectStore(ut).put(e,Oi(t)),await r.done}catch(n){if(n instanceof se)de.warn(n.message);else{const r=Ee.create("idb-set",{originalErrorMessage:n==null?void 0:n.message});de.warn(r.message)}}}function Oi(t){return`${t.name}!${t.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Sa=1024,Ca=30;class Ra{constructor(e){this.container=e,this._heartbeatsCache=null;const n=this.container.getProvider("app").getImmediate();this._storage=new Pa(n),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){var e,n;try{const i=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),s=Tr();if(((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((n=this._heartbeatsCache)===null||n===void 0?void 0:n.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===s||this._heartbeatsCache.heartbeats.some(o=>o.date===s))return;if(this._heartbeatsCache.heartbeats.push({date:s,agent:i}),this._heartbeatsCache.heartbeats.length>Ca){const o=Na(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(o,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(r){de.warn(r)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const n=Tr(),{heartbeatsToSend:r,unsentEntries:i}=ka(this._heartbeatsCache.heartbeats),s=bi(JSON.stringify({version:2,heartbeats:r}));return this._heartbeatsCache.lastSentHeartbeatDate=n,i.length>0?(this._heartbeatsCache.heartbeats=i,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),s}catch(n){return de.warn(n),""}}}function Tr(){return new Date().toISOString().substring(0,10)}function ka(t,e=Sa){const n=[];let r=t.slice();for(const i of t){const s=n.find(o=>o.agent===i.agent);if(s){if(s.dates.push(i.date),Sr(n)>e){s.dates.pop();break}}else if(n.push({agent:i.agent,dates:[i.date]}),Sr(n)>e){n.pop();break}r=r.slice(1)}return{heartbeatsToSend:n,unsentEntries:r}}class Pa{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return vo()?yo().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const n=await Ta(this.app);return n!=null&&n.heartbeats?n:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){var n;if(await this._canUseIndexedDBPromise){const i=await this.read();return Ar(this.app,{lastSentHeartbeatDate:(n=e.lastSentHeartbeatDate)!==null&&n!==void 0?n:i.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){var n;if(await this._canUseIndexedDBPromise){const i=await this.read();return Ar(this.app,{lastSentHeartbeatDate:(n=e.lastSentHeartbeatDate)!==null&&n!==void 0?n:i.lastSentHeartbeatDate,heartbeats:[...i.heartbeats,...e.heartbeats]})}else return}}function Sr(t){return bi(JSON.stringify({version:2,heartbeats:t})).length}function Na(t){if(t.length===0)return-1;let e=0,n=t[0].date;for(let r=1;r<t.length;r++)t[r].date<n&&(n=t[r].date,e=r);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function La(t){Ne(new Ie("platform-logger",e=>new Bo(e),"PRIVATE")),Ne(new Ie("heartbeat",e=>new Ra(e),"PRIVATE")),be(xn,br,t),be(xn,br,"esm2017"),be("fire-js","")}La("");var xa="firebase",Oa="11.10.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */be(xa,Oa,"app");function vt(t,e){var n={};for(var r in t)Object.prototype.hasOwnProperty.call(t,r)&&e.indexOf(r)<0&&(n[r]=t[r]);if(t!=null&&typeof Object.getOwnPropertySymbols=="function")for(var i=0,r=Object.getOwnPropertySymbols(t);i<r.length;i++)e.indexOf(r[i])<0&&Object.prototype.propertyIsEnumerable.call(t,r[i])&&(n[r[i]]=t[r[i]]);return n}function Mi(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const Ma=Mi,Di=new Ae("auth","Firebase",Mi());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ut=new Jn("@firebase/auth");function Da(t,...e){Ut.logLevel<=U.WARN&&Ut.warn(`Auth (${Ke}): ${t}`,...e)}function kt(t,...e){Ut.logLevel<=U.ERROR&&Ut.error(`Auth (${Ke}): ${t}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Le(t,...e){throw Qn(t,...e)}function Ui(t,...e){return Qn(t,...e)}function Fi(t,e,n){const r=Object.assign(Object.assign({},Ma()),{[e]:n});return new Ae("auth","Firebase",r).create(e,{appName:t.name})}function Pe(t){return Fi(t,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function Qn(t,...e){if(typeof t!="string"){const n=e[0],r=[...e.slice(1)];return r[0]&&(r[0].appName=t.name),t._errorFactory.create(n,...r)}return Di.create(t,...e)}function N(t,e,...n){if(!t)throw Qn(e,...n)}function le(t){const e="INTERNAL ASSERTION FAILED: "+t;throw kt(e),new Error(e)}function Ft(t,e){t||le(e)}function Ua(){return Cr()==="http:"||Cr()==="https:"}function Cr(){var t;return typeof self<"u"&&((t=self.location)===null||t===void 0?void 0:t.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Fa(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(Ua()||Si()||"connection"in navigator)?navigator.onLine:!0}function Va(){if(typeof navigator>"u")return null;const t=navigator;return t.languages&&t.languages[0]||t.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let ja=class{constructor(e,n){this.shortDelay=e,this.longDelay=n,Ft(n>e,"Short delay should be less than long delay!"),this.isMobile=Ai()||Ci()}get(){return Fa()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ha(t,e){Ft(t.emulator,"Emulator should always be set here");const{url:n}=t.emulator;return e?`${n}${e.startsWith("/")?e.slice(1):e}`:n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Vi=class{static initialize(e,n,r){this.fetchImpl=e,n&&(this.headersImpl=n),r&&(this.responseImpl=r)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;le("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;le("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;le("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $a={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ba=["/v1/accounts:signInWithCustomToken","/v1/accounts:signInWithEmailLink","/v1/accounts:signInWithIdp","/v1/accounts:signInWithPassword","/v1/accounts:signInWithPhoneNumber","/v1/token"],Za=new ja(3e4,6e4);function Te(t,e){return t.tenantId&&!e.tenantId?Object.assign(Object.assign({},e),{tenantId:t.tenantId}):e}async function Se(t,e,n,r,i={}){return ji(t,i,async()=>{let s={},o={};r&&(e==="GET"?o=r:s={body:JSON.stringify(r)});const a=gt(Object.assign({key:t.config.apiKey},o)).slice(1),c=await t._getAdditionalHeaders();c["Content-Type"]="application/json",t.languageCode&&(c["X-Firebase-Locale"]=t.languageCode);const u=Object.assign({method:e,headers:c},s);return Ti()||(u.referrerPolicy="no-referrer"),t.emulatorConfig&&Ge(t.emulatorConfig.host)&&(u.credentials="include"),Vi.fetch()(await Hi(t,t.config.apiHost,n,a),u)})}async function ji(t,e,n){t._canInitEmulator=!1;const r=Object.assign(Object.assign({},$a),e);try{const i=new za(t),s=await Promise.race([n(),i.promise]);i.clearNetworkTimeout();const o=await s.json();if("needConfirmation"in o)throw Tt(t,"account-exists-with-different-credential",o);if(s.ok&&!("errorMessage"in o))return o;{const a=s.ok?o.errorMessage:o.error.message,[c,u]=a.split(" : ");if(c==="FEDERATED_USER_ID_ALREADY_LINKED")throw Tt(t,"credential-already-in-use",o);if(c==="EMAIL_EXISTS")throw Tt(t,"email-already-in-use",o);if(c==="USER_DISABLED")throw Tt(t,"user-disabled",o);const h=r[c]||c.toLowerCase().replace(/[_\s]+/g,"-");if(u)throw Fi(t,h,u);Le(t,h)}}catch(i){if(i instanceof se)throw i;Le(t,"network-request-failed",{message:String(i)})}}async function yt(t,e,n,r,i={}){const s=await Se(t,e,n,r,i);return"mfaPendingCredential"in s&&Le(t,"multi-factor-auth-required",{_serverResponse:s}),s}async function Hi(t,e,n,r){const i=`${e}${n}?${r}`,s=t,o=s.config.emulator?Ha(t.config,i):`${t.config.apiScheme}://${i}`;return Ba.includes(n)&&(await s._persistenceManagerAvailable,s._getPersistenceType()==="COOKIE")?s._getPersistence()._getFinalTarget(o).toString():o}function Wa(t){switch(t){case"ENFORCE":return"ENFORCE";case"AUDIT":return"AUDIT";case"OFF":return"OFF";default:return"ENFORCEMENT_STATE_UNSPECIFIED"}}let za=class{clearNetworkTimeout(){clearTimeout(this.timer)}constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((n,r)=>{this.timer=setTimeout(()=>r(Ui(this.auth,"network-request-failed")),Za.get())})}};function Tt(t,e,n){const r={appName:t.name};n.email&&(r.email=n.email),n.phoneNumber&&(r.phoneNumber=n.phoneNumber);const i=Ui(t,e,r);return i.customData._tokenResponse=n,i}function Rr(t){return t!==void 0&&t.enterprise!==void 0}class Ga{constructor(e){if(this.siteKey="",this.recaptchaEnforcementState=[],e.recaptchaKey===void 0)throw new Error("recaptchaKey undefined");this.siteKey=e.recaptchaKey.split("/")[3],this.recaptchaEnforcementState=e.recaptchaEnforcementState}getProviderEnforcementState(e){if(!this.recaptchaEnforcementState||this.recaptchaEnforcementState.length===0)return null;for(const n of this.recaptchaEnforcementState)if(n.provider&&n.provider===e)return Wa(n.enforcementState);return null}isProviderEnabled(e){return this.getProviderEnforcementState(e)==="ENFORCE"||this.getProviderEnforcementState(e)==="AUDIT"}isAnyProviderEnabled(){return this.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")||this.isProviderEnabled("PHONE_PROVIDER")}}async function Ka(t,e){return Se(t,"GET","/v2/recaptchaConfig",Te(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ya(t,e){return Se(t,"POST","/v1/accounts:delete",e)}async function Vt(t,e){return Se(t,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ot(t){if(t)try{const e=new Date(Number(t));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function qa(t,e=!1){const n=Y(t),r=await n.getIdToken(e),i=$i(r);N(i&&i.exp&&i.auth_time&&i.iat,n.auth,"internal-error");const s=typeof i.firebase=="object"?i.firebase:void 0,o=s==null?void 0:s.sign_in_provider;return{claims:i,token:r,authTime:ot(fn(i.auth_time)),issuedAtTime:ot(fn(i.iat)),expirationTime:ot(fn(i.exp)),signInProvider:o||null,signInSecondFactor:(s==null?void 0:s.sign_in_second_factor)||null}}function fn(t){return Number(t)*1e3}function $i(t){const[e,n,r]=t.split(".");if(e===void 0||n===void 0||r===void 0)return kt("JWT malformed, contained fewer than 3 sections"),null;try{const i=Yn(n);return i?JSON.parse(i):(kt("Failed to decode base64 JWT payload"),null)}catch(i){return kt("Caught error parsing JWT payload as JSON",i==null?void 0:i.toString()),null}}function kr(t){const e=$i(t);return N(e,"internal-error"),N(typeof e.exp<"u","internal-error"),N(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function jt(t,e,n=!1){if(n)return e;try{return await e}catch(r){throw r instanceof se&&Ja(r)&&t.auth.currentUser===t&&await t.auth.signOut(),r}}function Ja({code:t}){return t==="auth/user-disabled"||t==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Xa=class{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){var n;if(e){const r=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),r}else{this.errorBackoff=3e4;const i=((n=this.user.stsTokenManager.expirationTime)!==null&&n!==void 0?n:0)-Date.now()-3e5;return Math.max(0,i)}}schedule(e=!1){if(!this.isRunning)return;const n=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},n)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Dn=class{constructor(e,n){this.createdAt=e,this.lastLoginAt=n,this._initializeTime()}_initializeTime(){this.lastSignInTime=ot(this.lastLoginAt),this.creationTime=ot(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ht(t){var e;const n=t.auth,r=await t.getIdToken(),i=await jt(t,Vt(n,{idToken:r}));N(i==null?void 0:i.users.length,n,"internal-error");const s=i.users[0];t._notifyReloadListener(s);const o=!((e=s.providerUserInfo)===null||e===void 0)&&e.length?Bi(s.providerUserInfo):[],a=ec(t.providerData,o),c=t.isAnonymous,u=!(t.email&&s.passwordHash)&&!(a!=null&&a.length),h=c?u:!1,p={uid:s.localId,displayName:s.displayName||null,photoURL:s.photoUrl||null,email:s.email||null,emailVerified:s.emailVerified||!1,phoneNumber:s.phoneNumber||null,tenantId:s.tenantId||null,providerData:a,metadata:new Dn(s.createdAt,s.lastLoginAt),isAnonymous:h};Object.assign(t,p)}async function Qa(t){const e=Y(t);await Ht(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function ec(t,e){return[...t.filter(r=>!e.some(i=>i.providerId===r.providerId)),...e]}function Bi(t){return t.map(e=>{var{providerId:n}=e,r=vt(e,["providerId"]);return{providerId:n,uid:r.rawId||"",displayName:r.displayName||null,email:r.email||null,phoneNumber:r.phoneNumber||null,photoURL:r.photoUrl||null}})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function tc(t,e){const n=await ji(t,{},async()=>{const r=gt({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:i,apiKey:s}=t.config,o=await Hi(t,i,"/v1/token",`key=${s}`),a=await t._getAdditionalHeaders();a["Content-Type"]="application/x-www-form-urlencoded";const c={method:"POST",headers:a,body:r};return t.emulatorConfig&&Ge(t.emulatorConfig.host)&&(c.credentials="include"),Vi.fetch()(o,c)});return{accessToken:n.access_token,expiresIn:n.expires_in,refreshToken:n.refresh_token}}async function nc(t,e){return Se(t,"POST","/v2/accounts:revokeToken",Te(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let pn=class Un{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){N(e.idToken,"internal-error"),N(typeof e.idToken<"u","internal-error"),N(typeof e.refreshToken<"u","internal-error");const n="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):kr(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,n)}updateFromIdToken(e){N(e.length!==0,"internal-error");const n=kr(e);this.updateTokensAndExpiration(e,null,n)}async getToken(e,n=!1){return!n&&this.accessToken&&!this.isExpired?this.accessToken:(N(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,n){const{accessToken:r,refreshToken:i,expiresIn:s}=await tc(e,n);this.updateTokensAndExpiration(r,i,Number(s))}updateTokensAndExpiration(e,n,r){this.refreshToken=n||null,this.accessToken=e||null,this.expirationTime=Date.now()+r*1e3}static fromJSON(e,n){const{refreshToken:r,accessToken:i,expirationTime:s}=n,o=new Un;return r&&(N(typeof r=="string","internal-error",{appName:e}),o.refreshToken=r),i&&(N(typeof i=="string","internal-error",{appName:e}),o.accessToken=i),s&&(N(typeof s=="number","internal-error",{appName:e}),o.expirationTime=s),o}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new Un,this.toJSON())}_performRefresh(){return le("not implemented")}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pe(t,e){N(typeof t=="string"||typeof t>"u","internal-error",{appName:e})}let De=class it{constructor(e){var{uid:n,auth:r,stsTokenManager:i}=e,s=vt(e,["uid","auth","stsTokenManager"]);this.providerId="firebase",this.proactiveRefresh=new Xa(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=n,this.auth=r,this.stsTokenManager=i,this.accessToken=i.accessToken,this.displayName=s.displayName||null,this.email=s.email||null,this.emailVerified=s.emailVerified||!1,this.phoneNumber=s.phoneNumber||null,this.photoURL=s.photoURL||null,this.isAnonymous=s.isAnonymous||!1,this.tenantId=s.tenantId||null,this.providerData=s.providerData?[...s.providerData]:[],this.metadata=new Dn(s.createdAt||void 0,s.lastLoginAt||void 0)}async getIdToken(e){const n=await jt(this,this.stsTokenManager.getToken(this.auth,e));return N(n,this.auth,"internal-error"),this.accessToken!==n&&(this.accessToken=n,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),n}getIdTokenResult(e){return qa(this,e)}reload(){return Qa(this)}_assign(e){this!==e&&(N(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(n=>Object.assign({},n)),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const n=new it(Object.assign(Object.assign({},this),{auth:e,stsTokenManager:this.stsTokenManager._clone()}));return n.metadata._copy(this.metadata),n}_onReload(e){N(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,n=!1){let r=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),r=!0),n&&await Ht(this),await this.auth._persistUserIfCurrent(this),r&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(K(this.auth.app))return Promise.reject(Pe(this.auth));const e=await this.getIdToken();return await jt(this,Ya(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return Object.assign(Object.assign({uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>Object.assign({},e)),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId},this.metadata.toJSON()),{apiKey:this.auth.config.apiKey,appName:this.auth.name})}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,n){var r,i,s,o,a,c,u,h;const p=(r=n.displayName)!==null&&r!==void 0?r:void 0,f=(i=n.email)!==null&&i!==void 0?i:void 0,m=(s=n.phoneNumber)!==null&&s!==void 0?s:void 0,_=(o=n.photoURL)!==null&&o!==void 0?o:void 0,g=(a=n.tenantId)!==null&&a!==void 0?a:void 0,y=(c=n._redirectEventId)!==null&&c!==void 0?c:void 0,w=(u=n.createdAt)!==null&&u!==void 0?u:void 0,E=(h=n.lastLoginAt)!==null&&h!==void 0?h:void 0,{uid:v,emailVerified:A,isAnonymous:S,providerData:R,stsTokenManager:x}=n;N(v&&x,e,"internal-error");const V=pn.fromJSON(this.name,x);N(typeof v=="string",e,"internal-error"),pe(p,e.name),pe(f,e.name),N(typeof A=="boolean",e,"internal-error"),N(typeof S=="boolean",e,"internal-error"),pe(m,e.name),pe(_,e.name),pe(g,e.name),pe(y,e.name),pe(w,e.name),pe(E,e.name);const O=new it({uid:v,auth:e,email:f,emailVerified:A,displayName:p,isAnonymous:S,photoURL:_,phoneNumber:m,tenantId:g,stsTokenManager:V,createdAt:w,lastLoginAt:E});return R&&Array.isArray(R)&&(O.providerData=R.map(F=>Object.assign({},F))),y&&(O._redirectEventId=y),O}static async _fromIdTokenResponse(e,n,r=!1){const i=new pn;i.updateFromServerResponse(n);const s=new it({uid:n.localId,auth:e,stsTokenManager:i,isAnonymous:r});return await Ht(s),s}static async _fromGetAccountInfoResponse(e,n,r){const i=n.users[0];N(i.localId!==void 0,"internal-error");const s=i.providerUserInfo!==void 0?Bi(i.providerUserInfo):[],o=!(i.email&&i.passwordHash)&&!(s!=null&&s.length),a=new pn;a.updateFromIdToken(r);const c=new it({uid:i.localId,auth:e,stsTokenManager:a,isAnonymous:o}),u={uid:i.localId,displayName:i.displayName||null,photoURL:i.photoUrl||null,email:i.email||null,emailVerified:i.emailVerified||!1,phoneNumber:i.phoneNumber||null,tenantId:i.tenantId||null,providerData:s,metadata:new Dn(i.createdAt,i.lastLoginAt),isAnonymous:!(i.email&&i.passwordHash)&&!(s!=null&&s.length)};return Object.assign(c,u),c}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pr=new Map;function Re(t){Ft(t instanceof Function,"Expected a class definition");let e=Pr.get(t);return e?(Ft(e instanceof t,"Instance stored in cache mismatched with class"),e):(e=new t,Pr.set(t,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Zi=class{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,n){this.storage[e]=n}async _get(e){const n=this.storage[e];return n===void 0?null:n}async _remove(e){delete this.storage[e]}_addListener(e,n){}_removeListener(e,n){}};Zi.type="NONE";const Nr=Zi;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function mn(t,e,n){return`firebase:${t}:${e}:${n}`}let Lr=class Pt{constructor(e,n,r){this.persistence=e,this.auth=n,this.userKey=r;const{config:i,name:s}=this.auth;this.fullUserKey=mn(this.userKey,i.apiKey,s),this.fullPersistenceKey=mn("persistence",i.apiKey,s),this.boundEventHandler=n._onStorageEvent.bind(n),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);if(!e)return null;if(typeof e=="string"){const n=await Vt(this.auth,{idToken:e}).catch(()=>{});return n?De._fromGetAccountInfoResponse(this.auth,n,e):null}return De._fromJSON(this.auth,e)}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const n=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,n)return this.setCurrentUser(n)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,n,r="authUser"){if(!n.length)return new Pt(Re(Nr),e,r);const i=(await Promise.all(n.map(async u=>{if(await u._isAvailable())return u}))).filter(u=>u);let s=i[0]||Re(Nr);const o=mn(r,e.config.apiKey,e.name);let a=null;for(const u of n)try{const h=await u._get(o);if(h){let p;if(typeof h=="string"){const f=await Vt(e,{idToken:h}).catch(()=>{});if(!f)break;p=await De._fromGetAccountInfoResponse(e,f,h)}else p=De._fromJSON(e,h);u!==s&&(a=p),s=u;break}}catch{}const c=i.filter(u=>u._shouldAllowMigration);return!s._shouldAllowMigration||!c.length?new Pt(s,e,r):(s=c[0],a&&await s._set(o,a.toJSON()),await Promise.all(n.map(async u=>{if(u!==s)try{await u._remove(o)}catch{}})),new Pt(s,e,r))}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xr(t){const e=t.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(oc(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(rc(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(cc(e))return"Blackberry";if(lc(e))return"Webos";if(ic(e))return"Safari";if((e.includes("chrome/")||sc(e))&&!e.includes("edge/"))return"Chrome";if(ac(e))return"Android";{const n=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,r=t.match(n);if((r==null?void 0:r.length)===2)return r[1]}return"Other"}function rc(t=G()){return/firefox\//i.test(t)}function ic(t=G()){const e=t.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function sc(t=G()){return/crios\//i.test(t)}function oc(t=G()){return/iemobile/i.test(t)}function ac(t=G()){return/android/i.test(t)}function cc(t=G()){return/blackberry/i.test(t)}function lc(t=G()){return/webos/i.test(t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wi(t,e=[]){let n;switch(t){case"Browser":n=xr(G());break;case"Worker":n=`${xr(G())}-${t}`;break;default:n=t}const r=e.length?e.join(","):"FirebaseCore-web";return`${n}/JsCore/${Ke}/${r}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let uc=class{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,n){const r=s=>new Promise((o,a)=>{try{const c=e(s);o(c)}catch(c){a(c)}});r.onAbort=n,this.queue.push(r);const i=this.queue.length-1;return()=>{this.queue[i]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const n=[];try{for(const r of this.queue)await r(e),r.onAbort&&n.push(r.onAbort)}catch(r){n.reverse();for(const i of n)try{i()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:r==null?void 0:r.message})}}};/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function dc(t,e={}){return Se(t,"GET","/v2/passwordPolicy",Te(t,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hc=6;let fc=class{constructor(e){var n,r,i,s;const o=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=(n=o.minPasswordLength)!==null&&n!==void 0?n:hc,o.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=o.maxPasswordLength),o.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=o.containsLowercaseCharacter),o.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=o.containsUppercaseCharacter),o.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=o.containsNumericCharacter),o.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=o.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=(i=(r=e.allowedNonAlphanumericCharacters)===null||r===void 0?void 0:r.join(""))!==null&&i!==void 0?i:"",this.forceUpgradeOnSignin=(s=e.forceUpgradeOnSignin)!==null&&s!==void 0?s:!1,this.schemaVersion=e.schemaVersion}validatePassword(e){var n,r,i,s,o,a;const c={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,c),this.validatePasswordCharacterOptions(e,c),c.isValid&&(c.isValid=(n=c.meetsMinPasswordLength)!==null&&n!==void 0?n:!0),c.isValid&&(c.isValid=(r=c.meetsMaxPasswordLength)!==null&&r!==void 0?r:!0),c.isValid&&(c.isValid=(i=c.containsLowercaseLetter)!==null&&i!==void 0?i:!0),c.isValid&&(c.isValid=(s=c.containsUppercaseLetter)!==null&&s!==void 0?s:!0),c.isValid&&(c.isValid=(o=c.containsNumericCharacter)!==null&&o!==void 0?o:!0),c.isValid&&(c.isValid=(a=c.containsNonAlphanumericCharacter)!==null&&a!==void 0?a:!0),c}validatePasswordLengthOptions(e,n){const r=this.customStrengthOptions.minPasswordLength,i=this.customStrengthOptions.maxPasswordLength;r&&(n.meetsMinPasswordLength=e.length>=r),i&&(n.meetsMaxPasswordLength=e.length<=i)}validatePasswordCharacterOptions(e,n){this.updatePasswordCharacterOptionsStatuses(n,!1,!1,!1,!1);let r;for(let i=0;i<e.length;i++)r=e.charAt(i),this.updatePasswordCharacterOptionsStatuses(n,r>="a"&&r<="z",r>="A"&&r<="Z",r>="0"&&r<="9",this.allowedNonAlphanumericCharacters.includes(r))}updatePasswordCharacterOptionsStatuses(e,n,r,i,s){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=n)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=r)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=i)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=s))}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let pc=class{constructor(e,n,r,i){this.app=e,this.heartbeatServiceProvider=n,this.appCheckServiceProvider=r,this.config=i,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new Or(this),this.idTokenSubscription=new Or(this),this.beforeStateQueue=new uc(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=Di,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this._resolvePersistenceManagerAvailable=void 0,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=i.sdkClientVersion,this._persistenceManagerAvailable=new Promise(s=>this._resolvePersistenceManagerAvailable=s)}_initializeWithPersistence(e,n){return n&&(this._popupRedirectResolver=Re(n)),this._initializationPromise=this.queue(async()=>{var r,i,s;if(!this._deleted&&(this.persistenceManager=await Lr.create(this,e),(r=this._resolvePersistenceManagerAvailable)===null||r===void 0||r.call(this),!this._deleted)){if(!((i=this._popupRedirectResolver)===null||i===void 0)&&i._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(n),this.lastNotifiedUid=((s=this.currentUser)===null||s===void 0?void 0:s.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const n=await Vt(this,{idToken:e}),r=await De._fromGetAccountInfoResponse(this,n,e);await this.directlySetCurrentUser(r)}catch(n){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",n),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var n;if(K(this.app)){const o=this.app.settings.authIdToken;return o?new Promise(a=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(o).then(a,a))}):this.directlySetCurrentUser(null)}const r=await this.assertedPersistence.getCurrentUser();let i=r,s=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const o=(n=this.redirectUser)===null||n===void 0?void 0:n._redirectEventId,a=i==null?void 0:i._redirectEventId,c=await this.tryRedirectSignIn(e);(!o||o===a)&&(c!=null&&c.user)&&(i=c.user,s=!0)}if(!i)return this.directlySetCurrentUser(null);if(!i._redirectEventId){if(s)try{await this.beforeStateQueue.runMiddleware(i)}catch(o){i=r,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(o))}return i?this.reloadAndSetCurrentUserOrClear(i):this.directlySetCurrentUser(null)}return N(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===i._redirectEventId?this.directlySetCurrentUser(i):this.reloadAndSetCurrentUserOrClear(i)}async tryRedirectSignIn(e){let n=null;try{n=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return n}async reloadAndSetCurrentUserOrClear(e){try{await Ht(e)}catch(n){if((n==null?void 0:n.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=Va()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(K(this.app))return Promise.reject(Pe(this));const n=e?Y(e):null;return n&&N(n.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(n&&n._clone(this))}async _updateCurrentUser(e,n=!1){if(!this._deleted)return e&&N(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),n||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return K(this.app)?Promise.reject(Pe(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return K(this.app)?Promise.reject(Pe(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(Re(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const n=this._getPasswordPolicyInternal();return n.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):n.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await dc(this),n=new fc(e);this.tenantId===null?this._projectPasswordPolicy=n:this._tenantPasswordPolicies[this.tenantId]=n}_getPersistenceType(){return this.assertedPersistence.persistence.type}_getPersistence(){return this.assertedPersistence.persistence}_updateErrorMap(e){this._errorFactory=new Ae("auth","Firebase",e())}onAuthStateChanged(e,n,r){return this.registerStateListener(this.authStateSubscription,e,n,r)}beforeAuthStateChanged(e,n){return this.beforeStateQueue.pushCallback(e,n)}onIdTokenChanged(e,n,r){return this.registerStateListener(this.idTokenSubscription,e,n,r)}authStateReady(){return new Promise((e,n)=>{if(this.currentUser)e();else{const r=this.onAuthStateChanged(()=>{r(),e()},n)}})}async revokeAccessToken(e){if(this.currentUser){const n=await this.currentUser.getIdToken(),r={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:n};this.tenantId!=null&&(r.tenantId=this.tenantId),await nc(this,r)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)===null||e===void 0?void 0:e.toJSON()}}async _setRedirectUser(e,n){const r=await this.getOrInitRedirectPersistenceManager(n);return e===null?r.removeCurrentUser():r.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const n=e&&Re(e)||this._popupRedirectResolver;N(n,this,"argument-error"),this.redirectPersistenceManager=await Lr.create(this,[Re(n._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var n,r;return this._isInitialized&&await this.queue(async()=>{}),((n=this._currentUser)===null||n===void 0?void 0:n._redirectEventId)===e?this._currentUser:((r=this.redirectUser)===null||r===void 0?void 0:r._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var e,n;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const r=(n=(e=this.currentUser)===null||e===void 0?void 0:e.uid)!==null&&n!==void 0?n:null;this.lastNotifiedUid!==r&&(this.lastNotifiedUid=r,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,n,r,i){if(this._deleted)return()=>{};const s=typeof n=="function"?n:n.next.bind(n);let o=!1;const a=this._isInitialized?Promise.resolve():this._initializationPromise;if(N(a,this,"internal-error"),a.then(()=>{o||s(this.currentUser)}),typeof n=="function"){const c=e.addObserver(n,r,i);return()=>{o=!0,c()}}else{const c=e.addObserver(n);return()=>{o=!0,c()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return N(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=Wi(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var e;const n={"X-Client-Version":this.clientVersion};this.app.options.appId&&(n["X-Firebase-gmpid"]=this.app.options.appId);const r=await((e=this.heartbeatServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getHeartbeatsHeader());r&&(n["X-Firebase-Client"]=r);const i=await this._getAppCheckToken();return i&&(n["X-Firebase-AppCheck"]=i),n}async _getAppCheckToken(){var e;if(K(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const n=await((e=this.appCheckServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getToken());return n!=null&&n.error&&Da(`Error while retrieving App Check token: ${n.error}`),n==null?void 0:n.token}};function Ye(t){return Y(t)}let Or=class{constructor(e){this.auth=e,this.observer=null,this.addObserver=Ri(n=>this.observer=n)}get next(){return N(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let zi={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function mc(t){return zi.loadJS(t)}function gc(){return zi.recaptchaEnterpriseScript}class vc{constructor(){this.enterprise=new yc}ready(e){e()}execute(e,n){return Promise.resolve("token")}render(e,n){return""}}class yc{ready(e){e()}execute(e,n){return Promise.resolve("token")}render(e,n){return""}}const _c="recaptcha-enterprise",Gi="NO_RECAPTCHA";class wc{constructor(e){this.type=_c,this.auth=Ye(e)}async verify(e="verify",n=!1){async function r(s){if(!n){if(s.tenantId==null&&s._agentRecaptchaConfig!=null)return s._agentRecaptchaConfig.siteKey;if(s.tenantId!=null&&s._tenantRecaptchaConfigs[s.tenantId]!==void 0)return s._tenantRecaptchaConfigs[s.tenantId].siteKey}return new Promise(async(o,a)=>{Ka(s,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then(c=>{if(c.recaptchaKey===void 0)a(new Error("recaptcha Enterprise site key undefined"));else{const u=new Ga(c);return s.tenantId==null?s._agentRecaptchaConfig=u:s._tenantRecaptchaConfigs[s.tenantId]=u,o(u.siteKey)}}).catch(c=>{a(c)})})}function i(s,o,a){const c=window.grecaptcha;Rr(c)?c.enterprise.ready(()=>{c.enterprise.execute(s,{action:e}).then(u=>{o(u)}).catch(()=>{o(Gi)})}):a(Error("No reCAPTCHA enterprise script loaded."))}return this.auth.settings.appVerificationDisabledForTesting?new vc().execute("siteKey",{action:"verify"}):new Promise((s,o)=>{r(this.auth).then(a=>{if(!n&&Rr(window.grecaptcha))i(a,s,o);else{if(typeof window>"u"){o(new Error("RecaptchaVerifier is only supported in browser"));return}let c=gc();c.length!==0&&(c+=a),mc(c).then(()=>{i(a,s,o)}).catch(u=>{o(u)})}}).catch(a=>{o(a)})})}}async function Mr(t,e,n,r=!1,i=!1){const s=new wc(t);let o;if(i)o=Gi;else try{o=await s.verify(n)}catch{o=await s.verify(n,!0)}const a=Object.assign({},e);if(n==="mfaSmsEnrollment"||n==="mfaSmsSignIn"){if("phoneEnrollmentInfo"in a){const c=a.phoneEnrollmentInfo.phoneNumber,u=a.phoneEnrollmentInfo.recaptchaToken;Object.assign(a,{phoneEnrollmentInfo:{phoneNumber:c,recaptchaToken:u,captchaResponse:o,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}else if("phoneSignInInfo"in a){const c=a.phoneSignInInfo.recaptchaToken;Object.assign(a,{phoneSignInInfo:{recaptchaToken:c,captchaResponse:o,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}return a}return r?Object.assign(a,{captchaResp:o}):Object.assign(a,{captchaResponse:o}),Object.assign(a,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(a,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),a}async function Fn(t,e,n,r,i){var s;if(!((s=t._getRecaptchaConfig())===null||s===void 0)&&s.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")){const o=await Mr(t,e,n,n==="getOobCode");return r(t,o)}else return r(t,e).catch(async o=>{if(o.code==="auth/missing-recaptcha-token"){console.log(`${n} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`);const a=await Mr(t,e,n,n==="getOobCode");return r(t,a)}else return Promise.reject(o)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ec(t,e){const n=Ni(t,"auth");if(n.isInitialized()){const i=n.getImmediate(),s=n.getOptions();if(Ze(s,e??{}))return i;Le(i,"already-initialized")}return n.initialize({options:e})}function bc(t,e){const n=(e==null?void 0:e.persistence)||[],r=(Array.isArray(n)?n:[n]).map(Re);e!=null&&e.errorMap&&t._updateErrorMap(e.errorMap),t._initializeWithPersistence(r,e==null?void 0:e.popupRedirectResolver)}function Ic(t,e,n){const r=Ye(t);N(/^https?:\/\//.test(e),r,"invalid-emulator-scheme");const i=!1,s=Ki(e),{host:o,port:a}=Ac(e),c=a===null?"":`:${a}`,u={url:`${s}//${o}${c}/`},h=Object.freeze({host:o,port:a,protocol:s.replace(":",""),options:Object.freeze({disableWarnings:i})});if(!r._canInitEmulator){N(r.config.emulator&&r.emulatorConfig,r,"emulator-config-failed"),N(Ze(u,r.config.emulator)&&Ze(h,r.emulatorConfig),r,"emulator-config-failed");return}r.config.emulator=u,r.emulatorConfig=h,r.settings.appVerificationDisabledForTesting=!0,Ge(o)?(fo(`${s}//${o}${c}`),go("Auth",!0)):Tc()}function Ki(t){const e=t.indexOf(":");return e<0?"":t.substr(0,e+1)}function Ac(t){const e=Ki(t),n=/(\/\/)?([^?#/]+)/.exec(t.substr(e.length));if(!n)return{host:"",port:null};const r=n[2].split("@").pop()||"",i=/^(\[[^\]]+\])(:|$)/.exec(r);if(i){const s=i[1];return{host:s,port:Dr(r.substr(s.length+1))}}else{const[s,o]=r.split(":");return{host:s,port:Dr(o)}}}function Dr(t){if(!t)return null;const e=Number(t);return isNaN(e)?null:e}function Tc(){function t(){const e=document.createElement("p"),n=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",n.position="fixed",n.width="100%",n.backgroundColor="#ffffff",n.border=".1em solid #000000",n.color="#b50000",n.bottom="0px",n.left="0px",n.margin="0px",n.zIndex="10000",n.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",t):t())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yi{constructor(e,n){this.providerId=e,this.signInMethod=n}toJSON(){return le("not implemented")}_getIdTokenResponse(e){return le("not implemented")}_linkToIdToken(e,n){return le("not implemented")}_getReauthenticationResolver(e){return le("not implemented")}}async function Sc(t,e){return Se(t,"POST","/v1/accounts:signUp",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Cc(t,e){return yt(t,"POST","/v1/accounts:signInWithPassword",Te(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Rc(t,e){return yt(t,"POST","/v1/accounts:signInWithEmailLink",Te(t,e))}async function kc(t,e){return yt(t,"POST","/v1/accounts:signInWithEmailLink",Te(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dt extends Yi{constructor(e,n,r,i=null){super("password",r),this._email=e,this._password=n,this._tenantId=i}static _fromEmailAndPassword(e,n){return new dt(e,n,"password")}static _fromEmailAndCode(e,n,r=null){return new dt(e,n,"emailLink",r)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(e){const n=typeof e=="string"?JSON.parse(e):e;if(n!=null&&n.email&&(n!=null&&n.password)){if(n.signInMethod==="password")return this._fromEmailAndPassword(n.email,n.password);if(n.signInMethod==="emailLink")return this._fromEmailAndCode(n.email,n.password,n.tenantId)}return null}async _getIdTokenResponse(e){switch(this.signInMethod){case"password":const n={returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Fn(e,n,"signInWithPassword",Cc);case"emailLink":return Rc(e,{email:this._email,oobCode:this._password});default:Le(e,"internal-error")}}async _linkToIdToken(e,n){switch(this.signInMethod){case"password":const r={idToken:n,returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return Fn(e,r,"signUpPassword",Sc);case"emailLink":return kc(e,{idToken:n,email:this._email,oobCode:this._password});default:Le(e,"internal-error")}}_getReauthenticationResolver(e){return this._getIdTokenResponse(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function gn(t,e){return yt(t,"POST","/v1/accounts:signInWithIdp",Te(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pc="http://localhost";class xe extends Yi{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const n=new xe(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(n.idToken=e.idToken),e.accessToken&&(n.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(n.nonce=e.nonce),e.pendingToken&&(n.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(n.accessToken=e.oauthToken,n.secret=e.oauthTokenSecret):Le("argument-error"),n}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const n=typeof e=="string"?JSON.parse(e):e,{providerId:r,signInMethod:i}=n,s=vt(n,["providerId","signInMethod"]);if(!r||!i)return null;const o=new xe(r,i);return o.idToken=s.idToken||void 0,o.accessToken=s.accessToken||void 0,o.secret=s.secret,o.nonce=s.nonce,o.pendingToken=s.pendingToken||null,o}_getIdTokenResponse(e){const n=this.buildRequest();return gn(e,n)}_linkToIdToken(e,n){const r=this.buildRequest();return r.idToken=n,gn(e,r)}_getReauthenticationResolver(e){const n=this.buildRequest();return n.autoCreate=!1,gn(e,n)}buildRequest(){const e={requestUri:Pc,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const n={};this.idToken&&(n.id_token=this.idToken),this.accessToken&&(n.access_token=this.accessToken),this.secret&&(n.oauth_token_secret=this.secret),n.providerId=this.providerId,this.nonce&&!this.pendingToken&&(n.nonce=this.nonce),e.postBody=gt(n)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Nc(t){switch(t){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}function Lc(t){const e=nt(rt(t)).link,n=e?nt(rt(e)).deep_link_id:null,r=nt(rt(t)).deep_link_id;return(r?nt(rt(r)).link:null)||r||n||e||t}class er{constructor(e){var n,r,i,s,o,a;const c=nt(rt(e)),u=(n=c.apiKey)!==null&&n!==void 0?n:null,h=(r=c.oobCode)!==null&&r!==void 0?r:null,p=Nc((i=c.mode)!==null&&i!==void 0?i:null);N(u&&h&&p,"argument-error"),this.apiKey=u,this.operation=p,this.code=h,this.continueUrl=(s=c.continueUrl)!==null&&s!==void 0?s:null,this.languageCode=(o=c.lang)!==null&&o!==void 0?o:null,this.tenantId=(a=c.tenantId)!==null&&a!==void 0?a:null}static parseLink(e){const n=Lc(e);try{return new er(n)}catch{return null}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qe{constructor(){this.providerId=qe.PROVIDER_ID}static credential(e,n){return dt._fromEmailAndPassword(e,n)}static credentialWithLink(e,n){const r=er.parseLink(n);return N(r,"argument-error"),dt._fromEmailAndCode(e,r.code,r.tenantId)}}qe.PROVIDER_ID="password";qe.EMAIL_PASSWORD_SIGN_IN_METHOD="password";qe.EMAIL_LINK_SIGN_IN_METHOD="emailLink";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xc{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qt extends xc{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ge extends Qt{constructor(){super("facebook.com")}static credential(e){return xe._fromParams({providerId:ge.PROVIDER_ID,signInMethod:ge.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return ge.credentialFromTaggedObject(e)}static credentialFromError(e){return ge.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return ge.credential(e.oauthAccessToken)}catch{return null}}}ge.FACEBOOK_SIGN_IN_METHOD="facebook.com";ge.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ce extends Qt{constructor(){super("google.com"),this.addScope("profile")}static credential(e,n){return xe._fromParams({providerId:ce.PROVIDER_ID,signInMethod:ce.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:n})}static credentialFromResult(e){return ce.credentialFromTaggedObject(e)}static credentialFromError(e){return ce.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:n,oauthAccessToken:r}=e;if(!n&&!r)return null;try{return ce.credential(n,r)}catch{return null}}}ce.GOOGLE_SIGN_IN_METHOD="google.com";ce.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ve extends Qt{constructor(){super("github.com")}static credential(e){return xe._fromParams({providerId:ve.PROVIDER_ID,signInMethod:ve.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return ve.credentialFromTaggedObject(e)}static credentialFromError(e){return ve.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return ve.credential(e.oauthAccessToken)}catch{return null}}}ve.GITHUB_SIGN_IN_METHOD="github.com";ve.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ye extends Qt{constructor(){super("twitter.com")}static credential(e,n){return xe._fromParams({providerId:ye.PROVIDER_ID,signInMethod:ye.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:n})}static credentialFromResult(e){return ye.credentialFromTaggedObject(e)}static credentialFromError(e){return ye.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:n,oauthTokenSecret:r}=e;if(!n||!r)return null;try{return ye.credential(n,r)}catch{return null}}}ye.TWITTER_SIGN_IN_METHOD="twitter.com";ye.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Oc(t,e){return yt(t,"POST","/v1/accounts:signUp",Te(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ht{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,n,r,i=!1){const s=await De._fromIdTokenResponse(e,r,i),o=Ur(r);return new ht({user:s,providerId:o,_tokenResponse:r,operationType:n})}static async _forOperation(e,n,r){await e._updateTokensIfNecessary(r,!0);const i=Ur(r);return new ht({user:e,providerId:i,_tokenResponse:r,operationType:n})}}function Ur(t){return t.providerId?t.providerId:"phoneNumber"in t?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $t extends se{constructor(e,n,r,i){var s;super(n.code,n.message),this.operationType=r,this.user=i,Object.setPrototypeOf(this,$t.prototype),this.customData={appName:e.name,tenantId:(s=e.tenantId)!==null&&s!==void 0?s:void 0,_serverResponse:n.customData._serverResponse,operationType:r}}static _fromErrorAndOperation(e,n,r,i){return new $t(e,n,r,i)}}function Mc(t,e,n,r){return n._getIdTokenResponse(t).catch(s=>{throw s.code==="auth/multi-factor-auth-required"?$t._fromErrorAndOperation(t,s,e,r):s})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Dc(t,e,n=!1){if(K(t.app))return Promise.reject(Pe(t));const r="signIn",i=await Mc(t,r,e),s=await ht._fromIdTokenResponse(t,r,i);return n||await t._updateCurrentUser(s.user),s}async function qi(t,e){return Dc(Ye(t),e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ji(t){const e=Ye(t);e._getPasswordPolicyInternal()&&await e._updatePasswordPolicy()}async function Uc(t,e,n){if(K(t.app))return Promise.reject(Pe(t));const r=Ye(t),o=await Fn(r,{returnSecureToken:!0,email:e,password:n,clientType:"CLIENT_TYPE_WEB"},"signUpPassword",Oc).catch(c=>{throw c.code==="auth/password-does-not-meet-requirements"&&Ji(t),c}),a=await ht._fromIdTokenResponse(r,"signIn",o);return await r._updateCurrentUser(a.user),a}function Fc(t,e,n){return K(t.app)?Promise.reject(Pe(t)):qi(Y(t),qe.credential(e,n)).catch(async r=>{throw r.code==="auth/password-does-not-meet-requirements"&&Ji(t),r})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Vc(t,e){return Se(t,"POST","/v1/accounts:update",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function jc(t,{displayName:e,photoURL:n}){if(e===void 0&&n===void 0)return;const r=Y(t),s={idToken:await r.getIdToken(),displayName:e,photoUrl:n,returnSecureToken:!0},o=await jt(r,Vc(r.auth,s));r.displayName=o.displayName||null,r.photoURL=o.photoUrl||null;const a=r.providerData.find(({providerId:c})=>c==="password");a&&(a.displayName=r.displayName,a.photoURL=r.photoURL),await r._updateTokensIfNecessary(o)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Hc(t,e){return Y(t).setPersistence(e)}function Xi(t,e,n,r){return Y(t).onAuthStateChanged(e,n,r)}function $c(t){return Y(t).signOut()}const Fr="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Bc(t){return Promise.all(t.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(n){return{fulfilled:!1,reason:n}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class en{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const n=this.receivers.find(i=>i.isListeningto(e));if(n)return n;const r=new en(e);return this.receivers.push(r),r}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const n=e,{eventId:r,eventType:i,data:s}=n.data,o=this.handlersMap[i];if(!(o!=null&&o.size))return;n.ports[0].postMessage({status:"ack",eventId:r,eventType:i});const a=Array.from(o).map(async u=>u(n.origin,s)),c=await Bc(a);n.ports[0].postMessage({status:"done",eventId:r,eventType:i,response:c})}_subscribe(e,n){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(n)}_unsubscribe(e,n){this.handlersMap[e]&&n&&this.handlersMap[e].delete(n),(!n||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}en.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Zc(t="",e=10){let n="";for(let r=0;r<e;r++)n+=Math.floor(Math.random()*10);return t+n}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wc{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,n,r=50){const i=typeof MessageChannel<"u"?new MessageChannel:null;if(!i)throw new Error("connection_unavailable");let s,o;return new Promise((a,c)=>{const u=Zc("",20);i.port1.start();const h=setTimeout(()=>{c(new Error("unsupported_event"))},r);o={messageChannel:i,onMessage(p){const f=p;if(f.data.eventId===u)switch(f.data.status){case"ack":clearTimeout(h),s=setTimeout(()=>{c(new Error("timeout"))},3e3);break;case"done":clearTimeout(s),a(f.data.response);break;default:clearTimeout(h),clearTimeout(s),c(new Error("invalid_response"));break}}},this.handlers.add(o),i.port1.addEventListener("message",o.onMessage),this.target.postMessage({eventType:e,eventId:u,data:n},[i.port2])}).finally(()=>{o&&this.removeMessageHandler(o)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Vr(){return window}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qi(){return typeof Vr().WorkerGlobalScope<"u"&&typeof Vr().importScripts=="function"}async function zc(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function Gc(){var t;return((t=navigator==null?void 0:navigator.serviceWorker)===null||t===void 0?void 0:t.controller)||null}function Kc(){return Qi()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const es="firebaseLocalStorageDb",Yc=1,Bt="firebaseLocalStorage",ts="fbase_key";class _t{constructor(e){this.request=e}toPromise(){return new Promise((e,n)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{n(this.request.error)})})}}function tn(t,e){return t.transaction([Bt],e?"readwrite":"readonly").objectStore(Bt)}function qc(){const t=indexedDB.deleteDatabase(es);return new _t(t).toPromise()}function Vn(){const t=indexedDB.open(es,Yc);return new Promise((e,n)=>{t.addEventListener("error",()=>{n(t.error)}),t.addEventListener("upgradeneeded",()=>{const r=t.result;try{r.createObjectStore(Bt,{keyPath:ts})}catch(i){n(i)}}),t.addEventListener("success",async()=>{const r=t.result;r.objectStoreNames.contains(Bt)?e(r):(r.close(),await qc(),e(await Vn()))})})}async function jr(t,e,n){const r=tn(t,!0).put({[ts]:e,value:n});return new _t(r).toPromise()}async function Jc(t,e){const n=tn(t,!1).get(e),r=await new _t(n).toPromise();return r===void 0?null:r.value}function Hr(t,e){const n=tn(t,!0).delete(e);return new _t(n).toPromise()}const Xc=800,Qc=3;class ns{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await Vn(),this.db)}async _withRetries(e){let n=0;for(;;)try{const r=await this._openDb();return await e(r)}catch(r){if(n++>Qc)throw r;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return Qi()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=en._getInstance(Kc()),this.receiver._subscribe("keyChanged",async(e,n)=>({keyProcessed:(await this._poll()).includes(n.key)})),this.receiver._subscribe("ping",async(e,n)=>["keyChanged"])}async initializeSender(){var e,n;if(this.activeServiceWorker=await zc(),!this.activeServiceWorker)return;this.sender=new Wc(this.activeServiceWorker);const r=await this.sender._send("ping",{},800);r&&!((e=r[0])===null||e===void 0)&&e.fulfilled&&!((n=r[0])===null||n===void 0)&&n.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||Gc()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await Vn();return await jr(e,Fr,"1"),await Hr(e,Fr),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,n){return this._withPendingWrite(async()=>(await this._withRetries(r=>jr(r,e,n)),this.localCache[e]=n,this.notifyServiceWorker(e)))}async _get(e){const n=await this._withRetries(r=>Jc(r,e));return this.localCache[e]=n,n}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(n=>Hr(n,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(i=>{const s=tn(i,!1).getAll();return new _t(s).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const n=[],r=new Set;if(e.length!==0)for(const{fbase_key:i,value:s}of e)r.add(i),JSON.stringify(this.localCache[i])!==JSON.stringify(s)&&(this.notifyListeners(i,s),n.push(i));for(const i of Object.keys(this.localCache))this.localCache[i]&&!r.has(i)&&(this.notifyListeners(i,null),n.push(i));return n}notifyListeners(e,n){this.localCache[e]=n;const r=this.listeners[e];if(r)for(const i of Array.from(r))i(n)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),Xc)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,n){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(n)}_removeListener(e,n){this.listeners[e]&&(this.listeners[e].delete(n),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}ns.type="LOCAL";const rs=ns;var $r="@firebase/auth",Br="1.10.8";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let el=class{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)===null||e===void 0?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const n=this.auth.onIdTokenChanged(r=>{e((r==null?void 0:r.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,n),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const n=this.internalListeners.get(e);n&&(this.internalListeners.delete(e),n(),this.updateProactiveRefresh())}assertAuthConfigured(){N(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tl(t){switch(t){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function nl(t){Ne(new Ie("auth",(e,{options:n})=>{const r=e.getProvider("app").getImmediate(),i=e.getProvider("heartbeat"),s=e.getProvider("app-check-internal"),{apiKey:o,authDomain:a}=r.options;N(o&&!o.includes(":"),"invalid-api-key",{appName:r.name});const c={apiKey:o,authDomain:a,clientPlatform:t,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:Wi(t)},u=new pc(r,i,s,c);return bc(u,n),u},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,n,r)=>{e.getProvider("auth-internal").initialize()})),Ne(new Ie("auth-internal",e=>{const n=Ye(e.getProvider("auth").getImmediate());return(r=>new el(r))(n)},"PRIVATE").setInstantiationMode("EXPLICIT")),be($r,Br,tl(t)),be($r,Br,"esm2017")}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rl(t=ba()){const e=Ni(t,"auth");if(e.isInitialized())return e.getImmediate();const n=Ec(t,{persistence:[rs]}),r=lo("auth");return r&&Ic(n,`http://${r}`),n}nl("WebExtension");const il={apiKey:"AIzaSyDIs0Hg-lv01tdZd6w9Y4nYjNN34i3c8YM",authDomain:"task-assistant-project.firebaseapp.com",databaseURL:"https://task-assistant-project-default-rtdb.firebaseio.com",projectId:"task-assistant-project",storageBucket:"task-assistant-project.appspot.com",messagingSenderId:"1054146048463",appId:"1:1054146048463:web:280b00bd6de490868aa2ba"},sl=Li(il),te=rl(sl);Hc(te,rs).catch(t=>{console.error("Error setting persistence:",t)});const et={createUser:async(t,e,n)=>{try{const r=await Uc(te,t,e);return await jc(r.user,{displayName:n}),r.user}catch(r){throw console.error("Error during signup:",r),r}},signIn:async(t,e)=>{try{return(await Fc(te,t,e)).user}catch(n){throw console.error("Error during login:",n),n}},signOut:async()=>{try{await $c(te)}catch(t){throw console.error("Error during logout:",t),t}},getCurrentUser:()=>te.currentUser,getAuthToken:async()=>{console.log("Firebase: Getting auth token");const t=te.currentUser;if(t)try{console.log("Firebase: Current user found, getting fresh token");const e=await t.getIdToken(!0);if(e)return e;console.log("Firebase: Empty token received from getIdToken")}catch(e){return console.error("Firebase: Error getting token from current user:",e),""}return console.warn("Firebase: No authentication token available"),""},signInWithGoogleCredential:async t=>{try{const e=ce.credential(t),n=await qi(te,e);return console.log("Successfully signed in with Google credential:",n.user),n.user}catch(e){throw console.error("Error during Google credential login:",e),e}}},Me={MIXPANEL_TOKEN:"fcd8a519ebeab7a88e1dc2f5b3366dd7",MIXPANEL_API_URL:"https://api.mixpanel.com/track",MIXPANEL_ENGAGE_URL:"https://api.mixpanel.com/engage"};let Zr=null;const vn={setUserId:t=>{Zr=t},track:async(t,e)=>{try{const n={event:t,properties:{token:Me.MIXPANEL_TOKEN,time:Date.now(),distinct_id:Zr||"anonymous",...e}},r=await fetch(Me.MIXPANEL_API_URL,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`data=${encodeURIComponent(JSON.stringify(n))}`});r.ok||console.error("Mixpanel API error:",r.status,r.statusText)}catch(n){console.error("Mixpanel tracking error:",n)}},identify:async t=>{try{const e={event:"$identify",properties:{token:Me.MIXPANEL_TOKEN,time:Date.now(),distinct_id:t}},n=await fetch(Me.MIXPANEL_API_URL,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`data=${encodeURIComponent(JSON.stringify(e))}`});n.ok||console.error("Mixpanel identify API error:",n.status,n.statusText)}catch(e){console.error("Mixpanel identify error:",e)}},setUserProperties:async(t,e)=>{try{const n=[{$token:Me.MIXPANEL_TOKEN,$distinct_id:t,$set:e}],r=await fetch(Me.MIXPANEL_ENGAGE_URL,{method:"POST",headers:{accept:"text/plain","content-type":"application/json"},body:JSON.stringify(n)});r.ok||console.error("Mixpanel set user properties API error:",r.status,r.statusText)}catch(n){console.error("Mixpanel set user properties error:",n)}}},Wr={BASE_URL:"/",BROWSER:"firefox",CHROME:!1,COMMAND:"build",DEV:!1,EDGE:!1,ENTRYPOINT:"html",FIREFOX:!0,MANIFEST_VERSION:2,MODE:"production",OPERA:!1,PROD:!0,SAFARI:!1,SSR:!1},ft=new Map,St=t=>{const e=ft.get(t);return e?Object.fromEntries(Object.entries(e.stores).map(([n,r])=>[n,r.getState()])):{}},ol=(t,e,n)=>{if(t===void 0)return{type:"untracked",connection:e.connect(n)};const r=ft.get(n.name);if(r)return{type:"tracked",store:t,...r};const i={connection:e.connect(n),stores:{}};return ft.set(n.name,i),{type:"tracked",store:t,...i}},al=(t,e)=>{if(e===void 0)return;const n=ft.get(t);n&&(delete n.stores[e],Object.keys(n.stores).length===0&&ft.delete(t))},cl=t=>{var e,n;if(!t)return;const r=t.split(`
`),i=r.findIndex(o=>o.includes("api.setState"));if(i<0)return;const s=((e=r[i+1])==null?void 0:e.trim())||"";return(n=/.+ (.+) .+/.exec(s))==null?void 0:n[1]},ll=(t,e={})=>(n,r,i)=>{const{enabled:s,anonymousActionType:o,store:a,...c}=e;let u;try{u=(s??(Wr?"production":void 0)!=="production")&&window.__REDUX_DEVTOOLS_EXTENSION__}catch{}if(!u)return t(n,r,i);const{connection:h,...p}=ol(a,u,c);let f=!0;i.setState=(g,y,w)=>{const E=n(g,y);if(!f)return E;const v=w===void 0?{type:o||cl(new Error().stack)||"anonymous"}:typeof w=="string"?{type:w}:w;return a===void 0?(h==null||h.send(v,r()),E):(h==null||h.send({...v,type:`${a}/${v.type}`},{...St(c.name),[a]:i.getState()}),E)},i.devtools={cleanup:()=>{h&&typeof h.unsubscribe=="function"&&h.unsubscribe(),al(c.name,a)}};const m=(...g)=>{const y=f;f=!1,n(...g),f=y},_=t(i.setState,r,i);if(p.type==="untracked"?h==null||h.init(_):(p.stores[p.store]=i,h==null||h.init(Object.fromEntries(Object.entries(p.stores).map(([g,y])=>[g,g===p.store?_:y.getState()])))),i.dispatchFromDevtools&&typeof i.dispatch=="function"){let g=!1;const y=i.dispatch;i.dispatch=(...w)=>{(Wr?"production":void 0)!=="production"&&w[0].type==="__setState"&&!g&&(console.warn('[zustand devtools middleware] "__setState" action type is reserved to set state from the devtools. Avoid using it.'),g=!0),y(...w)}}return h.subscribe(g=>{var y;switch(g.type){case"ACTION":if(typeof g.payload!="string"){console.error("[zustand devtools middleware] Unsupported action format");return}return yn(g.payload,w=>{if(w.type==="__setState"){if(a===void 0){m(w.state);return}Object.keys(w.state).length!==1&&console.error(`
                    [zustand devtools middleware] Unsupported __setState action format.
                    When using 'store' option in devtools(), the 'state' should have only one key, which is a value of 'store' that was passed in devtools(),
                    and value of this only key should be a state object. Example: { "type": "__setState", "state": { "abc123Store": { "foo": "bar" } } }
                    `);const E=w.state[a];if(E==null)return;JSON.stringify(i.getState())!==JSON.stringify(E)&&m(E);return}i.dispatchFromDevtools&&typeof i.dispatch=="function"&&i.dispatch(w)});case"DISPATCH":switch(g.payload.type){case"RESET":return m(_),a===void 0?h==null?void 0:h.init(i.getState()):h==null?void 0:h.init(St(c.name));case"COMMIT":if(a===void 0){h==null||h.init(i.getState());return}return h==null?void 0:h.init(St(c.name));case"ROLLBACK":return yn(g.state,w=>{if(a===void 0){m(w),h==null||h.init(i.getState());return}m(w[a]),h==null||h.init(St(c.name))});case"JUMP_TO_STATE":case"JUMP_TO_ACTION":return yn(g.state,w=>{if(a===void 0){m(w);return}JSON.stringify(i.getState())!==JSON.stringify(w[a])&&m(w[a])});case"IMPORT_STATE":{const{nextLiftedState:w}=g.payload,E=(y=w.computedStates.slice(-1)[0])==null?void 0:y.state;if(!E)return;m(a===void 0?E:E[a]),h==null||h.send(null,w);return}case"PAUSE_RECORDING":return f=!f}return}}),_},ul=ll,yn=(t,e)=>{let n;try{n=JSON.parse(t)}catch(r){console.error("[zustand devtools middleware] Could not parse the received json",r)}n!==void 0&&e(n)},is=Xt()(ul((t,e)=>({currentView:"auth",viewHistory:[],isInitialized:!1,navigateTo:n=>{const{currentView:r}=e();r!==n&&t(i=>({currentView:n,viewHistory:[...i.viewHistory,r]}))},goBack:()=>{const{viewHistory:n}=e();if(n.length>0){const r=n[n.length-1];t(i=>({currentView:r,viewHistory:i.viewHistory.slice(0,-1)}))}},initialize:()=>{t({isInitialized:!0})},reset:()=>{t({currentView:"auth",viewHistory:[],isInitialized:!1})}}),{name:"PopupStore"})),We=Xt(t=>({user:void 0,isLoading:!1,error:null,signIn:async(e,n)=>{var r;t({isLoading:!0,error:null});try{const i=await et.signIn(e,n),s={email:i.email,name:i.displayName||((r=i.email)==null?void 0:r.split("@")[0])||"User",uid:i.uid};t({user:s,isLoading:!1})}catch(i){t({error:i.message||"Failed to sign in",isLoading:!1}),j.runtime.sendMessage({action:"sendMixpanelEvent",eventName:"signin_failure",eventParams:{method:"email_password",error:i.message||"Unknown error"}}).catch(console.error)}},signUp:async(e,n,r)=>{t({isLoading:!0,error:null});try{const i=await et.createUser(e,n,r),s={email:i.email,name:i.displayName||r,uid:i.uid};t({user:s,isLoading:!1})}catch(i){t({error:i.message||"Failed to sign up",isLoading:!1})}},signInWithGoogleCredential:async e=>{var n;t({isLoading:!0,error:null});try{const r=await et.signInWithGoogleCredential(e),i={email:r.email,name:r.displayName||((n=r.email)==null?void 0:n.split("@")[0])||"User",uid:r.uid};t({user:i,isLoading:!1})}catch(r){t({error:r.message||"Failed to sign in with Google",isLoading:!1}),j.runtime.sendMessage({action:"sendMixpanelEvent",eventName:"signin_failure",eventParams:{method:"google_credential",error:r.message||"Unknown error"}}).catch(console.error)}},signOut:async()=>{t({isLoading:!0,error:null});try{await et.signOut(),t({user:null,isLoading:!1}),is.getState().reset(),j.runtime.sendMessage({action:"sendMixpanelEvent",eventName:"signout_success"}).catch(console.error)}catch(e){t({error:e.message||"Failed to sign out",isLoading:!1}),j.runtime.sendMessage({action:"sendMixpanelEvent",eventName:"signout_failure",eventParams:{error:e.message||"Unknown error"}}).catch(console.error)}},getAuthToken:async()=>{try{const e=await et.getAuthToken();return console.log("[Yellow Popup]: Get auth token:",e.length),e}catch(e){return console.error("Failed to get auth token:",e),""}},clearError:()=>t({error:null})}));Xi(te,t=>{var e,n,r;if(t){const i={email:t.email,name:t.displayName||((e=t.email)==null?void 0:e.split("@")[0])||"User",uid:t.uid};We.setState({user:i}),vn.setUserId(t.uid),vn.identify(t.uid),vn.setUserProperties(t.uid,{$name:t.displayName||((n=t.email)==null?void 0:n.split("@")[0])||"User",$email:t.email}),j.runtime.sendMessage({action:"sendMixpanelEvent",eventName:"signin_success",eventParams:{method:"firebase_auth_state_change"}}).catch(console.error),t.uid&&t.email&&(console.log("[Yellow Auth]: Sending createUserProfile message for user:",t.uid),j.runtime.sendMessage({action:"createUserProfile",user:{uid:t.uid,email:t.email,displayName:t.displayName||((r=t.email)==null?void 0:r.split("@")[0])||"User"}}).then(s=>{console.log("[Yellow Auth]: createUserProfile response:",s)}).catch(s=>{console.error("[Yellow Auth]: Failed to create user profile:",s)}))}else We.setState({user:null})});const dl=new Promise((t,e)=>{j.runtime.sendMessage({action:"waitForAuthReady"},n=>{n.success?t(n.data.isReady):e(new Error(n.error))})}),tr=()=>{const{currentView:t,viewHistory:e,isInitialized:n,navigateTo:r,goBack:i,initialize:s,reset:o}=is();return{currentView:t,viewHistory:e,isInitialized:n,navigateTo:r,goBack:i,initialize:s,reset:o,canGoBack:e.length>0,isAuthView:t==="auth",isUserPanelView:t==="user-panel",isSubscriptionView:t==="subscription"}},hl=new Map([["bold",l.createElement(l.Fragment,null,l.createElement("path",{d:"M224.49,136.49l-72,72a12,12,0,0,1-17-17L187,140H40a12,12,0,0,1,0-24H187L135.51,64.48a12,12,0,0,1,17-17l72,72A12,12,0,0,1,224.49,136.49Z"}))],["duotone",l.createElement(l.Fragment,null,l.createElement("path",{d:"M216,128l-72,72V56Z",opacity:"0.2"}),l.createElement("path",{d:"M221.66,122.34l-72-72A8,8,0,0,0,136,56v64H40a8,8,0,0,0,0,16h96v64a8,8,0,0,0,13.66,5.66l72-72A8,8,0,0,0,221.66,122.34ZM152,180.69V75.31L204.69,128Z"}))],["fill",l.createElement(l.Fragment,null,l.createElement("path",{d:"M221.66,133.66l-72,72A8,8,0,0,1,136,200V136H40a8,8,0,0,1,0-16h96V56a8,8,0,0,1,13.66-5.66l72,72A8,8,0,0,1,221.66,133.66Z"}))],["light",l.createElement(l.Fragment,null,l.createElement("path",{d:"M220.24,132.24l-72,72a6,6,0,0,1-8.48-8.48L201.51,134H40a6,6,0,0,1,0-12H201.51L139.76,60.24a6,6,0,0,1,8.48-8.48l72,72A6,6,0,0,1,220.24,132.24Z"}))],["regular",l.createElement(l.Fragment,null,l.createElement("path",{d:"M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"}))],["thin",l.createElement(l.Fragment,null,l.createElement("path",{d:"M218.83,130.83l-72,72a4,4,0,0,1-5.66-5.66L206.34,132H40a4,4,0,0,1,0-8H206.34L141.17,58.83a4,4,0,0,1,5.66-5.66l72,72A4,4,0,0,1,218.83,130.83Z"}))]]),fl=new Map([["bold",l.createElement(l.Fragment,null,l.createElement("path",{d:"M208,28H188V24a12,12,0,0,0-24,0v4H92V24a12,12,0,0,0-24,0v4H48A20,20,0,0,0,28,48V208a20,20,0,0,0,20,20H208a20,20,0,0,0,20-20V48A20,20,0,0,0,208,28ZM68,52a12,12,0,0,0,24,0h72a12,12,0,0,0,24,0h16V76H52V52ZM52,204V100H204V204Zm60-80v56a12,12,0,0,1-24,0V143.32a12,12,0,0,1-9.37-22l16-8A12,12,0,0,1,112,124Zm61.49,33.88L163.9,168H168a12,12,0,0,1,0,24H136a12,12,0,0,1-8.71-20.25L155.45,142a4,4,0,0,0,.55-2,4,4,0,0,0-7.47-2,12,12,0,0,1-20.78-12A28,28,0,0,1,180,140a27.77,27.77,0,0,1-5.64,16.86A10.63,10.63,0,0,1,173.49,157.88Z"}))],["duotone",l.createElement(l.Fragment,null,l.createElement("path",{d:"M216,48V88H40V48a8,8,0,0,1,8-8H208A8,8,0,0,1,216,48Z",opacity:"0.2"}),l.createElement("path",{d:"M208,32H184V24a8,8,0,0,0-16,0v8H88V24a8,8,0,0,0-16,0v8H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM72,48v8a8,8,0,0,0,16,0V48h80v8a8,8,0,0,0,16,0V48h24V80H48V48ZM208,208H48V96H208V208Zm-96-88v64a8,8,0,0,1-16,0V132.94l-4.42,2.22a8,8,0,0,1-7.16-14.32l16-8A8,8,0,0,1,112,120Zm59.16,30.45L152,176h16a8,8,0,0,1,0,16H136a8,8,0,0,1-6.4-12.8l28.78-38.37A8,8,0,1,0,145.07,132a8,8,0,1,1-13.85-8A24,24,0,0,1,176,136,23.76,23.76,0,0,1,171.16,150.45Z"}))],["fill",l.createElement(l.Fragment,null,l.createElement("path",{d:"M208,32H184V24a8,8,0,0,0-16,0v8H88V24a8,8,0,0,0-16,0v8H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM112,184a8,8,0,0,1-16,0V132.94l-4.42,2.22a8,8,0,0,1-7.16-14.32l16-8A8,8,0,0,1,112,120Zm56-8a8,8,0,0,1,0,16H136a8,8,0,0,1-6.4-12.8l28.78-38.37A8,8,0,1,0,145.07,132a8,8,0,1,1-13.85-8A24,24,0,0,1,176,136a23.76,23.76,0,0,1-4.84,14.45L152,176ZM48,80V48H72v8a8,8,0,0,0,16,0V48h80v8a8,8,0,0,0,16,0V48h24V80Z"}))],["light",l.createElement(l.Fragment,null,l.createElement("path",{d:"M208,34H182V24a6,6,0,0,0-12,0V34H86V24a6,6,0,0,0-12,0V34H48A14,14,0,0,0,34,48V208a14,14,0,0,0,14,14H208a14,14,0,0,0,14-14V48A14,14,0,0,0,208,34ZM48,46H74V56a6,6,0,0,0,12,0V46h84V56a6,6,0,0,0,12,0V46h26a2,2,0,0,1,2,2V82H46V48A2,2,0,0,1,48,46ZM208,210H48a2,2,0,0,1-2-2V94H210V208A2,2,0,0,1,208,210Zm-98-90v64a6,6,0,0,1-12,0V129.71l-7.32,3.66a6,6,0,1,1-5.36-10.74l16-8A6,6,0,0,1,110,120Zm59.57,29.25L148,178h20a6,6,0,0,1,0,12H136a6,6,0,0,1-4.8-9.6L160,142a10,10,0,1,0-16.65-11A6,6,0,1,1,133,125a22,22,0,1,1,36.62,24.26Z"}))],["regular",l.createElement(l.Fragment,null,l.createElement("path",{d:"M208,32H184V24a8,8,0,0,0-16,0v8H88V24a8,8,0,0,0-16,0v8H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM72,48v8a8,8,0,0,0,16,0V48h80v8a8,8,0,0,0,16,0V48h24V80H48V48ZM208,208H48V96H208V208Zm-96-88v64a8,8,0,0,1-16,0V132.94l-4.42,2.22a8,8,0,0,1-7.16-14.32l16-8A8,8,0,0,1,112,120Zm59.16,30.45L152,176h16a8,8,0,0,1,0,16H136a8,8,0,0,1-6.4-12.8l28.78-38.37A8,8,0,1,0,145.07,132a8,8,0,1,1-13.85-8A24,24,0,0,1,176,136,23.76,23.76,0,0,1,171.16,150.45Z"}))],["thin",l.createElement(l.Fragment,null,l.createElement("path",{d:"M208,36H180V24a4,4,0,0,0-8,0V36H84V24a4,4,0,0,0-8,0V36H48A12,12,0,0,0,36,48V208a12,12,0,0,0,12,12H208a12,12,0,0,0,12-12V48A12,12,0,0,0,208,36ZM48,44H76V56a4,4,0,0,0,8,0V44h88V56a4,4,0,0,0,8,0V44h28a4,4,0,0,1,4,4V84H44V48A4,4,0,0,1,48,44ZM208,212H48a4,4,0,0,1-4-4V92H212V208A4,4,0,0,1,208,212ZM108,120v64a4,4,0,0,1-8,0V126.47l-10.21,5.11a4,4,0,0,1-3.58-7.16l16-8A4,4,0,0,1,108,120Zm60,28-24,32h24a4,4,0,0,1,0,8H136a4,4,0,0,1-3.2-6.4l28.78-38.37A11.88,11.88,0,0,0,164,136a12,12,0,0,0-22.4-6,4,4,0,0,1-6.92-4A20,20,0,0,1,172,136,19.79,19.79,0,0,1,168,148Z"}))]]),pl=new Map([["bold",l.createElement(l.Fragment,null,l.createElement("path",{d:"M168.49,199.51a12,12,0,0,1-17,17l-80-80a12,12,0,0,1,0-17l80-80a12,12,0,0,1,17,17L97,128Z"}))],["duotone",l.createElement(l.Fragment,null,l.createElement("path",{d:"M160,48V208L80,128Z",opacity:"0.2"}),l.createElement("path",{d:"M163.06,40.61a8,8,0,0,0-8.72,1.73l-80,80a8,8,0,0,0,0,11.32l80,80A8,8,0,0,0,168,208V48A8,8,0,0,0,163.06,40.61ZM152,188.69,91.31,128,152,67.31Z"}))],["fill",l.createElement(l.Fragment,null,l.createElement("path",{d:"M168,48V208a8,8,0,0,1-13.66,5.66l-80-80a8,8,0,0,1,0-11.32l80-80A8,8,0,0,1,168,48Z"}))],["light",l.createElement(l.Fragment,null,l.createElement("path",{d:"M164.24,203.76a6,6,0,1,1-8.48,8.48l-80-80a6,6,0,0,1,0-8.48l80-80a6,6,0,0,1,8.48,8.48L88.49,128Z"}))],["regular",l.createElement(l.Fragment,null,l.createElement("path",{d:"M165.66,202.34a8,8,0,0,1-11.32,11.32l-80-80a8,8,0,0,1,0-11.32l80-80a8,8,0,0,1,11.32,11.32L91.31,128Z"}))],["thin",l.createElement(l.Fragment,null,l.createElement("path",{d:"M162.83,205.17a4,4,0,0,1-5.66,5.66l-80-80a4,4,0,0,1,0-5.66l80-80a4,4,0,1,1,5.66,5.66L85.66,128Z"}))]]),ml=new Map([["bold",l.createElement(l.Fragment,null,l.createElement("path",{d:"M232.49,80.49l-128,128a12,12,0,0,1-17,0l-56-56a12,12,0,1,1,17-17L96,183,215.51,63.51a12,12,0,0,1,17,17Z"}))],["duotone",l.createElement(l.Fragment,null,l.createElement("path",{d:"M232,56V200a16,16,0,0,1-16,16H40a16,16,0,0,1-16-16V56A16,16,0,0,1,40,40H216A16,16,0,0,1,232,56Z",opacity:"0.2"}),l.createElement("path",{d:"M205.66,85.66l-96,96a8,8,0,0,1-11.32,0l-40-40a8,8,0,0,1,11.32-11.32L104,164.69l90.34-90.35a8,8,0,0,1,11.32,11.32Z"}))],["fill",l.createElement(l.Fragment,null,l.createElement("path",{d:"M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40ZM205.66,85.66l-96,96a8,8,0,0,1-11.32,0l-40-40a8,8,0,0,1,11.32-11.32L104,164.69l90.34-90.35a8,8,0,0,1,11.32,11.32Z"}))],["light",l.createElement(l.Fragment,null,l.createElement("path",{d:"M228.24,76.24l-128,128a6,6,0,0,1-8.48,0l-56-56a6,6,0,0,1,8.48-8.48L96,191.51,219.76,67.76a6,6,0,0,1,8.48,8.48Z"}))],["regular",l.createElement(l.Fragment,null,l.createElement("path",{d:"M229.66,77.66l-128,128a8,8,0,0,1-11.32,0l-56-56a8,8,0,0,1,11.32-11.32L96,188.69,218.34,66.34a8,8,0,0,1,11.32,11.32Z"}))],["thin",l.createElement(l.Fragment,null,l.createElement("path",{d:"M226.83,74.83l-128,128a4,4,0,0,1-5.66,0l-56-56a4,4,0,0,1,5.66-5.66L96,194.34,221.17,69.17a4,4,0,1,1,5.66,5.66Z"}))]]),gl=new Map([["bold",l.createElement(l.Fragment,null,l.createElement("path",{d:"M224.15,179.17l-46.83-46.82,37.93-13.51.76-.3a20,20,0,0,0-1.76-37.27L54.16,29A20,20,0,0,0,29,54.16L81.27,214.24A20,20,0,0,0,118.54,216c.11-.25.21-.5.3-.76l13.51-37.92,46.83,46.82a20,20,0,0,0,28.28,0l16.69-16.68A20,20,0,0,0,224.15,179.17Zm-30.83,25.17-48.48-48.48A20,20,0,0,0,130.7,150a20.66,20.66,0,0,0-3.74.35A20,20,0,0,0,112.35,162c-.11.25-.21.5-.3.76L100.4,195.5,54.29,54.29l141.21,46.1-32.71,11.66c-.26.09-.51.19-.76.3a20,20,0,0,0-6.17,32.48h0l48.49,48.48Z"}))],["duotone",l.createElement(l.Fragment,null,l.createElement("path",{d:"M213.66,201,201,213.66a8,8,0,0,1-11.31,0l-51.31-51.31a8,8,0,0,0-13,2.46l-17.82,46.41a8,8,0,0,1-14.85-.71L40.41,50.44a8,8,0,0,1,10-10L210.51,92.68a8,8,0,0,1,.71,14.85l-46.41,17.82a8,8,0,0,0-2.46,13l51.31,51.31A8,8,0,0,1,213.66,201Z",opacity:"0.2"}),l.createElement("path",{d:"M168,132.69,214.08,115l.33-.13A16,16,0,0,0,213,85.07L52.92,32.8A15.95,15.95,0,0,0,32.8,52.92L85.07,213a15.82,15.82,0,0,0,14.41,11l.78,0a15.84,15.84,0,0,0,14.61-9.59l.13-.33L132.69,168,184,219.31a16,16,0,0,0,22.63,0l12.68-12.68a16,16,0,0,0,0-22.63ZM195.31,208,144,156.69a16,16,0,0,0-26,4.93c0,.11-.09.22-.13.32l-17.65,46L48,48l159.85,52.2-45.95,17.64-.32.13a16,16,0,0,0-4.93,26h0L208,195.31Z"}))],["fill",l.createElement(l.Fragment,null,l.createElement("path",{d:"M220.49,207.8,207.8,220.49a12,12,0,0,1-17,0l-56.57-56.57L115,214.08l-.13.33A15.84,15.84,0,0,1,100.26,224l-.78,0a15.82,15.82,0,0,1-14.41-11L32.8,52.92A15.95,15.95,0,0,1,52.92,32.8L213,85.07a16,16,0,0,1,1.41,29.8l-.33.13-50.16,19.27,56.57,56.56A12,12,0,0,1,220.49,207.8Z"}))],["light",l.createElement(l.Fragment,null,l.createElement("path",{d:"M166.59,134.1a1.91,1.91,0,0,1-.55-1.79,2,2,0,0,1,1.08-1.42l46.25-17.76.24-.1A14,14,0,0,0,212.38,87L52.29,34.7A13.95,13.95,0,0,0,34.7,52.29L87,212.38a13.82,13.82,0,0,0,12.6,9.6c.23,0,.46,0,.69,0A13.84,13.84,0,0,0,113,213.61a2.44,2.44,0,0,0,.1-.24l17.76-46.25a2,2,0,0,1,3.21-.53l51.31,51.31a14,14,0,0,0,19.8,0l12.69-12.69a14,14,0,0,0,0-19.8Zm42.82,62.63-12.68,12.68a2,2,0,0,1-2.83,0L142.59,158.1a14,14,0,0,0-22.74,4.32,2.44,2.44,0,0,0-.1.24L102,208.91a2,2,0,0,1-3.61-.26L46.11,48.57a1.87,1.87,0,0,1,.47-2A1.92,1.92,0,0,1,47.93,46a2.22,2.22,0,0,1,.64.1L208.65,98.38a2,2,0,0,1,.26,3.61l-46.25,17.76-.24.1a14,14,0,0,0-4.32,22.74h0l51.31,51.31A2,2,0,0,1,209.41,196.73Z"}))],["regular",l.createElement(l.Fragment,null,l.createElement("path",{d:"M168,132.69,214.08,115l.33-.13A16,16,0,0,0,213,85.07L52.92,32.8A15.95,15.95,0,0,0,32.8,52.92L85.07,213a15.82,15.82,0,0,0,14.41,11l.78,0a15.84,15.84,0,0,0,14.61-9.59l.13-.33L132.69,168,184,219.31a16,16,0,0,0,22.63,0l12.68-12.68a16,16,0,0,0,0-22.63ZM195.31,208,144,156.69a16,16,0,0,0-26,4.93c0,.11-.09.22-.13.32l-17.65,46L48,48l159.85,52.2-45.95,17.64-.32.13a16,16,0,0,0-4.93,26h0L208,195.31Z"}))],["thin",l.createElement(l.Fragment,null,l.createElement("path",{d:"M165.17,135.51a4,4,0,0,1,1.17-6.46l46.31-17.79.16-.06a12,12,0,0,0-1.05-22.33L51.67,36.6A12,12,0,0,0,36.6,51.67L88.87,211.76A11.86,11.86,0,0,0,99.67,220h.58a11.86,11.86,0,0,0,11-7.19l.06-.16,17.79-46.31a4,4,0,0,1,6.47-1.17l51.31,51.32a12,12,0,0,0,17,0l12.69-12.69a12,12,0,0,0,0-17Zm45.66,62.63-12.69,12.69a4,4,0,0,1-5.66,0l-51.31-51.31a12,12,0,0,0-8.48-3.52,12.13,12.13,0,0,0-2.24.21,12,12,0,0,0-8.77,7l-.06.16-17.79,46.31a4,4,0,0,1-7.36-.42L44.2,49.19a4,4,0,0,1,5-5L209.27,96.47a4,4,0,0,1,.42,7.36l-46.31,17.78-.16.07a12,12,0,0,0-3.71,19.49l51.32,51.31A4,4,0,0,1,210.83,198.14Z"}))]]),vl=new Map([["bold",l.createElement(l.Fragment,null,l.createElement("path",{d:"M108,84a16,16,0,1,1,16,16A16,16,0,0,1,108,84Zm128,44A108,108,0,1,1,128,20,108.12,108.12,0,0,1,236,128Zm-24,0a84,84,0,1,0-84,84A84.09,84.09,0,0,0,212,128Zm-72,36.68V132a20,20,0,0,0-20-20,12,12,0,0,0-4,23.32V168a20,20,0,0,0,20,20,12,12,0,0,0,4-23.32Z"}))],["duotone",l.createElement(l.Fragment,null,l.createElement("path",{d:"M224,128a96,96,0,1,1-96-96A96,96,0,0,1,224,128Z",opacity:"0.2"}),l.createElement("path",{d:"M144,176a8,8,0,0,1-8,8,16,16,0,0,1-16-16V128a8,8,0,0,1,0-16,16,16,0,0,1,16,16v40A8,8,0,0,1,144,176Zm88-48A104,104,0,1,1,128,24,104.11,104.11,0,0,1,232,128Zm-16,0a88,88,0,1,0-88,88A88.1,88.1,0,0,0,216,128ZM124,96a12,12,0,1,0-12-12A12,12,0,0,0,124,96Z"}))],["fill",l.createElement(l.Fragment,null,l.createElement("path",{d:"M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm-4,48a12,12,0,1,1-12,12A12,12,0,0,1,124,72Zm12,112a16,16,0,0,1-16-16V128a8,8,0,0,1,0-16,16,16,0,0,1,16,16v40a8,8,0,0,1,0,16Z"}))],["light",l.createElement(l.Fragment,null,l.createElement("path",{d:"M142,176a6,6,0,0,1-6,6,14,14,0,0,1-14-14V128a2,2,0,0,0-2-2,6,6,0,0,1,0-12,14,14,0,0,1,14,14v40a2,2,0,0,0,2,2A6,6,0,0,1,142,176ZM124,94a10,10,0,1,0-10-10A10,10,0,0,0,124,94Zm106,34A102,102,0,1,1,128,26,102.12,102.12,0,0,1,230,128Zm-12,0a90,90,0,1,0-90,90A90.1,90.1,0,0,0,218,128Z"}))],["regular",l.createElement(l.Fragment,null,l.createElement("path",{d:"M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm16-40a8,8,0,0,1-8,8,16,16,0,0,1-16-16V128a8,8,0,0,1,0-16,16,16,0,0,1,16,16v40A8,8,0,0,1,144,176ZM112,84a12,12,0,1,1,12,12A12,12,0,0,1,112,84Z"}))],["thin",l.createElement(l.Fragment,null,l.createElement("path",{d:"M140,176a4,4,0,0,1-4,4,12,12,0,0,1-12-12V128a4,4,0,0,0-4-4,4,4,0,0,1,0-8,12,12,0,0,1,12,12v40a4,4,0,0,0,4,4A4,4,0,0,1,140,176ZM124,92a8,8,0,1,0-8-8A8,8,0,0,0,124,92Zm104,36A100,100,0,1,1,128,28,100.11,100.11,0,0,1,228,128Zm-8,0a92,92,0,1,0-92,92A92.1,92.1,0,0,0,220,128Z"}))]]),yl=new Map([["bold",l.createElement(l.Fragment,null,l.createElement("path",{d:"M199,125.31l-49.88-18.39L130.69,57a19.92,19.92,0,0,0-37.38,0L74.92,106.92,25,125.31a19.92,19.92,0,0,0,0,37.38l49.88,18.39L93.31,231a19.92,19.92,0,0,0,37.38,0l18.39-49.88L199,162.69a19.92,19.92,0,0,0,0-37.38Zm-63.38,35.16a12,12,0,0,0-7.11,7.11L112,212.28l-16.47-44.7a12,12,0,0,0-7.11-7.11L43.72,144l44.7-16.47a12,12,0,0,0,7.11-7.11L112,75.72l16.47,44.7a12,12,0,0,0,7.11,7.11L180.28,144ZM140,40a12,12,0,0,1,12-12h12V16a12,12,0,0,1,24,0V28h12a12,12,0,0,1,0,24H188V64a12,12,0,0,1-24,0V52H152A12,12,0,0,1,140,40ZM252,88a12,12,0,0,1-12,12h-4v4a12,12,0,0,1-24,0v-4h-4a12,12,0,0,1,0-24h4V72a12,12,0,0,1,24,0v4h4A12,12,0,0,1,252,88Z"}))],["duotone",l.createElement(l.Fragment,null,l.createElement("path",{d:"M194.82,151.43l-55.09,20.3-20.3,55.09a7.92,7.92,0,0,1-14.86,0l-20.3-55.09-55.09-20.3a7.92,7.92,0,0,1,0-14.86l55.09-20.3,20.3-55.09a7.92,7.92,0,0,1,14.86,0l20.3,55.09,55.09,20.3A7.92,7.92,0,0,1,194.82,151.43Z",opacity:"0.2"}),l.createElement("path",{d:"M197.58,129.06,146,110l-19-51.62a15.92,15.92,0,0,0-29.88,0L78,110l-51.62,19a15.92,15.92,0,0,0,0,29.88L78,178l19,51.62a15.92,15.92,0,0,0,29.88,0L146,178l51.62-19a15.92,15.92,0,0,0,0-29.88ZM137,164.22a8,8,0,0,0-4.74,4.74L112,223.85,91.78,169A8,8,0,0,0,87,164.22L32.15,144,87,123.78A8,8,0,0,0,91.78,119L112,64.15,132.22,119a8,8,0,0,0,4.74,4.74L191.85,144ZM144,40a8,8,0,0,1,8-8h16V16a8,8,0,0,1,16,0V32h16a8,8,0,0,1,0,16H184V64a8,8,0,0,1-16,0V48H152A8,8,0,0,1,144,40ZM248,88a8,8,0,0,1-8,8h-8v8a8,8,0,0,1-16,0V96h-8a8,8,0,0,1,0-16h8V72a8,8,0,0,1,16,0v8h8A8,8,0,0,1,248,88Z"}))],["fill",l.createElement(l.Fragment,null,l.createElement("path",{d:"M208,144a15.78,15.78,0,0,1-10.42,14.94L146,178l-19,51.62a15.92,15.92,0,0,1-29.88,0L78,178l-51.62-19a15.92,15.92,0,0,1,0-29.88L78,110l19-51.62a15.92,15.92,0,0,1,29.88,0L146,110l51.62,19A15.78,15.78,0,0,1,208,144ZM152,48h16V64a8,8,0,0,0,16,0V48h16a8,8,0,0,0,0-16H184V16a8,8,0,0,0-16,0V32H152a8,8,0,0,0,0,16Zm88,32h-8V72a8,8,0,0,0-16,0v8h-8a8,8,0,0,0,0,16h8v8a8,8,0,0,0,16,0V96h8a8,8,0,0,0,0-16Z"}))],["light",l.createElement(l.Fragment,null,l.createElement("path",{d:"M196.89,130.94,144.4,111.6,125.06,59.11a13.92,13.92,0,0,0-26.12,0L79.6,111.6,27.11,130.94a13.92,13.92,0,0,0,0,26.12L79.6,176.4l19.34,52.49a13.92,13.92,0,0,0,26.12,0L144.4,176.4l52.49-19.34a13.92,13.92,0,0,0,0-26.12Zm-4.15,14.86-55.08,20.3a6,6,0,0,0-3.56,3.56l-20.3,55.08a1.92,1.92,0,0,1-3.6,0L89.9,169.66a6,6,0,0,0-3.56-3.56L31.26,145.8a1.92,1.92,0,0,1,0-3.6l55.08-20.3a6,6,0,0,0,3.56-3.56l20.3-55.08a1.92,1.92,0,0,1,3.6,0l20.3,55.08a6,6,0,0,0,3.56,3.56l55.08,20.3a1.92,1.92,0,0,1,0,3.6ZM146,40a6,6,0,0,1,6-6h18V16a6,6,0,0,1,12,0V34h18a6,6,0,0,1,0,12H182V64a6,6,0,0,1-12,0V46H152A6,6,0,0,1,146,40ZM246,88a6,6,0,0,1-6,6H230v10a6,6,0,0,1-12,0V94H208a6,6,0,0,1,0-12h10V72a6,6,0,0,1,12,0V82h10A6,6,0,0,1,246,88Z"}))],["regular",l.createElement(l.Fragment,null,l.createElement("path",{d:"M197.58,129.06,146,110l-19-51.62a15.92,15.92,0,0,0-29.88,0L78,110l-51.62,19a15.92,15.92,0,0,0,0,29.88L78,178l19,51.62a15.92,15.92,0,0,0,29.88,0L146,178l51.62-19a15.92,15.92,0,0,0,0-29.88ZM137,164.22a8,8,0,0,0-4.74,4.74L112,223.85,91.78,169A8,8,0,0,0,87,164.22L32.15,144,87,123.78A8,8,0,0,0,91.78,119L112,64.15,132.22,119a8,8,0,0,0,4.74,4.74L191.85,144ZM144,40a8,8,0,0,1,8-8h16V16a8,8,0,0,1,16,0V32h16a8,8,0,0,1,0,16H184V64a8,8,0,0,1-16,0V48H152A8,8,0,0,1,144,40ZM248,88a8,8,0,0,1-8,8h-8v8a8,8,0,0,1-16,0V96h-8a8,8,0,0,1,0-16h8V72a8,8,0,0,1,16,0v8h8A8,8,0,0,1,248,88Z"}))],["thin",l.createElement(l.Fragment,null,l.createElement("path",{d:"M196.2,132.81l-53.36-19.65L123.19,59.8a11.93,11.93,0,0,0-22.38,0L81.16,113.16,27.8,132.81a11.93,11.93,0,0,0,0,22.38l53.36,19.65,19.65,53.36a11.93,11.93,0,0,0,22.38,0l19.65-53.36,53.36-19.65a11.93,11.93,0,0,0,0-22.38Zm-2.77,14.87L138.35,168a4,4,0,0,0-2.37,2.37l-20.3,55.08a3.92,3.92,0,0,1-7.36,0L88,170.35A4,4,0,0,0,85.65,168l-55.08-20.3a3.92,3.92,0,0,1,0-7.36L85.65,120A4,4,0,0,0,88,117.65l20.3-55.08a3.92,3.92,0,0,1,7.36,0L136,117.65a4,4,0,0,0,2.37,2.37l55.08,20.3a3.92,3.92,0,0,1,0,7.36ZM148,40a4,4,0,0,1,4-4h20V16a4,4,0,0,1,8,0V36h20a4,4,0,0,1,0,8H180V64a4,4,0,0,1-8,0V44H152A4,4,0,0,1,148,40Zm96,48a4,4,0,0,1-4,4H228v12a4,4,0,0,1-8,0V92H208a4,4,0,0,1,0-8h12V72a4,4,0,0,1,8,0V84h12A4,4,0,0,1,244,88Z"}))]]),_l=new Map([["bold",l.createElement(l.Fragment,null,l.createElement("path",{d:"M140,32V64a12,12,0,0,1-24,0V32a12,12,0,0,1,24,0Zm33.25,62.75a12,12,0,0,0,8.49-3.52L204.37,68.6a12,12,0,0,0-17-17L164.77,74.26a12,12,0,0,0,8.48,20.49ZM224,116H192a12,12,0,0,0,0,24h32a12,12,0,0,0,0-24Zm-42.26,48.77a12,12,0,1,0-17,17l22.63,22.63a12,12,0,0,0,17-17ZM128,180a12,12,0,0,0-12,12v32a12,12,0,0,0,24,0V192A12,12,0,0,0,128,180ZM74.26,164.77,51.63,187.4a12,12,0,0,0,17,17l22.63-22.63a12,12,0,1,0-17-17ZM76,128a12,12,0,0,0-12-12H32a12,12,0,0,0,0,24H64A12,12,0,0,0,76,128ZM68.6,51.63a12,12,0,1,0-17,17L74.26,91.23a12,12,0,0,0,17-17Z"}))],["duotone",l.createElement(l.Fragment,null,l.createElement("path",{d:"M224,128a96,96,0,1,1-96-96A96,96,0,0,1,224,128Z",opacity:"0.2"}),l.createElement("path",{d:"M136,32V64a8,8,0,0,1-16,0V32a8,8,0,0,1,16,0Zm37.25,58.75a8,8,0,0,0,5.66-2.35l22.63-22.62a8,8,0,0,0-11.32-11.32L167.6,77.09a8,8,0,0,0,5.65,13.66ZM224,120H192a8,8,0,0,0,0,16h32a8,8,0,0,0,0-16Zm-45.09,47.6a8,8,0,0,0-11.31,11.31l22.62,22.63a8,8,0,0,0,11.32-11.32ZM128,184a8,8,0,0,0-8,8v32a8,8,0,0,0,16,0V192A8,8,0,0,0,128,184ZM77.09,167.6,54.46,190.22a8,8,0,0,0,11.32,11.32L88.4,178.91A8,8,0,0,0,77.09,167.6ZM72,128a8,8,0,0,0-8-8H32a8,8,0,0,0,0,16H64A8,8,0,0,0,72,128ZM65.78,54.46A8,8,0,0,0,54.46,65.78L77.09,88.4A8,8,0,0,0,88.4,77.09Z"}))],["fill",l.createElement(l.Fragment,null,l.createElement("path",{d:"M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm33.94,58.75,17-17a8,8,0,0,1,11.32,11.32l-17,17a8,8,0,0,1-11.31-11.31ZM48,136a8,8,0,0,1,0-16H72a8,8,0,0,1,0,16Zm46.06,37.25-17,17a8,8,0,0,1-11.32-11.32l17-17a8,8,0,0,1,11.31,11.31Zm0-79.19a8,8,0,0,1-11.31,0l-17-17A8,8,0,0,1,77.09,65.77l17,17A8,8,0,0,1,94.06,94.06ZM136,208a8,8,0,0,1-16,0V184a8,8,0,0,1,16,0Zm0-136a8,8,0,0,1-16,0V48a8,8,0,0,1,16,0Zm54.23,118.23a8,8,0,0,1-11.32,0l-17-17a8,8,0,0,1,11.31-11.31l17,17A8,8,0,0,1,190.23,190.23ZM208,136H184a8,8,0,0,1,0-16h24a8,8,0,0,1,0,16Z"}))],["light",l.createElement(l.Fragment,null,l.createElement("path",{d:"M134,32V64a6,6,0,0,1-12,0V32a6,6,0,0,1,12,0Zm39.25,56.75A6,6,0,0,0,177.5,87l22.62-22.63a6,6,0,0,0-8.48-8.48L169,78.5a6,6,0,0,0,4.24,10.25ZM224,122H192a6,6,0,0,0,0,12h32a6,6,0,0,0,0-12Zm-46.5,47A6,6,0,0,0,169,177.5l22.63,22.62a6,6,0,0,0,8.48-8.48ZM128,186a6,6,0,0,0-6,6v32a6,6,0,0,0,12,0V192A6,6,0,0,0,128,186ZM78.5,169,55.88,191.64a6,6,0,1,0,8.48,8.48L87,177.5A6,6,0,1,0,78.5,169ZM70,128a6,6,0,0,0-6-6H32a6,6,0,0,0,0,12H64A6,6,0,0,0,70,128ZM64.36,55.88a6,6,0,0,0-8.48,8.48L78.5,87A6,6,0,1,0,87,78.5Z"}))],["regular",l.createElement(l.Fragment,null,l.createElement("path",{d:"M136,32V64a8,8,0,0,1-16,0V32a8,8,0,0,1,16,0Zm37.25,58.75a8,8,0,0,0,5.66-2.35l22.63-22.62a8,8,0,0,0-11.32-11.32L167.6,77.09a8,8,0,0,0,5.65,13.66ZM224,120H192a8,8,0,0,0,0,16h32a8,8,0,0,0,0-16Zm-45.09,47.6a8,8,0,0,0-11.31,11.31l22.62,22.63a8,8,0,0,0,11.32-11.32ZM128,184a8,8,0,0,0-8,8v32a8,8,0,0,0,16,0V192A8,8,0,0,0,128,184ZM77.09,167.6,54.46,190.22a8,8,0,0,0,11.32,11.32L88.4,178.91A8,8,0,0,0,77.09,167.6ZM72,128a8,8,0,0,0-8-8H32a8,8,0,0,0,0,16H64A8,8,0,0,0,72,128ZM65.78,54.46A8,8,0,0,0,54.46,65.78L77.09,88.4A8,8,0,0,0,88.4,77.09Z"}))],["thin",l.createElement(l.Fragment,null,l.createElement("path",{d:"M132,32V64a4,4,0,0,1-8,0V32a4,4,0,0,1,8,0Zm41.25,54.75a4,4,0,0,0,2.83-1.18L198.71,63a4,4,0,0,0-5.66-5.66L170.43,79.92a4,4,0,0,0,2.82,6.83ZM224,124H192a4,4,0,0,0,0,8h32a4,4,0,0,0,0-8Zm-47.92,46.43a4,4,0,1,0-5.65,5.65l22.62,22.63a4,4,0,0,0,5.66-5.66ZM128,188a4,4,0,0,0-4,4v32a4,4,0,0,0,8,0V192A4,4,0,0,0,128,188ZM79.92,170.43,57.29,193.05A4,4,0,0,0,63,198.71l22.62-22.63a4,4,0,1,0-5.65-5.65ZM68,128a4,4,0,0,0-4-4H32a4,4,0,0,0,0,8H64A4,4,0,0,0,68,128ZM63,57.29A4,4,0,0,0,57.29,63L79.92,85.57a4,4,0,1,0,5.65-5.65Z"}))]]),wl=new Map([["bold",l.createElement(l.Fragment,null,l.createElement("path",{d:"M240.26,186.1,152.81,34.23h0a28.74,28.74,0,0,0-49.62,0L15.74,186.1a27.45,27.45,0,0,0,0,27.71A28.31,28.31,0,0,0,40.55,228h174.9a28.31,28.31,0,0,0,24.79-14.19A27.45,27.45,0,0,0,240.26,186.1Zm-20.8,15.7a4.46,4.46,0,0,1-4,2.2H40.55a4.46,4.46,0,0,1-4-2.2,3.56,3.56,0,0,1,0-3.73L124,46.2a4.77,4.77,0,0,1,8,0l87.44,151.87A3.56,3.56,0,0,1,219.46,201.8ZM116,136V104a12,12,0,0,1,24,0v32a12,12,0,0,1-24,0Zm28,40a16,16,0,1,1-16-16A16,16,0,0,1,144,176Z"}))],["duotone",l.createElement(l.Fragment,null,l.createElement("path",{d:"M215.46,216H40.54C27.92,216,20,202.79,26.13,192.09L113.59,40.22c6.3-11,22.52-11,28.82,0l87.46,151.87C236,202.79,228.08,216,215.46,216Z",opacity:"0.2"}),l.createElement("path",{d:"M236.8,188.09,149.35,36.22h0a24.76,24.76,0,0,0-42.7,0L19.2,188.09a23.51,23.51,0,0,0,0,23.72A24.35,24.35,0,0,0,40.55,224h174.9a24.35,24.35,0,0,0,21.33-12.19A23.51,23.51,0,0,0,236.8,188.09ZM222.93,203.8a8.5,8.5,0,0,1-7.48,4.2H40.55a8.5,8.5,0,0,1-7.48-4.2,7.59,7.59,0,0,1,0-7.72L120.52,44.21a8.75,8.75,0,0,1,15,0l87.45,151.87A7.59,7.59,0,0,1,222.93,203.8ZM120,144V104a8,8,0,0,1,16,0v40a8,8,0,0,1-16,0Zm20,36a12,12,0,1,1-12-12A12,12,0,0,1,140,180Z"}))],["fill",l.createElement(l.Fragment,null,l.createElement("path",{d:"M236.8,188.09,149.35,36.22h0a24.76,24.76,0,0,0-42.7,0L19.2,188.09a23.51,23.51,0,0,0,0,23.72A24.35,24.35,0,0,0,40.55,224h174.9a24.35,24.35,0,0,0,21.33-12.19A23.51,23.51,0,0,0,236.8,188.09ZM120,104a8,8,0,0,1,16,0v40a8,8,0,0,1-16,0Zm8,88a12,12,0,1,1,12-12A12,12,0,0,1,128,192Z"}))],["light",l.createElement(l.Fragment,null,l.createElement("path",{d:"M235.07,189.09,147.61,37.22h0a22.75,22.75,0,0,0-39.22,0L20.93,189.09a21.53,21.53,0,0,0,0,21.72A22.35,22.35,0,0,0,40.55,222h174.9a22.35,22.35,0,0,0,19.6-11.19A21.53,21.53,0,0,0,235.07,189.09ZM224.66,204.8a10.46,10.46,0,0,1-9.21,5.2H40.55a10.46,10.46,0,0,1-9.21-5.2,9.51,9.51,0,0,1,0-9.72L118.79,43.21a10.75,10.75,0,0,1,18.42,0l87.46,151.87A9.51,9.51,0,0,1,224.66,204.8ZM122,144V104a6,6,0,0,1,12,0v40a6,6,0,0,1-12,0Zm16,36a10,10,0,1,1-10-10A10,10,0,0,1,138,180Z"}))],["regular",l.createElement(l.Fragment,null,l.createElement("path",{d:"M236.8,188.09,149.35,36.22h0a24.76,24.76,0,0,0-42.7,0L19.2,188.09a23.51,23.51,0,0,0,0,23.72A24.35,24.35,0,0,0,40.55,224h174.9a24.35,24.35,0,0,0,21.33-12.19A23.51,23.51,0,0,0,236.8,188.09ZM222.93,203.8a8.5,8.5,0,0,1-7.48,4.2H40.55a8.5,8.5,0,0,1-7.48-4.2,7.59,7.59,0,0,1,0-7.72L120.52,44.21a8.75,8.75,0,0,1,15,0l87.45,151.87A7.59,7.59,0,0,1,222.93,203.8ZM120,144V104a8,8,0,0,1,16,0v40a8,8,0,0,1-16,0Zm20,36a12,12,0,1,1-12-12A12,12,0,0,1,140,180Z"}))],["thin",l.createElement(l.Fragment,null,l.createElement("path",{d:"M233.34,190.09,145.88,38.22h0a20.75,20.75,0,0,0-35.76,0L22.66,190.09a19.52,19.52,0,0,0,0,19.71A20.36,20.36,0,0,0,40.54,220H215.46a20.36,20.36,0,0,0,17.86-10.2A19.52,19.52,0,0,0,233.34,190.09ZM226.4,205.8a12.47,12.47,0,0,1-10.94,6.2H40.54a12.47,12.47,0,0,1-10.94-6.2,11.45,11.45,0,0,1,0-11.72L117.05,42.21a12.76,12.76,0,0,1,21.9,0L226.4,194.08A11.45,11.45,0,0,1,226.4,205.8ZM124,144V104a4,4,0,0,1,8,0v40a4,4,0,0,1-8,0Zm12,36a8,8,0,1,1-8-8A8,8,0,0,1,136,180Z"}))]]),El=l.createContext({color:"currentColor",size:"1em",weight:"regular",mirrored:!1}),oe=l.forwardRef((t,e)=>{const{alt:n,color:r,size:i,weight:s,mirrored:o,children:a,weights:c,...u}=t,{color:h="currentColor",size:p,weight:f="regular",mirrored:m=!1,..._}=l.useContext(El);return l.createElement("svg",{ref:e,xmlns:"http://www.w3.org/2000/svg",width:i??p,height:i??p,fill:r??h,viewBox:"0 0 256 256",transform:o||m?"scale(-1, 1)":void 0,..._,...u},!!n&&l.createElement("title",null,n),a,c.get(s??f))});oe.displayName="IconBase";const ss=l.forwardRef((t,e)=>l.createElement(oe,{ref:e,...t,weights:hl}));ss.displayName="ArrowRightIcon";const os=l.forwardRef((t,e)=>l.createElement(oe,{ref:e,...t,weights:fl}));os.displayName="CalendarIcon";const as=l.forwardRef((t,e)=>l.createElement(oe,{ref:e,...t,weights:pl}));as.displayName="CaretLeftIcon";const cs=l.forwardRef((t,e)=>l.createElement(oe,{ref:e,...t,weights:ml}));cs.displayName="CheckIcon";const ls=l.forwardRef((t,e)=>l.createElement(oe,{ref:e,...t,weights:gl}));ls.displayName="CursorIcon";const us=l.forwardRef((t,e)=>l.createElement(oe,{ref:e,...t,weights:vl}));us.displayName="InfoIcon";const ds=l.forwardRef((t,e)=>l.createElement(oe,{ref:e,...t,weights:yl}));ds.displayName="SparkleIcon";const nr=l.forwardRef((t,e)=>l.createElement(oe,{ref:e,...t,weights:_l}));nr.displayName="SpinnerIcon";const hs=l.forwardRef((t,e)=>l.createElement(oe,{ref:e,...t,weights:wl}));hs.displayName="WarningIcon";async function wt(t,e={}){try{const n=await j.runtime.sendMessage({action:"callApi",endpoint:t,options:e});if(!n.success)throw new Error(n.error);return n.data}catch(n){throw console.error(`Error calling ${t} via background:`,n),n}}const bl=async()=>wt("/v1/user/integrations",{method:"GET"}),Il=async t=>wt(`${Pn.permissionServiceUrl}/v1/revoke/google`,{method:"DELETE"}),Nt=["gmail.readonly","calendar","contacts.other.readonly","userinfo.email"];class Al{requestGooglePermissions(e){const{clientId:n,redirectUri:r,authEndpoint:i,returnUrl:s}=Pn.oauth.google,o={userId:e.userId,mode:e.mode||"popup",firebaseUserToken:e.firebaseUserToken,returnUrl:s,env:Pn.env},a=btoa(JSON.stringify(o)),c=e.scope.split(" ").map(u=>`https://www.googleapis.com/auth/${u}`).join(" ");return`${i}?scope=email ${c}&access_type=offline&include_granted_scopes=true&response_type=code&redirect_uri=${r}&client_id=${n}&prompt=consent&state=${a}`}}const Tl=new Al,jn=Xt((t,e)=>({integrations:null,isLoading:!1,error:null,fetchIntegrations:async()=>{t({isLoading:!0,error:null});try{const n=await bl();t({integrations:n,isLoading:!1})}catch(n){t({error:n.message||"Failed to fetch integrations",isLoading:!1})}},clearIntegrations:()=>t({integrations:null,error:null}),getMissingPermissions:()=>{const{integrations:n}=e();if(!n)return Nt;const r=n.find(s=>s.provider==="google");if(!r)return Nt;const i=r.scopes.map(s=>s.replace("https://www.googleapis.com/auth/",""));return Nt.filter(s=>!i.includes(s))}}));Xi(te,t=>{t?jn.getState().fetchIntegrations():jn.getState().clearIntegrations()});const Sl=()=>{const{integrations:e,error:n,fetchIntegrations:r,getMissingPermissions:i}=jn(),[s,o]=l.useState(!1),[a,c]=l.useState(0),{user:u,getAuthToken:h}=We(),p=async()=>(c(v=>v+1),await new Promise(v=>setTimeout(v,500)),r());if(!e&&!n)throw r();if(n){if(a<5)throw p();return d.jsx("p",{className:"error-text",children:n})}const f=v=>{switch(v.replace("https://www.googleapis.com/auth/","")){case"gmail.readonly":return"Read your Gmail messages";case"calendar":return"View and manage your calendar";case"contacts.other.readonly":return"View your contacts";case"userinfo.email":return"View your email address";default:return null}},m=async()=>{if(!u)throw new Error("User must be logged in to grant permissions");try{const v=await h(),A=Tl.requestGooglePermissions({userId:u.uid,scope:Nt.join(" "),mode:"popup",firebaseUserToken:v}),S=600,R=800,x=(window.screen.width-S)/2,V=(window.screen.height-R)/2,O=window.open(A,"googleOAuthPopup",`width=${S},height=${R},left=${x},top=${V},resizable=yes,scrollbars=yes`);return console.log("OAuth popup window opened:",O),O||console.error("Popup window was blocked. Please allow popups for this site."),!0}catch(v){throw console.error("Error initiating Google permissions:",v),v}},_=async()=>{console.log("[Yellow] Granting permissions...");try{await m(),j.runtime.sendMessage({action:"sendMixpanelEvent",eventName:"grant_permissions_success",eventParams:{provider:"google"}}).catch(console.error)}catch(v){console.error("[Yellow] Failed to grant permissions:",v),j.runtime.sendMessage({action:"sendMixpanelEvent",eventName:"grant_permissions_failure",eventParams:{provider:"google",error:v instanceof Error?v.message:"Unknown error"}}).catch(console.error)}},g=async v=>{if(window.confirm(`Warning: Revoking permissions will disable the extension's ability to read your emails and help you schedule meetings. You'll need to grant permissions again to use the extension.

Are you sure you want to continue?`)){o(!0);try{await Il("google"),await r(),j.runtime.sendMessage({action:"sendMixpanelEvent",eventName:"revoke_permissions_success",eventParams:{provider:"google"}}).catch(console.error)}catch(S){j.runtime.sendMessage({action:"sendMixpanelEvent",eventName:"revoke_permissions_failure",eventParams:{provider:"google",error:S instanceof Error?S.message:"Unknown error"}}).catch(console.error)}finally{o(!1)}}},y=i(),w=()=>!e||e.length===0?null:d.jsxs(d.Fragment,{children:[d.jsx("div",{className:"popup-card-title",children:"You have connected the following services:"}),d.jsxs("div",{className:"popup-card",children:[d.jsx("div",{className:"popup-card-list",children:e.map((v,A)=>v.scopes.map((S,R)=>{const x=f(S);return x?d.jsxs("div",{className:"popup-card-item",children:[d.jsx("span",{className:"popup-card-icon",children:d.jsx(cs,{size:16})}),d.jsx("span",{children:x})]},`${A}-${R}`):null}).filter(Boolean))}),d.jsx("button",{className:"btn btn-danger btn-small btn-full",onClick:()=>{var v;return g(((v=e[0])==null?void 0:v.id)||"")},disabled:s,children:d.jsxs("div",{className:"button-content",children:[s&&d.jsx(nr,{className:"integration-spinner"}),s?"Revoking permissions...":"Revoke Permissions"]})})]})]}),E=()=>y.length===0?null:d.jsxs(d.Fragment,{children:[d.jsx("div",{className:"popup-card-title",children:"To help you schedule meetings from your inbox, we will need access to:"}),d.jsxs("div",{className:"popup-card",children:[d.jsx("div",{className:"popup-card-list",children:y.map((v,A)=>d.jsxs("div",{className:"popup-card-item",children:[d.jsx("span",{className:"popup-card-icon",children:d.jsx(ss,{size:16})}),d.jsx("span",{children:f(v)})]},A))}),d.jsx("button",{className:"btn btn-primary btn-full",onClick:_,children:"Grant Google Permissions"})]})]});return d.jsxs("section",{className:"user-integrations",children:[w(),E()]})},Ue=({style:t,children:e})=>d.jsx("div",{className:"popup-skeleton",style:t,children:e}),fs=()=>{const{user:t,isLoading:e,signOut:n}=We(),{navigateTo:r}=tr(),i=typeof t=="string"?JSON.parse(t):null,s=()=>{window.confirm("Are you sure you want to sign out? You'll need to sign in again to use the extension.")&&n()},o=()=>{r("subscription")};return t?d.jsxs(d.Fragment,{children:[d.jsx("header",{className:"user-panel-header",children:d.jsxs("span",{children:["Welcome, ",(t==null?void 0:t.name)||(i==null?void 0:i.name),"!"]})}),d.jsx(l.Suspense,{fallback:d.jsx(Ue,{style:{minHeight:"130px"},children:"Loading integrations..."}),children:d.jsx(Sl,{})}),d.jsxs("footer",{className:"user-panel-footer",children:[d.jsx("button",{className:"subscription-button",onClick:o,children:"Subscription"}),d.jsx("button",{className:"sign-out-button",onClick:s,disabled:e,children:e?"Signing out...":"Sign Out"})]})]}):null},Cl=()=>{const[t,e]=l.useState(!1),[n,r]=l.useState(null),i=()=>new Date().toLocaleString(),s=async()=>{try{e(!0),r(null),await a(),await c()||await o();const u=h=>{h.target===dr.OFFSCREEN&&h.type===hr.GOOGLE_AUTH_DATA&&(r(`Found google auth data: ${h.data}`),j.runtime.onMessage.removeListener(u))};j.runtime.onMessage.addListener(u),await j.runtime.sendMessage({type:hr.AUTH_EVENT,target:dr.OFFSCREEN,data:i()})}catch(u){console.error("Sign in with Google failed:",u),r("Sign in with Google failed")}finally{e(!1)}};async function o(){await c()||await j.offscreen.createDocument({url:j.runtime.getURL(fr),reasons:[j.offscreen.Reason.DOM_SCRAPING],justification:"authentication"})}async function a(){await c()&&await j.offscreen.closeDocument()}async function c(){var h;const u=await((h=j.runtime)==null?void 0:h.getContexts({contextTypes:[j.runtime.ContextType.OFFSCREEN_DOCUMENT],documentUrls:[j.runtime.getURL(fr)]}));return u!=null?u.length>0:(await self.clients.matchAll()).some(f=>f.url.includes(j.runtime.id))}return d.jsxs(d.Fragment,{children:[d.jsx("button",{onClick:s,disabled:t,className:"google-sign-in-button",children:t?d.jsxs(d.Fragment,{children:[d.jsx(nr,{size:18,className:"google-auth-spinner"}),"Processing..."]}):d.jsxs(d.Fragment,{children:[d.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"18",height:"18",viewBox:"0 0 48 48",children:[d.jsx("path",{fill:"#EA4335",d:"M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"}),d.jsx("path",{fill:"#4285F4",d:"M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"}),d.jsx("path",{fill:"#FBBC05",d:"M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"}),d.jsx("path",{fill:"#34A853",d:"M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"})]}),"Continue with Google"]})}),n&&d.jsx("div",{style:{marginTop:"10px",fontSize:"12px",color:"#333"},children:n})]})},zr=()=>{const{user:t,isLoading:e,error:n,signIn:r,signUp:i,signOut:s,clearError:o}=We();if(t===void 0)throw dl;return t?d.jsx(fs,{}):d.jsxs(d.Fragment,{children:[d.jsxs("header",{className:"auth-header",children:[d.jsx("img",{className:"auth-logo",src:"/icons/yellow-logo.svg",alt:"Yellow Logo"}),d.jsx("p",{className:"auth-title",children:"Sign up to start your 14-day free trial"}),d.jsx("p",{className:"auth-subtitle",children:"Try Yellow for free, cancel anytime!"})]}),n&&d.jsx("div",{className:"popup-error-message",children:n}),d.jsxs("div",{className:"popup-card",children:[d.jsxs("div",{className:"popup-card-list",children:[d.jsxs("div",{className:"popup-card-item",children:[d.jsx("span",{className:"popup-card-icon",children:d.jsx(ds,{size:16})}),d.jsx("span",{children:"AI automatically detects meeting requests in your emails"})]}),d.jsxs("div",{className:"popup-card-item",children:[d.jsx("span",{className:"popup-card-icon",children:d.jsx(os,{size:16})}),d.jsx("span",{children:"Shows optimized time slots for all participants"})]}),d.jsxs("div",{className:"popup-card-item",children:[d.jsx("span",{className:"popup-card-icon",children:d.jsx(ls,{size:16})}),d.jsx("span",{children:"Schedule in two clicks, right from your inbox!"})]})]}),d.jsx(Cl,{})]})]})};function ps(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const Rl=ps,ms=new Ae("auth","Firebase",ps());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Zt=new Jn("@firebase/auth");function kl(t,...e){Zt.logLevel<=U.WARN&&Zt.warn(`Auth (${Ke}): ${t}`,...e)}function Lt(t,...e){Zt.logLevel<=U.ERROR&&Zt.error(`Auth (${Ke}): ${t}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Gr(t,...e){throw rr(t,...e)}function gs(t,...e){return rr(t,...e)}function vs(t,e,n){const r=Object.assign(Object.assign({},Rl()),{[e]:n});return new Ae("auth","Firebase",r).create(e,{appName:t.name})}function xt(t){return vs(t,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function rr(t,...e){if(typeof t!="string"){const n=e[0],r=[...e.slice(1)];return r[0]&&(r[0].appName=t.name),t._errorFactory.create(n,...r)}return ms.create(t,...e)}function D(t,e,...n){if(!t)throw rr(e,...n)}function at(t){const e="INTERNAL ASSERTION FAILED: "+t;throw Lt(e),new Error(e)}function Wt(t,e){t||at(e)}function Pl(){return Kr()==="http:"||Kr()==="https:"}function Kr(){var t;return typeof self<"u"&&((t=self.location)===null||t===void 0?void 0:t.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Nl(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(Pl()||Si()||"connection"in navigator)?navigator.onLine:!0}function Ll(){if(typeof navigator>"u")return null;const t=navigator;return t.languages&&t.languages[0]||t.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Et{constructor(e,n){this.shortDelay=e,this.longDelay=n,Wt(n>e,"Short delay should be less than long delay!"),this.isMobile=Ai()||Ci()}get(){return Nl()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xl(t,e){Wt(t.emulator,"Emulator should always be set here");const{url:n}=t.emulator;return e?`${n}${e.startsWith("/")?e.slice(1):e}`:n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ys{static initialize(e,n,r){this.fetchImpl=e,n&&(this.headersImpl=n),r&&(this.responseImpl=r)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;at("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;at("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;at("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ol={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ml=["/v1/accounts:signInWithCustomToken","/v1/accounts:signInWithEmailLink","/v1/accounts:signInWithIdp","/v1/accounts:signInWithPassword","/v1/accounts:signInWithPhoneNumber","/v1/token"],Dl=new Et(3e4,6e4);function _s(t,e){return t.tenantId&&!e.tenantId?Object.assign(Object.assign({},e),{tenantId:t.tenantId}):e}async function nn(t,e,n,r,i={}){return ws(t,i,async()=>{let s={},o={};r&&(e==="GET"?o=r:s={body:JSON.stringify(r)});const a=gt(Object.assign({key:t.config.apiKey},o)).slice(1),c=await t._getAdditionalHeaders();c["Content-Type"]="application/json",t.languageCode&&(c["X-Firebase-Locale"]=t.languageCode);const u=Object.assign({method:e,headers:c},s);return Ti()||(u.referrerPolicy="no-referrer"),t.emulatorConfig&&Ge(t.emulatorConfig.host)&&(u.credentials="include"),ys.fetch()(await Es(t,t.config.apiHost,n,a),u)})}async function ws(t,e,n){t._canInitEmulator=!1;const r=Object.assign(Object.assign({},Ol),e);try{const i=new Ul(t),s=await Promise.race([n(),i.promise]);i.clearNetworkTimeout();const o=await s.json();if("needConfirmation"in o)throw Ct(t,"account-exists-with-different-credential",o);if(s.ok&&!("errorMessage"in o))return o;{const a=s.ok?o.errorMessage:o.error.message,[c,u]=a.split(" : ");if(c==="FEDERATED_USER_ID_ALREADY_LINKED")throw Ct(t,"credential-already-in-use",o);if(c==="EMAIL_EXISTS")throw Ct(t,"email-already-in-use",o);if(c==="USER_DISABLED")throw Ct(t,"user-disabled",o);const h=r[c]||c.toLowerCase().replace(/[_\s]+/g,"-");if(u)throw vs(t,h,u);Gr(t,h)}}catch(i){if(i instanceof se)throw i;Gr(t,"network-request-failed",{message:String(i)})}}async function Es(t,e,n,r){const i=`${e}${n}?${r}`,s=t,o=s.config.emulator?xl(t.config,i):`${t.config.apiScheme}://${i}`;return Ml.includes(n)&&(await s._persistenceManagerAvailable,s._getPersistenceType()==="COOKIE")?s._getPersistence()._getFinalTarget(o).toString():o}class Ul{clearNetworkTimeout(){clearTimeout(this.timer)}constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((n,r)=>{this.timer=setTimeout(()=>r(gs(this.auth,"network-request-failed")),Dl.get())})}}function Ct(t,e,n){const r={appName:t.name};n.email&&(r.email=n.email),n.phoneNumber&&(r.phoneNumber=n.phoneNumber);const i=gs(t,e,r);return i.customData._tokenResponse=n,i}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Fl(t,e){return nn(t,"POST","/v1/accounts:delete",e)}async function zt(t,e){return nn(t,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ct(t){if(t)try{const e=new Date(Number(t));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function Vl(t,e=!1){const n=Y(t),r=await n.getIdToken(e),i=bs(r);D(i&&i.exp&&i.auth_time&&i.iat,n.auth,"internal-error");const s=typeof i.firebase=="object"?i.firebase:void 0,o=s==null?void 0:s.sign_in_provider;return{claims:i,token:r,authTime:ct(_n(i.auth_time)),issuedAtTime:ct(_n(i.iat)),expirationTime:ct(_n(i.exp)),signInProvider:o||null,signInSecondFactor:(s==null?void 0:s.sign_in_second_factor)||null}}function _n(t){return Number(t)*1e3}function bs(t){const[e,n,r]=t.split(".");if(e===void 0||n===void 0||r===void 0)return Lt("JWT malformed, contained fewer than 3 sections"),null;try{const i=Yn(n);return i?JSON.parse(i):(Lt("Failed to decode base64 JWT payload"),null)}catch(i){return Lt("Caught error parsing JWT payload as JSON",i==null?void 0:i.toString()),null}}function Yr(t){const e=bs(t);return D(e,"internal-error"),D(typeof e.exp<"u","internal-error"),D(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Hn(t,e,n=!1){if(n)return e;try{return await e}catch(r){throw r instanceof se&&jl(r)&&t.auth.currentUser===t&&await t.auth.signOut(),r}}function jl({code:t}){return t==="auth/user-disabled"||t==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hl{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){var n;if(e){const r=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),r}else{this.errorBackoff=3e4;const i=((n=this.user.stsTokenManager.expirationTime)!==null&&n!==void 0?n:0)-Date.now()-3e5;return Math.max(0,i)}}schedule(e=!1){if(!this.isRunning)return;const n=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},n)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $n{constructor(e,n){this.createdAt=e,this.lastLoginAt=n,this._initializeTime()}_initializeTime(){this.lastSignInTime=ct(this.lastLoginAt),this.creationTime=ct(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Gt(t){var e;const n=t.auth,r=await t.getIdToken(),i=await Hn(t,zt(n,{idToken:r}));D(i==null?void 0:i.users.length,n,"internal-error");const s=i.users[0];t._notifyReloadListener(s);const o=!((e=s.providerUserInfo)===null||e===void 0)&&e.length?Is(s.providerUserInfo):[],a=Bl(t.providerData,o),c=t.isAnonymous,u=!(t.email&&s.passwordHash)&&!(a!=null&&a.length),h=c?u:!1,p={uid:s.localId,displayName:s.displayName||null,photoURL:s.photoUrl||null,email:s.email||null,emailVerified:s.emailVerified||!1,phoneNumber:s.phoneNumber||null,tenantId:s.tenantId||null,providerData:a,metadata:new $n(s.createdAt,s.lastLoginAt),isAnonymous:h};Object.assign(t,p)}async function $l(t){const e=Y(t);await Gt(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function Bl(t,e){return[...t.filter(r=>!e.some(i=>i.providerId===r.providerId)),...e]}function Is(t){return t.map(e=>{var{providerId:n}=e,r=vt(e,["providerId"]);return{providerId:n,uid:r.rawId||"",displayName:r.displayName||null,email:r.email||null,phoneNumber:r.phoneNumber||null,photoURL:r.photoUrl||null}})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Zl(t,e){const n=await ws(t,{},async()=>{const r=gt({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:i,apiKey:s}=t.config,o=await Es(t,i,"/v1/token",`key=${s}`),a=await t._getAdditionalHeaders();a["Content-Type"]="application/x-www-form-urlencoded";const c={method:"POST",headers:a,body:r};return t.emulatorConfig&&Ge(t.emulatorConfig.host)&&(c.credentials="include"),ys.fetch()(o,c)});return{accessToken:n.access_token,expiresIn:n.expires_in,refreshToken:n.refresh_token}}async function Wl(t,e){return nn(t,"POST","/v2/accounts:revokeToken",_s(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ve{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){D(e.idToken,"internal-error"),D(typeof e.idToken<"u","internal-error"),D(typeof e.refreshToken<"u","internal-error");const n="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):Yr(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,n)}updateFromIdToken(e){D(e.length!==0,"internal-error");const n=Yr(e);this.updateTokensAndExpiration(e,null,n)}async getToken(e,n=!1){return!n&&this.accessToken&&!this.isExpired?this.accessToken:(D(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,n){const{accessToken:r,refreshToken:i,expiresIn:s}=await Zl(e,n);this.updateTokensAndExpiration(r,i,Number(s))}updateTokensAndExpiration(e,n,r){this.refreshToken=n||null,this.accessToken=e||null,this.expirationTime=Date.now()+r*1e3}static fromJSON(e,n){const{refreshToken:r,accessToken:i,expirationTime:s}=n,o=new Ve;return r&&(D(typeof r=="string","internal-error",{appName:e}),o.refreshToken=r),i&&(D(typeof i=="string","internal-error",{appName:e}),o.accessToken=i),s&&(D(typeof s=="number","internal-error",{appName:e}),o.expirationTime=s),o}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new Ve,this.toJSON())}_performRefresh(){return at("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function me(t,e){D(typeof t=="string"||typeof t>"u","internal-error",{appName:e})}class re{constructor(e){var{uid:n,auth:r,stsTokenManager:i}=e,s=vt(e,["uid","auth","stsTokenManager"]);this.providerId="firebase",this.proactiveRefresh=new Hl(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=n,this.auth=r,this.stsTokenManager=i,this.accessToken=i.accessToken,this.displayName=s.displayName||null,this.email=s.email||null,this.emailVerified=s.emailVerified||!1,this.phoneNumber=s.phoneNumber||null,this.photoURL=s.photoURL||null,this.isAnonymous=s.isAnonymous||!1,this.tenantId=s.tenantId||null,this.providerData=s.providerData?[...s.providerData]:[],this.metadata=new $n(s.createdAt||void 0,s.lastLoginAt||void 0)}async getIdToken(e){const n=await Hn(this,this.stsTokenManager.getToken(this.auth,e));return D(n,this.auth,"internal-error"),this.accessToken!==n&&(this.accessToken=n,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),n}getIdTokenResult(e){return Vl(this,e)}reload(){return $l(this)}_assign(e){this!==e&&(D(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(n=>Object.assign({},n)),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const n=new re(Object.assign(Object.assign({},this),{auth:e,stsTokenManager:this.stsTokenManager._clone()}));return n.metadata._copy(this.metadata),n}_onReload(e){D(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,n=!1){let r=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),r=!0),n&&await Gt(this),await this.auth._persistUserIfCurrent(this),r&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(K(this.auth.app))return Promise.reject(xt(this.auth));const e=await this.getIdToken();return await Hn(this,Fl(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return Object.assign(Object.assign({uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>Object.assign({},e)),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId},this.metadata.toJSON()),{apiKey:this.auth.config.apiKey,appName:this.auth.name})}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,n){var r,i,s,o,a,c,u,h;const p=(r=n.displayName)!==null&&r!==void 0?r:void 0,f=(i=n.email)!==null&&i!==void 0?i:void 0,m=(s=n.phoneNumber)!==null&&s!==void 0?s:void 0,_=(o=n.photoURL)!==null&&o!==void 0?o:void 0,g=(a=n.tenantId)!==null&&a!==void 0?a:void 0,y=(c=n._redirectEventId)!==null&&c!==void 0?c:void 0,w=(u=n.createdAt)!==null&&u!==void 0?u:void 0,E=(h=n.lastLoginAt)!==null&&h!==void 0?h:void 0,{uid:v,emailVerified:A,isAnonymous:S,providerData:R,stsTokenManager:x}=n;D(v&&x,e,"internal-error");const V=Ve.fromJSON(this.name,x);D(typeof v=="string",e,"internal-error"),me(p,e.name),me(f,e.name),D(typeof A=="boolean",e,"internal-error"),D(typeof S=="boolean",e,"internal-error"),me(m,e.name),me(_,e.name),me(g,e.name),me(y,e.name),me(w,e.name),me(E,e.name);const O=new re({uid:v,auth:e,email:f,emailVerified:A,displayName:p,isAnonymous:S,photoURL:_,phoneNumber:m,tenantId:g,stsTokenManager:V,createdAt:w,lastLoginAt:E});return R&&Array.isArray(R)&&(O.providerData=R.map(F=>Object.assign({},F))),y&&(O._redirectEventId=y),O}static async _fromIdTokenResponse(e,n,r=!1){const i=new Ve;i.updateFromServerResponse(n);const s=new re({uid:n.localId,auth:e,stsTokenManager:i,isAnonymous:r});return await Gt(s),s}static async _fromGetAccountInfoResponse(e,n,r){const i=n.users[0];D(i.localId!==void 0,"internal-error");const s=i.providerUserInfo!==void 0?Is(i.providerUserInfo):[],o=!(i.email&&i.passwordHash)&&!(s!=null&&s.length),a=new Ve;a.updateFromIdToken(r);const c=new re({uid:i.localId,auth:e,stsTokenManager:a,isAnonymous:o}),u={uid:i.localId,displayName:i.displayName||null,photoURL:i.photoUrl||null,email:i.email||null,emailVerified:i.emailVerified||!1,phoneNumber:i.phoneNumber||null,tenantId:i.tenantId||null,providerData:s,metadata:new $n(i.createdAt,i.lastLoginAt),isAnonymous:!(i.email&&i.passwordHash)&&!(s!=null&&s.length)};return Object.assign(c,u),c}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qr=new Map;function ke(t){Wt(t instanceof Function,"Expected a class definition");let e=qr.get(t);return e?(Wt(e instanceof t,"Instance stored in cache mismatched with class"),e):(e=new t,qr.set(t,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class As{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,n){this.storage[e]=n}async _get(e){const n=this.storage[e];return n===void 0?null:n}async _remove(e){delete this.storage[e]}_addListener(e,n){}_removeListener(e,n){}}As.type="NONE";const Jr=As;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wn(t,e,n){return`firebase:${t}:${e}:${n}`}class je{constructor(e,n,r){this.persistence=e,this.auth=n,this.userKey=r;const{config:i,name:s}=this.auth;this.fullUserKey=wn(this.userKey,i.apiKey,s),this.fullPersistenceKey=wn("persistence",i.apiKey,s),this.boundEventHandler=n._onStorageEvent.bind(n),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);if(!e)return null;if(typeof e=="string"){const n=await zt(this.auth,{idToken:e}).catch(()=>{});return n?re._fromGetAccountInfoResponse(this.auth,n,e):null}return re._fromJSON(this.auth,e)}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const n=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,n)return this.setCurrentUser(n)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,n,r="authUser"){if(!n.length)return new je(ke(Jr),e,r);const i=(await Promise.all(n.map(async u=>{if(await u._isAvailable())return u}))).filter(u=>u);let s=i[0]||ke(Jr);const o=wn(r,e.config.apiKey,e.name);let a=null;for(const u of n)try{const h=await u._get(o);if(h){let p;if(typeof h=="string"){const f=await zt(e,{idToken:h}).catch(()=>{});if(!f)break;p=await re._fromGetAccountInfoResponse(e,f,h)}else p=re._fromJSON(e,h);u!==s&&(a=p),s=u;break}}catch{}const c=i.filter(u=>u._shouldAllowMigration);return!s._shouldAllowMigration||!c.length?new je(s,e,r):(s=c[0],a&&await s._set(o,a.toJSON()),await Promise.all(n.map(async u=>{if(u!==s)try{await u._remove(o)}catch{}})),new je(s,e,r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xr(t){const e=t.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(Yl(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(zl(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(Jl(e))return"Blackberry";if(Xl(e))return"Webos";if(Gl(e))return"Safari";if((e.includes("chrome/")||Kl(e))&&!e.includes("edge/"))return"Chrome";if(ql(e))return"Android";{const n=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,r=t.match(n);if((r==null?void 0:r.length)===2)return r[1]}return"Other"}function zl(t=G()){return/firefox\//i.test(t)}function Gl(t=G()){const e=t.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function Kl(t=G()){return/crios\//i.test(t)}function Yl(t=G()){return/iemobile/i.test(t)}function ql(t=G()){return/android/i.test(t)}function Jl(t=G()){return/blackberry/i.test(t)}function Xl(t=G()){return/webos/i.test(t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ts(t,e=[]){let n;switch(t){case"Browser":n=Xr(G());break;case"Worker":n=`${Xr(G())}-${t}`;break;default:n=t}const r=e.length?e.join(","):"FirebaseCore-web";return`${n}/JsCore/${Ke}/${r}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ql{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,n){const r=s=>new Promise((o,a)=>{try{const c=e(s);o(c)}catch(c){a(c)}});r.onAbort=n,this.queue.push(r);const i=this.queue.length-1;return()=>{this.queue[i]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const n=[];try{for(const r of this.queue)await r(e),r.onAbort&&n.push(r.onAbort)}catch(r){n.reverse();for(const i of n)try{i()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:r==null?void 0:r.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function eu(t,e={}){return nn(t,"GET","/v2/passwordPolicy",_s(t,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const tu=6;class nu{constructor(e){var n,r,i,s;const o=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=(n=o.minPasswordLength)!==null&&n!==void 0?n:tu,o.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=o.maxPasswordLength),o.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=o.containsLowercaseCharacter),o.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=o.containsUppercaseCharacter),o.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=o.containsNumericCharacter),o.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=o.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=(i=(r=e.allowedNonAlphanumericCharacters)===null||r===void 0?void 0:r.join(""))!==null&&i!==void 0?i:"",this.forceUpgradeOnSignin=(s=e.forceUpgradeOnSignin)!==null&&s!==void 0?s:!1,this.schemaVersion=e.schemaVersion}validatePassword(e){var n,r,i,s,o,a;const c={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,c),this.validatePasswordCharacterOptions(e,c),c.isValid&&(c.isValid=(n=c.meetsMinPasswordLength)!==null&&n!==void 0?n:!0),c.isValid&&(c.isValid=(r=c.meetsMaxPasswordLength)!==null&&r!==void 0?r:!0),c.isValid&&(c.isValid=(i=c.containsLowercaseLetter)!==null&&i!==void 0?i:!0),c.isValid&&(c.isValid=(s=c.containsUppercaseLetter)!==null&&s!==void 0?s:!0),c.isValid&&(c.isValid=(o=c.containsNumericCharacter)!==null&&o!==void 0?o:!0),c.isValid&&(c.isValid=(a=c.containsNonAlphanumericCharacter)!==null&&a!==void 0?a:!0),c}validatePasswordLengthOptions(e,n){const r=this.customStrengthOptions.minPasswordLength,i=this.customStrengthOptions.maxPasswordLength;r&&(n.meetsMinPasswordLength=e.length>=r),i&&(n.meetsMaxPasswordLength=e.length<=i)}validatePasswordCharacterOptions(e,n){this.updatePasswordCharacterOptionsStatuses(n,!1,!1,!1,!1);let r;for(let i=0;i<e.length;i++)r=e.charAt(i),this.updatePasswordCharacterOptionsStatuses(n,r>="a"&&r<="z",r>="A"&&r<="Z",r>="0"&&r<="9",this.allowedNonAlphanumericCharacters.includes(r))}updatePasswordCharacterOptionsStatuses(e,n,r,i,s){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=n)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=r)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=i)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ru{constructor(e,n,r,i){this.app=e,this.heartbeatServiceProvider=n,this.appCheckServiceProvider=r,this.config=i,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new Qr(this),this.idTokenSubscription=new Qr(this),this.beforeStateQueue=new Ql(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=ms,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this._resolvePersistenceManagerAvailable=void 0,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=i.sdkClientVersion,this._persistenceManagerAvailable=new Promise(s=>this._resolvePersistenceManagerAvailable=s)}_initializeWithPersistence(e,n){return n&&(this._popupRedirectResolver=ke(n)),this._initializationPromise=this.queue(async()=>{var r,i,s;if(!this._deleted&&(this.persistenceManager=await je.create(this,e),(r=this._resolvePersistenceManagerAvailable)===null||r===void 0||r.call(this),!this._deleted)){if(!((i=this._popupRedirectResolver)===null||i===void 0)&&i._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(n),this.lastNotifiedUid=((s=this.currentUser)===null||s===void 0?void 0:s.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const n=await zt(this,{idToken:e}),r=await re._fromGetAccountInfoResponse(this,n,e);await this.directlySetCurrentUser(r)}catch(n){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",n),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var n;if(K(this.app)){const o=this.app.settings.authIdToken;return o?new Promise(a=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(o).then(a,a))}):this.directlySetCurrentUser(null)}const r=await this.assertedPersistence.getCurrentUser();let i=r,s=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const o=(n=this.redirectUser)===null||n===void 0?void 0:n._redirectEventId,a=i==null?void 0:i._redirectEventId,c=await this.tryRedirectSignIn(e);(!o||o===a)&&(c!=null&&c.user)&&(i=c.user,s=!0)}if(!i)return this.directlySetCurrentUser(null);if(!i._redirectEventId){if(s)try{await this.beforeStateQueue.runMiddleware(i)}catch(o){i=r,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(o))}return i?this.reloadAndSetCurrentUserOrClear(i):this.directlySetCurrentUser(null)}return D(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===i._redirectEventId?this.directlySetCurrentUser(i):this.reloadAndSetCurrentUserOrClear(i)}async tryRedirectSignIn(e){let n=null;try{n=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return n}async reloadAndSetCurrentUserOrClear(e){try{await Gt(e)}catch(n){if((n==null?void 0:n.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=Ll()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(K(this.app))return Promise.reject(xt(this));const n=e?Y(e):null;return n&&D(n.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(n&&n._clone(this))}async _updateCurrentUser(e,n=!1){if(!this._deleted)return e&&D(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),n||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return K(this.app)?Promise.reject(xt(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return K(this.app)?Promise.reject(xt(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(ke(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const n=this._getPasswordPolicyInternal();return n.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):n.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await eu(this),n=new nu(e);this.tenantId===null?this._projectPasswordPolicy=n:this._tenantPasswordPolicies[this.tenantId]=n}_getPersistenceType(){return this.assertedPersistence.persistence.type}_getPersistence(){return this.assertedPersistence.persistence}_updateErrorMap(e){this._errorFactory=new Ae("auth","Firebase",e())}onAuthStateChanged(e,n,r){return this.registerStateListener(this.authStateSubscription,e,n,r)}beforeAuthStateChanged(e,n){return this.beforeStateQueue.pushCallback(e,n)}onIdTokenChanged(e,n,r){return this.registerStateListener(this.idTokenSubscription,e,n,r)}authStateReady(){return new Promise((e,n)=>{if(this.currentUser)e();else{const r=this.onAuthStateChanged(()=>{r(),e()},n)}})}async revokeAccessToken(e){if(this.currentUser){const n=await this.currentUser.getIdToken(),r={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:n};this.tenantId!=null&&(r.tenantId=this.tenantId),await Wl(this,r)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)===null||e===void 0?void 0:e.toJSON()}}async _setRedirectUser(e,n){const r=await this.getOrInitRedirectPersistenceManager(n);return e===null?r.removeCurrentUser():r.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const n=e&&ke(e)||this._popupRedirectResolver;D(n,this,"argument-error"),this.redirectPersistenceManager=await je.create(this,[ke(n._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var n,r;return this._isInitialized&&await this.queue(async()=>{}),((n=this._currentUser)===null||n===void 0?void 0:n._redirectEventId)===e?this._currentUser:((r=this.redirectUser)===null||r===void 0?void 0:r._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var e,n;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const r=(n=(e=this.currentUser)===null||e===void 0?void 0:e.uid)!==null&&n!==void 0?n:null;this.lastNotifiedUid!==r&&(this.lastNotifiedUid=r,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,n,r,i){if(this._deleted)return()=>{};const s=typeof n=="function"?n:n.next.bind(n);let o=!1;const a=this._isInitialized?Promise.resolve():this._initializationPromise;if(D(a,this,"internal-error"),a.then(()=>{o||s(this.currentUser)}),typeof n=="function"){const c=e.addObserver(n,r,i);return()=>{o=!0,c()}}else{const c=e.addObserver(n);return()=>{o=!0,c()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return D(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=Ts(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var e;const n={"X-Client-Version":this.clientVersion};this.app.options.appId&&(n["X-Firebase-gmpid"]=this.app.options.appId);const r=await((e=this.heartbeatServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getHeartbeatsHeader());r&&(n["X-Firebase-Client"]=r);const i=await this._getAppCheckToken();return i&&(n["X-Firebase-AppCheck"]=i),n}async _getAppCheckToken(){var e;if(K(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const n=await((e=this.appCheckServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getToken());return n!=null&&n.error&&kl(`Error while retrieving App Check token: ${n.error}`),n==null?void 0:n.token}}function iu(t){return Y(t)}let Qr=class{constructor(e){this.auth=e,this.observer=null,this.addObserver=Ri(n=>this.observer=n)}get next(){return D(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}};function su(t,e){const n=(e==null?void 0:e.persistence)||[],r=(Array.isArray(n)?n:[n]).map(ke);e!=null&&e.errorMap&&t._updateErrorMap(e.errorMap),t._initializeWithPersistence(r,e==null?void 0:e.popupRedirectResolver)}function ou(t,e,n,r){return Y(t).onAuthStateChanged(e,n,r)}new Et(3e4,6e4);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */new Et(2e3,1e4);/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */new Et(3e4,6e4);/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */new Et(5e3,15e3);var ei="@firebase/auth",ti="1.10.8";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class au{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)===null||e===void 0?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const n=this.auth.onIdTokenChanged(r=>{e((r==null?void 0:r.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,n),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const n=this.internalListeners.get(e);n&&(this.internalListeners.delete(e),n(),this.updateProactiveRefresh())}assertAuthConfigured(){D(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function cu(t){switch(t){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function lu(t){Ne(new Ie("auth",(e,{options:n})=>{const r=e.getProvider("app").getImmediate(),i=e.getProvider("heartbeat"),s=e.getProvider("app-check-internal"),{apiKey:o,authDomain:a}=r.options;D(o&&!o.includes(":"),"invalid-api-key",{appName:r.name});const c={apiKey:o,authDomain:a,clientPlatform:t,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:Ts(t)},u=new ru(r,i,s,c);return su(u,n),u},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,n,r)=>{e.getProvider("auth-internal").initialize()})),Ne(new Ie("auth-internal",e=>{const n=iu(e.getProvider("auth").getImmediate());return(r=>new au(r))(n)},"PRIVATE").setInstantiationMode("EXPLICIT")),be(ei,ti,cu(t)),be(ei,ti,"esm2017")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uu=300;uo("authIdTokenMaxAge");lu("Browser");const du=async()=>wt("/v1/subscription-status",{method:"GET"}),hu=async()=>wt("/v1/subscription/pricing-table",{method:"GET"}),fu=async()=>wt("/v1/subscription/portal",{method:"GET"}),En=t=>{if(!t)return{hasLimit:!1,isPro:!1,isFree:!1,isActive:!1,isOverLimit:!1,isCloseToLimit:!1,isFreeTrialExpiringSoon:!1,usagePercentage:0};const e=t.plan==="individual",n=t.plan==="free",r=t.status==="active",i=typeof t.plan_limit=="number"&&t.plan_limit>0,s=i?Math.round(t.action_item_count/t.plan_limit*100):0,o=i&&s>=80,a=i&&t.action_item_count>=t.plan_limit;let c=!1;if(n&&t.due_to){const u=new Date,p=new Date(t.due_to).getTime()-u.getTime();p>0&&(c=Math.ceil(p/864e5)<=5)}return{hasLimit:i,isPro:e,isFree:n,isActive:r,isOverLimit:a,isCloseToLimit:o,isFreeTrialExpiringSoon:c,usagePercentage:s}},Ss=Xt(t=>({subscription:null,isLoading:!1,error:null,...En(null),fetchSubscription:async()=>{t({isLoading:!0,error:null});try{const e=await du();t(n=>({subscription:e,isLoading:!1,...En(e)}))}catch(e){t({error:e.message||"Failed to fetch subscription status",isLoading:!1})}},clearSubscription:()=>t({subscription:null,error:null,...En(null)})}));ou(te,t=>{const e=Ss.getState();t?e.fetchSubscription():e.clearSubscription()});function rn(){return typeof window<"u"}function Je(t){return Cs(t)?(t.nodeName||"").toLowerCase():"#document"}function J(t){var e;return(t==null||(e=t.ownerDocument)==null?void 0:e.defaultView)||window}function fe(t){var e;return(e=(Cs(t)?t.ownerDocument:t.document)||window.document)==null?void 0:e.documentElement}function Cs(t){return rn()?t instanceof Node||t instanceof J(t).Node:!1}function H(t){return rn()?t instanceof Element||t instanceof J(t).Element:!1}function ee(t){return rn()?t instanceof HTMLElement||t instanceof J(t).HTMLElement:!1}function Bn(t){return!rn()||typeof ShadowRoot>"u"?!1:t instanceof ShadowRoot||t instanceof J(t).ShadowRoot}const pu=new Set(["inline","contents"]);function bt(t){const{overflow:e,overflowX:n,overflowY:r,display:i}=Q(t);return/auto|scroll|overlay|hidden|clip/.test(e+r+n)&&!pu.has(i)}const mu=new Set(["table","td","th"]);function gu(t){return mu.has(Je(t))}const vu=[":popover-open",":modal"];function sn(t){return vu.some(e=>{try{return t.matches(e)}catch{return!1}})}const yu=["transform","translate","scale","rotate","perspective"],_u=["transform","translate","scale","rotate","perspective","filter"],wu=["paint","layout","strict","content"];function ir(t){const e=on(),n=H(t)?Q(t):t;return yu.some(r=>n[r]?n[r]!=="none":!1)||(n.containerType?n.containerType!=="normal":!1)||!e&&(n.backdropFilter?n.backdropFilter!=="none":!1)||!e&&(n.filter?n.filter!=="none":!1)||_u.some(r=>(n.willChange||"").includes(r))||wu.some(r=>(n.contain||"").includes(r))}function Eu(t){let e=he(t);for(;ee(e)&&!ue(e);){if(ir(e))return e;if(sn(e))return null;e=he(e)}return null}function on(){return typeof CSS>"u"||!CSS.supports?!1:CSS.supports("-webkit-backdrop-filter","none")}const bu=new Set(["html","body","#document"]);function ue(t){return bu.has(Je(t))}function Q(t){return J(t).getComputedStyle(t)}function an(t){return H(t)?{scrollLeft:t.scrollLeft,scrollTop:t.scrollTop}:{scrollLeft:t.scrollX,scrollTop:t.scrollY}}function he(t){if(Je(t)==="html")return t;const e=t.assignedSlot||t.parentNode||Bn(t)&&t.host||fe(t);return Bn(e)?e.host:e}function Rs(t){const e=he(t);return ue(e)?t.ownerDocument?t.ownerDocument.body:t.body:ee(e)&&bt(e)?e:Rs(e)}function He(t,e,n){var r;e===void 0&&(e=[]),n===void 0&&(n=!0);const i=Rs(t),s=i===((r=t.ownerDocument)==null?void 0:r.body),o=J(i);if(s){const a=Zn(o);return e.concat(o,o.visualViewport||[],bt(i)?i:[],a&&n?He(a):[])}return e.concat(i,He(i,[],n))}function Zn(t){return t.parent&&Object.getPrototypeOf(t.parent)?t.frameElement:null}const pt=Math.min,$e=Math.max,Kt=Math.round,ie=t=>({x:t,y:t}),Iu={left:"right",right:"left",bottom:"top",top:"bottom"},Au={start:"end",end:"start"};function Wn(t,e,n){return $e(t,pt(e,n))}function It(t,e){return typeof t=="function"?t(e):t}function Oe(t){return t.split("-")[0]}function At(t){return t.split("-")[1]}function ks(t){return t==="x"?"y":"x"}function sr(t){return t==="y"?"height":"width"}const Tu=new Set(["top","bottom"]);function _e(t){return Tu.has(Oe(t))?"y":"x"}function or(t){return ks(_e(t))}function Su(t,e,n){n===void 0&&(n=!1);const r=At(t),i=or(t),s=sr(i);let o=i==="x"?r===(n?"end":"start")?"right":"left":r==="start"?"bottom":"top";return e.reference[s]>e.floating[s]&&(o=Yt(o)),[o,Yt(o)]}function Cu(t){const e=Yt(t);return[zn(t),e,zn(e)]}function zn(t){return t.replace(/start|end/g,e=>Au[e])}const ni=["left","right"],ri=["right","left"],Ru=["top","bottom"],ku=["bottom","top"];function Pu(t,e,n){switch(t){case"top":case"bottom":return n?e?ri:ni:e?ni:ri;case"left":case"right":return e?Ru:ku;default:return[]}}function Nu(t,e,n,r){const i=At(t);let s=Pu(Oe(t),n==="start",r);return i&&(s=s.map(o=>o+"-"+i),e&&(s=s.concat(s.map(zn)))),s}function Yt(t){return t.replace(/left|right|bottom|top/g,e=>Iu[e])}function Lu(t){return{top:0,right:0,bottom:0,left:0,...t}}function Ps(t){return typeof t!="number"?Lu(t):{top:t,right:t,bottom:t,left:t}}function qt(t){const{x:e,y:n,width:r,height:i}=t;return{width:r,height:i,top:n,left:e,right:e+r,bottom:n+i,x:e,y:n}}const ii="data-floating-ui-focusable";function Gn(t,e){if(!t||!e)return!1;const n=e.getRootNode==null?void 0:e.getRootNode();if(t.contains(e))return!0;if(n&&Bn(n)){let r=e;for(;r;){if(t===r)return!0;r=r.parentNode||r.host}}return!1}function tt(t){return"composedPath"in t?t.composedPath()[0]:t.target}function bn(t,e){if(e==null)return!1;if("composedPath"in t)return t.composedPath().includes(e);const n=t;return n.target!=null&&e.contains(n.target)}function xu(t){return t.matches("html,body")}function Fe(t){return(t==null?void 0:t.ownerDocument)||document}function Ou(t){return t?t.hasAttribute(ii)?t:t.querySelector("["+ii+"]")||t:null}function Ot(t,e,n){return n===void 0&&(n=!0),t.filter(i=>{var s;return i.parentId===e&&(!n||((s=i.context)==null?void 0:s.open))}).flatMap(i=>[i,...Ot(t,i.id,n)])}function Mu(t){return"nativeEvent"in t}function Kn(t,e){const n=["mouse","pen"];return n.push("",void 0),n.includes(t)}var Du=typeof document<"u",Uu=function(){},ze=Du?l.useLayoutEffect:Uu;const Fu={..._i};function Rt(t){const e=l.useRef(t);return ze(()=>{e.current=t}),e}const Vu=Fu.useInsertionEffect,ju=Vu||(t=>t());function ne(t){const e=l.useRef(()=>{});return ju(()=>{e.current=t}),l.useCallback(function(){for(var n=arguments.length,r=new Array(n),i=0;i<n;i++)r[i]=arguments[i];return e.current==null?void 0:e.current(...r)},[])}var Ns=qs();function si(t,e,n){let{reference:r,floating:i}=t;const s=_e(e),o=or(e),a=sr(o),c=Oe(e),u=s==="y",h=r.x+r.width/2-i.width/2,p=r.y+r.height/2-i.height/2,f=r[a]/2-i[a]/2;let m;switch(c){case"top":m={x:h,y:r.y-i.height};break;case"bottom":m={x:h,y:r.y+r.height};break;case"right":m={x:r.x+r.width,y:p};break;case"left":m={x:r.x-i.width,y:p};break;default:m={x:r.x,y:r.y}}switch(At(e)){case"start":m[o]-=f*(n&&u?-1:1);break;case"end":m[o]+=f*(n&&u?-1:1);break}return m}const Hu=async(t,e,n)=>{const{placement:r="bottom",strategy:i="absolute",middleware:s=[],platform:o}=n,a=s.filter(Boolean),c=await(o.isRTL==null?void 0:o.isRTL(e));let u=await o.getElementRects({reference:t,floating:e,strategy:i}),{x:h,y:p}=si(u,r,c),f=r,m={},_=0;for(let g=0;g<a.length;g++){const{name:y,fn:w}=a[g],{x:E,y:v,data:A,reset:S}=await w({x:h,y:p,initialPlacement:r,placement:f,strategy:i,middlewareData:m,rects:u,platform:o,elements:{reference:t,floating:e}});h=E??h,p=v??p,m={...m,[y]:{...m[y],...A}},S&&_<=50&&(_++,typeof S=="object"&&(S.placement&&(f=S.placement),S.rects&&(u=S.rects===!0?await o.getElementRects({reference:t,floating:e,strategy:i}):S.rects),{x:h,y:p}=si(u,f,c)),g=-1)}return{x:h,y:p,placement:f,strategy:i,middlewareData:m}};async function Ls(t,e){var n;e===void 0&&(e={});const{x:r,y:i,platform:s,rects:o,elements:a,strategy:c}=t,{boundary:u="clippingAncestors",rootBoundary:h="viewport",elementContext:p="floating",altBoundary:f=!1,padding:m=0}=It(e,t),_=Ps(m),y=a[f?p==="floating"?"reference":"floating":p],w=qt(await s.getClippingRect({element:(n=await(s.isElement==null?void 0:s.isElement(y)))==null||n?y:y.contextElement||await(s.getDocumentElement==null?void 0:s.getDocumentElement(a.floating)),boundary:u,rootBoundary:h,strategy:c})),E=p==="floating"?{x:r,y:i,width:o.floating.width,height:o.floating.height}:o.reference,v=await(s.getOffsetParent==null?void 0:s.getOffsetParent(a.floating)),A=await(s.isElement==null?void 0:s.isElement(v))?await(s.getScale==null?void 0:s.getScale(v))||{x:1,y:1}:{x:1,y:1},S=qt(s.convertOffsetParentRelativeRectToViewportRelativeRect?await s.convertOffsetParentRelativeRectToViewportRelativeRect({elements:a,rect:E,offsetParent:v,strategy:c}):E);return{top:(w.top-S.top+_.top)/A.y,bottom:(S.bottom-w.bottom+_.bottom)/A.y,left:(w.left-S.left+_.left)/A.x,right:(S.right-w.right+_.right)/A.x}}const $u=t=>({name:"arrow",options:t,async fn(e){const{x:n,y:r,placement:i,rects:s,platform:o,elements:a,middlewareData:c}=e,{element:u,padding:h=0}=It(t,e)||{};if(u==null)return{};const p=Ps(h),f={x:n,y:r},m=or(i),_=sr(m),g=await o.getDimensions(u),y=m==="y",w=y?"top":"left",E=y?"bottom":"right",v=y?"clientHeight":"clientWidth",A=s.reference[_]+s.reference[m]-f[m]-s.floating[_],S=f[m]-s.reference[m],R=await(o.getOffsetParent==null?void 0:o.getOffsetParent(u));let x=R?R[v]:0;(!x||!await(o.isElement==null?void 0:o.isElement(R)))&&(x=a.floating[v]||s.floating[_]);const V=A/2-S/2,O=x/2-g[_]/2-1,F=pt(p[w],O),Z=pt(p[E],O),B=F,$=x-g[_]-Z,M=x/2-g[_]/2+V,C=Wn(B,M,$),L=!c.arrow&&At(i)!=null&&M!==C&&s.reference[_]/2-(M<B?F:Z)-g[_]/2<0,T=L?M<B?M-B:M-$:0;return{[m]:f[m]+T,data:{[m]:C,centerOffset:M-C-T,...L&&{alignmentOffset:T}},reset:L}}}),Bu=function(t){return t===void 0&&(t={}),{name:"flip",options:t,async fn(e){var n,r;const{placement:i,middlewareData:s,rects:o,initialPlacement:a,platform:c,elements:u}=e,{mainAxis:h=!0,crossAxis:p=!0,fallbackPlacements:f,fallbackStrategy:m="bestFit",fallbackAxisSideDirection:_="none",flipAlignment:g=!0,...y}=It(t,e);if((n=s.arrow)!=null&&n.alignmentOffset)return{};const w=Oe(i),E=_e(a),v=Oe(a)===a,A=await(c.isRTL==null?void 0:c.isRTL(u.floating)),S=f||(v||!g?[Yt(a)]:Cu(a)),R=_!=="none";!f&&R&&S.push(...Nu(a,g,_,A));const x=[a,...S],V=await Ls(e,y),O=[];let F=((r=s.flip)==null?void 0:r.overflows)||[];if(h&&O.push(V[w]),p){const M=Su(i,o,A);O.push(V[M[0]],V[M[1]])}if(F=[...F,{placement:i,overflows:O}],!O.every(M=>M<=0)){var Z,B;const M=(((Z=s.flip)==null?void 0:Z.index)||0)+1,C=x[M];if(C&&(!(p==="alignment"?E!==_e(C):!1)||F.every(b=>b.overflows[0]>0&&_e(b.placement)===E)))return{data:{index:M,overflows:F},reset:{placement:C}};let L=(B=F.filter(T=>T.overflows[0]<=0).sort((T,b)=>T.overflows[1]-b.overflows[1])[0])==null?void 0:B.placement;if(!L)switch(m){case"bestFit":{var $;const T=($=F.filter(b=>{if(R){const I=_e(b.placement);return I===E||I==="y"}return!0}).map(b=>[b.placement,b.overflows.filter(I=>I>0).reduce((I,k)=>I+k,0)]).sort((b,I)=>b[1]-I[1])[0])==null?void 0:$[0];T&&(L=T);break}case"initialPlacement":L=a;break}if(i!==L)return{reset:{placement:L}}}return{}}}},Zu=new Set(["left","top"]);async function Wu(t,e){const{placement:n,platform:r,elements:i}=t,s=await(r.isRTL==null?void 0:r.isRTL(i.floating)),o=Oe(n),a=At(n),c=_e(n)==="y",u=Zu.has(o)?-1:1,h=s&&c?-1:1,p=It(e,t);let{mainAxis:f,crossAxis:m,alignmentAxis:_}=typeof p=="number"?{mainAxis:p,crossAxis:0,alignmentAxis:null}:{mainAxis:p.mainAxis||0,crossAxis:p.crossAxis||0,alignmentAxis:p.alignmentAxis};return a&&typeof _=="number"&&(m=a==="end"?_*-1:_),c?{x:m*h,y:f*u}:{x:f*u,y:m*h}}const zu=function(t){return t===void 0&&(t=0),{name:"offset",options:t,async fn(e){var n,r;const{x:i,y:s,placement:o,middlewareData:a}=e,c=await Wu(e,t);return o===((n=a.offset)==null?void 0:n.placement)&&(r=a.arrow)!=null&&r.alignmentOffset?{}:{x:i+c.x,y:s+c.y,data:{...c,placement:o}}}}},Gu=function(t){return t===void 0&&(t={}),{name:"shift",options:t,async fn(e){const{x:n,y:r,placement:i}=e,{mainAxis:s=!0,crossAxis:o=!1,limiter:a={fn:y=>{let{x:w,y:E}=y;return{x:w,y:E}}},...c}=It(t,e),u={x:n,y:r},h=await Ls(e,c),p=_e(Oe(i)),f=ks(p);let m=u[f],_=u[p];if(s){const y=f==="y"?"top":"left",w=f==="y"?"bottom":"right",E=m+h[y],v=m-h[w];m=Wn(E,m,v)}if(o){const y=p==="y"?"top":"left",w=p==="y"?"bottom":"right",E=_+h[y],v=_-h[w];_=Wn(E,_,v)}const g=a.fn({...e,[f]:m,[p]:_});return{...g,data:{x:g.x-n,y:g.y-r,enabled:{[f]:s,[p]:o}}}}}};function xs(t){const e=Q(t);let n=parseFloat(e.width)||0,r=parseFloat(e.height)||0;const i=ee(t),s=i?t.offsetWidth:n,o=i?t.offsetHeight:r,a=Kt(n)!==s||Kt(r)!==o;return a&&(n=s,r=o),{width:n,height:r,$:a}}function Os(t){return H(t)?t:t.contextElement}function Be(t){const e=Os(t);if(!ee(e))return ie(1);const n=e.getBoundingClientRect(),{width:r,height:i,$:s}=xs(e);let o=(s?Kt(n.width):n.width)/r,a=(s?Kt(n.height):n.height)/i;return(!o||!Number.isFinite(o))&&(o=1),(!a||!Number.isFinite(a))&&(a=1),{x:o,y:a}}const Ku=ie(0);function Ms(t){const e=J(t);return!on()||!e.visualViewport?Ku:{x:e.visualViewport.offsetLeft,y:e.visualViewport.offsetTop}}function Yu(t,e,n){return e===void 0&&(e=!1),!n||e&&n!==J(t)?!1:e}function mt(t,e,n,r){e===void 0&&(e=!1),n===void 0&&(n=!1);const i=t.getBoundingClientRect(),s=Os(t);let o=ie(1);e&&(r?H(r)&&(o=Be(r)):o=Be(t));const a=Yu(s,n,r)?Ms(s):ie(0);let c=(i.left+a.x)/o.x,u=(i.top+a.y)/o.y,h=i.width/o.x,p=i.height/o.y;if(s){const f=J(s),m=r&&H(r)?J(r):r;let _=f,g=Zn(_);for(;g&&r&&m!==_;){const y=Be(g),w=g.getBoundingClientRect(),E=Q(g),v=w.left+(g.clientLeft+parseFloat(E.paddingLeft))*y.x,A=w.top+(g.clientTop+parseFloat(E.paddingTop))*y.y;c*=y.x,u*=y.y,h*=y.x,p*=y.y,c+=v,u+=A,_=J(g),g=Zn(_)}}return qt({width:h,height:p,x:c,y:u})}function ar(t,e){const n=an(t).scrollLeft;return e?e.left+n:mt(fe(t)).left+n}function Ds(t,e,n){n===void 0&&(n=!1);const r=t.getBoundingClientRect(),i=r.left+e.scrollLeft-(n?0:ar(t,r)),s=r.top+e.scrollTop;return{x:i,y:s}}function qu(t){let{elements:e,rect:n,offsetParent:r,strategy:i}=t;const s=i==="fixed",o=fe(r),a=e?sn(e.floating):!1;if(r===o||a&&s)return n;let c={scrollLeft:0,scrollTop:0},u=ie(1);const h=ie(0),p=ee(r);if((p||!p&&!s)&&((Je(r)!=="body"||bt(o))&&(c=an(r)),ee(r))){const m=mt(r);u=Be(r),h.x=m.x+r.clientLeft,h.y=m.y+r.clientTop}const f=o&&!p&&!s?Ds(o,c,!0):ie(0);return{width:n.width*u.x,height:n.height*u.y,x:n.x*u.x-c.scrollLeft*u.x+h.x+f.x,y:n.y*u.y-c.scrollTop*u.y+h.y+f.y}}function Ju(t){return Array.from(t.getClientRects())}function Xu(t){const e=fe(t),n=an(t),r=t.ownerDocument.body,i=$e(e.scrollWidth,e.clientWidth,r.scrollWidth,r.clientWidth),s=$e(e.scrollHeight,e.clientHeight,r.scrollHeight,r.clientHeight);let o=-n.scrollLeft+ar(t);const a=-n.scrollTop;return Q(r).direction==="rtl"&&(o+=$e(e.clientWidth,r.clientWidth)-i),{width:i,height:s,x:o,y:a}}function Qu(t,e){const n=J(t),r=fe(t),i=n.visualViewport;let s=r.clientWidth,o=r.clientHeight,a=0,c=0;if(i){s=i.width,o=i.height;const u=on();(!u||u&&e==="fixed")&&(a=i.offsetLeft,c=i.offsetTop)}return{width:s,height:o,x:a,y:c}}const ed=new Set(["absolute","fixed"]);function td(t,e){const n=mt(t,!0,e==="fixed"),r=n.top+t.clientTop,i=n.left+t.clientLeft,s=ee(t)?Be(t):ie(1),o=t.clientWidth*s.x,a=t.clientHeight*s.y,c=i*s.x,u=r*s.y;return{width:o,height:a,x:c,y:u}}function oi(t,e,n){let r;if(e==="viewport")r=Qu(t,n);else if(e==="document")r=Xu(fe(t));else if(H(e))r=td(e,n);else{const i=Ms(t);r={x:e.x-i.x,y:e.y-i.y,width:e.width,height:e.height}}return qt(r)}function Us(t,e){const n=he(t);return n===e||!H(n)||ue(n)?!1:Q(n).position==="fixed"||Us(n,e)}function nd(t,e){const n=e.get(t);if(n)return n;let r=He(t,[],!1).filter(a=>H(a)&&Je(a)!=="body"),i=null;const s=Q(t).position==="fixed";let o=s?he(t):t;for(;H(o)&&!ue(o);){const a=Q(o),c=ir(o);!c&&a.position==="fixed"&&(i=null),(s?!c&&!i:!c&&a.position==="static"&&!!i&&ed.has(i.position)||bt(o)&&!c&&Us(t,o))?r=r.filter(h=>h!==o):i=a,o=he(o)}return e.set(t,r),r}function rd(t){let{element:e,boundary:n,rootBoundary:r,strategy:i}=t;const o=[...n==="clippingAncestors"?sn(e)?[]:nd(e,this._c):[].concat(n),r],a=o[0],c=o.reduce((u,h)=>{const p=oi(e,h,i);return u.top=$e(p.top,u.top),u.right=pt(p.right,u.right),u.bottom=pt(p.bottom,u.bottom),u.left=$e(p.left,u.left),u},oi(e,a,i));return{width:c.right-c.left,height:c.bottom-c.top,x:c.left,y:c.top}}function id(t){const{width:e,height:n}=xs(t);return{width:e,height:n}}function sd(t,e,n){const r=ee(e),i=fe(e),s=n==="fixed",o=mt(t,!0,s,e);let a={scrollLeft:0,scrollTop:0};const c=ie(0);function u(){c.x=ar(i)}if(r||!r&&!s)if((Je(e)!=="body"||bt(i))&&(a=an(e)),r){const m=mt(e,!0,s,e);c.x=m.x+e.clientLeft,c.y=m.y+e.clientTop}else i&&u();s&&!r&&i&&u();const h=i&&!r&&!s?Ds(i,a):ie(0),p=o.left+a.scrollLeft-c.x-h.x,f=o.top+a.scrollTop-c.y-h.y;return{x:p,y:f,width:o.width,height:o.height}}function In(t){return Q(t).position==="static"}function ai(t,e){if(!ee(t)||Q(t).position==="fixed")return null;if(e)return e(t);let n=t.offsetParent;return fe(t)===n&&(n=n.ownerDocument.body),n}function Fs(t,e){const n=J(t);if(sn(t))return n;if(!ee(t)){let i=he(t);for(;i&&!ue(i);){if(H(i)&&!In(i))return i;i=he(i)}return n}let r=ai(t,e);for(;r&&gu(r)&&In(r);)r=ai(r,e);return r&&ue(r)&&In(r)&&!ir(r)?n:r||Eu(t)||n}const od=async function(t){const e=this.getOffsetParent||Fs,n=this.getDimensions,r=await n(t.floating);return{reference:sd(t.reference,await e(t.floating),t.strategy),floating:{x:0,y:0,width:r.width,height:r.height}}};function ad(t){return Q(t).direction==="rtl"}const cd={convertOffsetParentRelativeRectToViewportRelativeRect:qu,getDocumentElement:fe,getClippingRect:rd,getOffsetParent:Fs,getElementRects:od,getClientRects:Ju,getDimensions:id,getScale:Be,isElement:H,isRTL:ad},ld=zu,ud=Gu,dd=Bu,ci=$u,hd=(t,e,n)=>{const r=new Map,i={platform:cd,...n},s={...i.platform,_c:r};return Hu(t,e,{...i,platform:s})};var fd=typeof document<"u",pd=function(){},Mt=fd?l.useLayoutEffect:pd;function Jt(t,e){if(t===e)return!0;if(typeof t!=typeof e)return!1;if(typeof t=="function"&&t.toString()===e.toString())return!0;let n,r,i;if(t&&e&&typeof t=="object"){if(Array.isArray(t)){if(n=t.length,n!==e.length)return!1;for(r=n;r--!==0;)if(!Jt(t[r],e[r]))return!1;return!0}if(i=Object.keys(t),n=i.length,n!==Object.keys(e).length)return!1;for(r=n;r--!==0;)if(!{}.hasOwnProperty.call(e,i[r]))return!1;for(r=n;r--!==0;){const s=i[r];if(!(s==="_owner"&&t.$$typeof)&&!Jt(t[s],e[s]))return!1}return!0}return t!==t&&e!==e}function Vs(t){return typeof window>"u"?1:(t.ownerDocument.defaultView||window).devicePixelRatio||1}function li(t,e){const n=Vs(t);return Math.round(e*n)/n}function An(t){const e=l.useRef(t);return Mt(()=>{e.current=t}),e}function md(t){t===void 0&&(t={});const{placement:e="bottom",strategy:n="absolute",middleware:r=[],platform:i,elements:{reference:s,floating:o}={},transform:a=!0,whileElementsMounted:c,open:u}=t,[h,p]=l.useState({x:0,y:0,strategy:n,placement:e,middlewareData:{},isPositioned:!1}),[f,m]=l.useState(r);Jt(f,r)||m(r);const[_,g]=l.useState(null),[y,w]=l.useState(null),E=l.useCallback(b=>{b!==R.current&&(R.current=b,g(b))},[]),v=l.useCallback(b=>{b!==x.current&&(x.current=b,w(b))},[]),A=s||_,S=o||y,R=l.useRef(null),x=l.useRef(null),V=l.useRef(h),O=c!=null,F=An(c),Z=An(i),B=An(u),$=l.useCallback(()=>{if(!R.current||!x.current)return;const b={placement:e,strategy:n,middleware:f};Z.current&&(b.platform=Z.current),hd(R.current,x.current,b).then(I=>{const k={...I,isPositioned:B.current!==!1};M.current&&!Jt(V.current,k)&&(V.current=k,Ns.flushSync(()=>{p(k)}))})},[f,e,n,Z,B]);Mt(()=>{u===!1&&V.current.isPositioned&&(V.current.isPositioned=!1,p(b=>({...b,isPositioned:!1})))},[u]);const M=l.useRef(!1);Mt(()=>(M.current=!0,()=>{M.current=!1}),[]),Mt(()=>{if(A&&(R.current=A),S&&(x.current=S),A&&S){if(F.current)return F.current(A,S,$);$()}},[A,S,$,F,O]);const C=l.useMemo(()=>({reference:R,floating:x,setReference:E,setFloating:v}),[E,v]),L=l.useMemo(()=>({reference:A,floating:S}),[A,S]),T=l.useMemo(()=>{const b={position:n,left:0,top:0};if(!L.floating)return b;const I=li(L.floating,h.x),k=li(L.floating,h.y);return a?{...b,transform:"translate("+I+"px, "+k+"px)",...Vs(L.floating)>=1.5&&{willChange:"transform"}}:{position:n,left:I,top:k}},[n,a,L.floating,h.x,h.y]);return l.useMemo(()=>({...h,update:$,refs:C,elements:L,floatingStyles:T}),[h,$,C,L,T])}const gd=t=>{function e(n){return{}.hasOwnProperty.call(n,"current")}return{name:"arrow",options:t,fn(n){const{element:r,padding:i}=typeof t=="function"?t(n):t;return r&&e(r)?r.current!=null?ci({element:r.current,padding:i}).fn(n):{}:r?ci({element:r,padding:i}).fn(n):{}}}},vd=(t,e)=>({...ld(t),options:[t,e]}),yd=(t,e)=>({...ud(t),options:[t,e]}),_d=(t,e)=>({...dd(t),options:[t,e]}),wd=(t,e)=>({...gd(t),options:[t,e]}),Ed="data-floating-ui-focusable",ui="active",di="selected",bd={..._i};let hi=!1,Id=0;const fi=()=>"floating-ui-"+Math.random().toString(36).slice(2,6)+Id++;function Ad(){const[t,e]=l.useState(()=>hi?fi():void 0);return ze(()=>{t==null&&e(fi())},[]),l.useEffect(()=>{hi=!0},[]),t}const Td=bd.useId,js=Td||Ad;function Sd(){const t=new Map;return{emit(e,n){var r;(r=t.get(e))==null||r.forEach(i=>i(n))},on(e,n){t.has(e)||t.set(e,new Set),t.get(e).add(n)},off(e,n){var r;(r=t.get(e))==null||r.delete(n)}}}const Cd=l.createContext(null),Rd=l.createContext(null),cr=()=>{var t;return((t=l.useContext(Cd))==null?void 0:t.id)||null},lr=()=>l.useContext(Rd);function Hs(t){return"data-floating-ui-"+t}function X(t){t.current!==-1&&(clearTimeout(t.current),t.current=-1)}const pi=Hs("safe-polygon");function Tn(t,e,n){if(n&&!Kn(n))return 0;if(typeof t=="number")return t;if(typeof t=="function"){const r=t();return typeof r=="number"?r:r==null?void 0:r[e]}return t==null?void 0:t[e]}function Sn(t){return typeof t=="function"?t():t}function kd(t,e){e===void 0&&(e={});const{open:n,onOpenChange:r,dataRef:i,events:s,elements:o}=t,{enabled:a=!0,delay:c=0,handleClose:u=null,mouseOnly:h=!1,restMs:p=0,move:f=!0}=e,m=lr(),_=cr(),g=Rt(u),y=Rt(c),w=Rt(n),E=Rt(p),v=l.useRef(),A=l.useRef(-1),S=l.useRef(),R=l.useRef(-1),x=l.useRef(!0),V=l.useRef(!1),O=l.useRef(()=>{}),F=l.useRef(!1),Z=ne(()=>{var T;const b=(T=i.current.openEvent)==null?void 0:T.type;return(b==null?void 0:b.includes("mouse"))&&b!=="mousedown"});l.useEffect(()=>{if(!a)return;function T(b){let{open:I}=b;I||(X(A),X(R),x.current=!0,F.current=!1)}return s.on("openchange",T),()=>{s.off("openchange",T)}},[a,s]),l.useEffect(()=>{if(!a||!g.current||!n)return;function T(I){Z()&&r(!1,I,"hover")}const b=Fe(o.floating).documentElement;return b.addEventListener("mouseleave",T),()=>{b.removeEventListener("mouseleave",T)}},[o.floating,n,r,a,g,Z]);const B=l.useCallback(function(T,b,I){b===void 0&&(b=!0),I===void 0&&(I="hover");const k=Tn(y.current,"close",v.current);k&&!S.current?(X(A),A.current=window.setTimeout(()=>r(!1,T,I),k)):b&&(X(A),r(!1,T,I))},[y,r]),$=ne(()=>{O.current(),S.current=void 0}),M=ne(()=>{if(V.current){const T=Fe(o.floating).body;T.style.pointerEvents="",T.removeAttribute(pi),V.current=!1}}),C=ne(()=>i.current.openEvent?["click","mousedown"].includes(i.current.openEvent.type):!1);l.useEffect(()=>{if(!a)return;function T(P){if(X(A),x.current=!1,h&&!Kn(v.current)||Sn(E.current)>0&&!Tn(y.current,"open"))return;const z=Tn(y.current,"open",v.current);z?A.current=window.setTimeout(()=>{w.current||r(!0,P,"hover")},z):n||r(!0,P,"hover")}function b(P){if(C()){M();return}O.current();const z=Fe(o.floating);if(X(R),F.current=!1,g.current&&i.current.floatingContext){n||X(A),S.current=g.current({...i.current.floatingContext,tree:m,x:P.clientX,y:P.clientY,onClose(){M(),$(),C()||B(P,!0,"safe-polygon")}});const Xe=S.current;z.addEventListener("mousemove",Xe),O.current=()=>{z.removeEventListener("mousemove",Xe)};return}(v.current==="touch"?!Gn(o.floating,P.relatedTarget):!0)&&B(P)}function I(P){C()||i.current.floatingContext&&(g.current==null||g.current({...i.current.floatingContext,tree:m,x:P.clientX,y:P.clientY,onClose(){M(),$(),C()||B(P)}})(P))}function k(){X(A)}function W(P){C()||B(P,!1)}if(H(o.domReference)){const P=o.domReference,z=o.floating;return n&&P.addEventListener("mouseleave",I),f&&P.addEventListener("mousemove",T,{once:!0}),P.addEventListener("mouseenter",T),P.addEventListener("mouseleave",b),z&&(z.addEventListener("mouseleave",I),z.addEventListener("mouseenter",k),z.addEventListener("mouseleave",W)),()=>{n&&P.removeEventListener("mouseleave",I),f&&P.removeEventListener("mousemove",T),P.removeEventListener("mouseenter",T),P.removeEventListener("mouseleave",b),z&&(z.removeEventListener("mouseleave",I),z.removeEventListener("mouseenter",k),z.removeEventListener("mouseleave",W))}}},[o,a,t,h,f,B,$,M,r,n,w,m,y,g,i,C,E]),ze(()=>{var T;if(a&&n&&(T=g.current)!=null&&(T=T.__options)!=null&&T.blockPointerEvents&&Z()){V.current=!0;const I=o.floating;if(H(o.domReference)&&I){var b;const k=Fe(o.floating).body;k.setAttribute(pi,"");const W=o.domReference,P=m==null||(b=m.nodesRef.current.find(z=>z.id===_))==null||(b=b.context)==null?void 0:b.elements.floating;return P&&(P.style.pointerEvents=""),k.style.pointerEvents="none",W.style.pointerEvents="auto",I.style.pointerEvents="auto",()=>{k.style.pointerEvents="",W.style.pointerEvents="",I.style.pointerEvents=""}}}},[a,n,_,o,m,g,Z]),ze(()=>{n||(v.current=void 0,F.current=!1,$(),M())},[n,$,M]),l.useEffect(()=>()=>{$(),X(A),X(R),M()},[a,o.domReference,$,M]);const L=l.useMemo(()=>{function T(b){v.current=b.pointerType}return{onPointerDown:T,onPointerEnter:T,onMouseMove(b){const{nativeEvent:I}=b;function k(){!x.current&&!w.current&&r(!0,I,"hover")}h&&!Kn(v.current)||n||Sn(E.current)===0||F.current&&b.movementX**2+b.movementY**2<2||(X(R),v.current==="touch"?k():(F.current=!0,R.current=window.setTimeout(k,Sn(E.current))))}}},[h,r,n,w,E]);return l.useMemo(()=>a?{reference:L}:{},[a,L])}const Pd={pointerdown:"onPointerDown",mousedown:"onMouseDown",click:"onClick"},Nd={pointerdown:"onPointerDownCapture",mousedown:"onMouseDownCapture",click:"onClickCapture"},mi=t=>{var e,n;return{escapeKey:typeof t=="boolean"?t:(e=t==null?void 0:t.escapeKey)!=null?e:!1,outsidePress:typeof t=="boolean"?t:(n=t==null?void 0:t.outsidePress)!=null?n:!0}};function Ld(t,e){e===void 0&&(e={});const{open:n,onOpenChange:r,elements:i,dataRef:s}=t,{enabled:o=!0,escapeKey:a=!0,outsidePress:c=!0,outsidePressEvent:u="pointerdown",referencePress:h=!1,referencePressEvent:p="pointerdown",ancestorScroll:f=!1,bubbles:m,capture:_}=e,g=lr(),y=ne(typeof c=="function"?c:()=>!1),w=typeof c=="function"?y:c,E=l.useRef(!1),{escapeKey:v,outsidePress:A}=mi(m),{escapeKey:S,outsidePress:R}=mi(_),x=l.useRef(!1),V=l.useRef(-1),O=ne(C=>{var L;if(!n||!o||!a||C.key!=="Escape"||x.current)return;const T=(L=s.current.floatingContext)==null?void 0:L.nodeId,b=g?Ot(g.nodesRef.current,T):[];if(!v&&(C.stopPropagation(),b.length>0)){let I=!0;if(b.forEach(k=>{var W;if((W=k.context)!=null&&W.open&&!k.context.dataRef.current.__escapeKeyBubbles){I=!1;return}}),!I)return}r(!1,Mu(C)?C.nativeEvent:C,"escape-key")}),F=ne(C=>{var L;const T=()=>{var b;O(C),(b=tt(C))==null||b.removeEventListener("keydown",T)};(L=tt(C))==null||L.addEventListener("keydown",T)}),Z=ne(C=>{var L;const T=s.current.insideReactTree;s.current.insideReactTree=!1;const b=E.current;if(E.current=!1,u==="click"&&b||T||typeof w=="function"&&!w(C))return;const I=tt(C),k="["+Hs("inert")+"]",W=Fe(i.floating).querySelectorAll(k);let P=H(I)?I:null;for(;P&&!ue(P);){const q=he(P);if(ue(q)||!H(q))break;P=q}if(W.length&&H(I)&&!xu(I)&&!Gn(I,i.floating)&&Array.from(W).every(q=>!Gn(P,q)))return;if(ee(I)&&M){const q=ue(I),ae=Q(I),Qe=/auto|scroll/,Bs=q||Qe.test(ae.overflowX),Zs=q||Qe.test(ae.overflowY),Ws=Bs&&I.clientWidth>0&&I.scrollWidth>I.clientWidth,zs=Zs&&I.clientHeight>0&&I.scrollHeight>I.clientHeight,Gs=ae.direction==="rtl",Ks=zs&&(Gs?C.offsetX<=I.offsetWidth-I.clientWidth:C.offsetX>I.clientWidth),Ys=Ws&&C.offsetY>I.clientHeight;if(Ks||Ys)return}const z=(L=s.current.floatingContext)==null?void 0:L.nodeId,ur=g&&Ot(g.nodesRef.current,z).some(q=>{var ae;return bn(C,(ae=q.context)==null?void 0:ae.elements.floating)});if(bn(C,i.floating)||bn(C,i.domReference)||ur)return;const Xe=g?Ot(g.nodesRef.current,z):[];if(Xe.length>0){let q=!0;if(Xe.forEach(ae=>{var Qe;if((Qe=ae.context)!=null&&Qe.open&&!ae.context.dataRef.current.__outsidePressBubbles){q=!1;return}}),!q)return}r(!1,C,"outside-press")}),B=ne(C=>{var L;const T=()=>{var b;Z(C),(b=tt(C))==null||b.removeEventListener(u,T)};(L=tt(C))==null||L.addEventListener(u,T)});l.useEffect(()=>{if(!n||!o)return;s.current.__escapeKeyBubbles=v,s.current.__outsidePressBubbles=A;let C=-1;function L(W){r(!1,W,"ancestor-scroll")}function T(){window.clearTimeout(C),x.current=!0}function b(){C=window.setTimeout(()=>{x.current=!1},on()?5:0)}const I=Fe(i.floating);a&&(I.addEventListener("keydown",S?F:O,S),I.addEventListener("compositionstart",T),I.addEventListener("compositionend",b)),w&&I.addEventListener(u,R?B:Z,R);let k=[];return f&&(H(i.domReference)&&(k=He(i.domReference)),H(i.floating)&&(k=k.concat(He(i.floating))),!H(i.reference)&&i.reference&&i.reference.contextElement&&(k=k.concat(He(i.reference.contextElement)))),k=k.filter(W=>{var P;return W!==((P=I.defaultView)==null?void 0:P.visualViewport)}),k.forEach(W=>{W.addEventListener("scroll",L,{passive:!0})}),()=>{a&&(I.removeEventListener("keydown",S?F:O,S),I.removeEventListener("compositionstart",T),I.removeEventListener("compositionend",b)),w&&I.removeEventListener(u,R?B:Z,R),k.forEach(W=>{W.removeEventListener("scroll",L)}),window.clearTimeout(C)}},[s,i,a,w,u,n,r,f,o,v,A,O,S,F,Z,R,B]),l.useEffect(()=>{s.current.insideReactTree=!1},[s,w,u]);const $=l.useMemo(()=>({onKeyDown:O,...h&&{[Pd[p]]:C=>{r(!1,C.nativeEvent,"reference-press")},...p!=="click"&&{onClick(C){r(!1,C.nativeEvent,"reference-press")}}}}),[O,r,h,p]),M=l.useMemo(()=>({onKeyDown:O,onMouseDown(){E.current=!0},onMouseUp(){E.current=!0},[Nd[u]]:()=>{s.current.insideReactTree=!0},onBlurCapture(){g||(X(V),s.current.insideReactTree=!0,V.current=window.setTimeout(()=>{s.current.insideReactTree=!1}))}}),[O,u,s,g]);return l.useMemo(()=>o?{reference:$,floating:M}:{},[o,$,M])}function xd(t){const{open:e=!1,onOpenChange:n,elements:r}=t,i=js(),s=l.useRef({}),[o]=l.useState(()=>Sd()),a=cr()!=null,[c,u]=l.useState(r.reference),h=ne((m,_,g)=>{s.current.openEvent=m?_:void 0,o.emit("openchange",{open:m,event:_,reason:g,nested:a}),n==null||n(m,_,g)}),p=l.useMemo(()=>({setPositionReference:u}),[]),f=l.useMemo(()=>({reference:c||r.reference||null,floating:r.floating||null,domReference:r.reference}),[c,r.reference,r.floating]);return l.useMemo(()=>({dataRef:s,open:e,onOpenChange:h,elements:f,events:o,floatingId:i,refs:p}),[e,h,f,o,i,p])}function Od(t){t===void 0&&(t={});const{nodeId:e}=t,n=xd({...t,elements:{reference:null,floating:null,...t.elements}}),r=t.rootContext||n,i=r.elements,[s,o]=l.useState(null),[a,c]=l.useState(null),h=(i==null?void 0:i.domReference)||s,p=l.useRef(null),f=lr();ze(()=>{h&&(p.current=h)},[h]);const m=md({...t,elements:{...i,...a&&{reference:a}}}),_=l.useCallback(v=>{const A=H(v)?{getBoundingClientRect:()=>v.getBoundingClientRect(),getClientRects:()=>v.getClientRects(),contextElement:v}:v;c(A),m.refs.setReference(A)},[m.refs]),g=l.useCallback(v=>{(H(v)||v===null)&&(p.current=v,o(v)),(H(m.refs.reference.current)||m.refs.reference.current===null||v!==null&&!H(v))&&m.refs.setReference(v)},[m.refs]),y=l.useMemo(()=>({...m.refs,setReference:g,setPositionReference:_,domReference:p}),[m.refs,g,_]),w=l.useMemo(()=>({...m.elements,domReference:h}),[m.elements,h]),E=l.useMemo(()=>({...m,...r,refs:y,elements:w,nodeId:e}),[m,y,w,e,r]);return ze(()=>{r.dataRef.current.floatingContext=E;const v=f==null?void 0:f.nodesRef.current.find(A=>A.id===e);v&&(v.context=E)}),l.useMemo(()=>({...m,context:E,refs:y,elements:w}),[m,y,w,E])}function Cn(t,e,n){const r=new Map,i=n==="item";let s=t;if(i&&t){const{[ui]:o,[di]:a,...c}=t;s=c}return{...n==="floating"&&{tabIndex:-1,[Ed]:""},...s,...e.map(o=>{const a=o?o[n]:null;return typeof a=="function"?t?a(t):null:a}).concat(t).reduce((o,a)=>(a&&Object.entries(a).forEach(c=>{let[u,h]=c;if(!(i&&[ui,di].includes(u)))if(u.indexOf("on")===0){if(r.has(u)||r.set(u,[]),typeof h=="function"){var p;(p=r.get(u))==null||p.push(h),o[u]=function(){for(var f,m=arguments.length,_=new Array(m),g=0;g<m;g++)_[g]=arguments[g];return(f=r.get(u))==null?void 0:f.map(y=>y(..._)).find(y=>y!==void 0)}}}else o[u]=h}),o),{})}}function Md(t){t===void 0&&(t=[]);const e=t.map(a=>a==null?void 0:a.reference),n=t.map(a=>a==null?void 0:a.floating),r=t.map(a=>a==null?void 0:a.item),i=l.useCallback(a=>Cn(a,t,"reference"),e),s=l.useCallback(a=>Cn(a,t,"floating"),n),o=l.useCallback(a=>Cn(a,t,"item"),r);return l.useMemo(()=>({getReferenceProps:i,getFloatingProps:s,getItemProps:o}),[i,s,o])}const Dd=new Map([["select","listbox"],["combobox","listbox"],["label",!1]]);function Ud(t,e){var n,r;e===void 0&&(e={});const{open:i,elements:s,floatingId:o}=t,{enabled:a=!0,role:c="dialog"}=e,u=js(),h=((n=s.domReference)==null?void 0:n.id)||u,p=l.useMemo(()=>{var E;return((E=Ou(s.floating))==null?void 0:E.id)||o},[s.floating,o]),f=(r=Dd.get(c))!=null?r:c,_=cr()!=null,g=l.useMemo(()=>f==="tooltip"||c==="label"?{["aria-"+(c==="label"?"labelledby":"describedby")]:i?p:void 0}:{"aria-expanded":i?"true":"false","aria-haspopup":f==="alertdialog"?"dialog":f,"aria-controls":i?p:void 0,...f==="listbox"&&{role:"combobox"},...f==="menu"&&{id:h},...f==="menu"&&_&&{role:"menuitem"},...c==="select"&&{"aria-autocomplete":"none"},...c==="combobox"&&{"aria-autocomplete":"list"}},[f,p,_,i,h,c]),y=l.useMemo(()=>{const E={id:p,...f&&{role:f}};return f==="tooltip"||c==="label"?E:{...E,...f==="menu"&&{"aria-labelledby":h}}},[f,p,h,c]),w=l.useCallback(E=>{let{active:v,selected:A}=E;const S={role:"option",...v&&{id:p+"-fui-option"}};switch(c){case"select":return{...S,"aria-selected":v&&A};case"combobox":return{...S,"aria-selected":A}}return{}},[p,c]);return l.useMemo(()=>a?{reference:g,floating:y,item:w}:{},[a,g,y,w])}const Fd=({text:t,children:e,className:n,placement:r="top",delay:i=500,styles:s})=>{var E,v;const[o,a]=lt.useState(!1),c=lt.useRef(null),{refs:u,floatingStyles:h,context:p,middlewareData:f}=Od({placement:r,open:o,onOpenChange:a,middleware:[vd(8),yd(),_d(),wd({element:c})]}),m=kd(p,{delay:{open:i,close:0}}),_=Ld(p),g=Ud(p,{role:"tooltip"}),{getReferenceProps:y,getFloatingProps:w}=Md([m,_,g]);return d.jsxs(d.Fragment,{children:[d.jsx("span",{ref:u.setReference,...y(),className:n,children:e}),o&&Ns.createPortal(d.jsxs("div",{ref:u.setFloating,style:{...h,zIndex:1e3,maxWidth:"300px",backgroundColor:"#333",color:"#fff",padding:"8px",borderRadius:"6px",fontSize:"11px",fontWeight:"normal",lineHeight:"1.4",whiteSpace:"pre-line",wordWrap:"break-word",...s},...w(),children:[t,d.jsx("div",{ref:c,style:{position:"absolute",width:"12px",height:"12px",backgroundColor:"#333",transform:"rotate(45deg)",zIndex:-1,left:((E=f.arrow)==null?void 0:E.x)!=null?`${f.arrow.x}px`:"",top:((v=f.arrow)==null?void 0:v.y)!=null?`${f.arrow.y}px`:""}})]}),document.body)]})},Rn=({title:t})=>{const{goBack:e,canGoBack:n}=tr();return d.jsxs("header",{className:"user-panel-header subscription-header",children:[n&&d.jsx("button",{className:"back-button",onClick:e,children:d.jsx(as,{size:20})}),d.jsx("span",{children:t})]})},gi=({planName:t})=>d.jsx("div",{className:"subscription-plan",children:typeof t=="string"?d.jsx("span",{className:"plan-name",children:t}):t}),kn=({children:t})=>d.jsx("div",{className:"popup-card",children:t}),vi=({children:t})=>d.jsx("div",{className:"usage-dashboard",children:t}),yi=({leftContent:t,rightContent:e,showTooltip:n=!1})=>d.jsxs("div",{className:"usage-dashboard-header",children:[d.jsxs("div",{className:"usage-text-container",children:[t,n&&d.jsx(Fd,{text:"How many event proposals have been created by Yellow. Once you reach your limit, incoming emails won't be processed anymore.",placement:"top",children:d.jsx(us,{size:14,className:"usage-info-icon"})})]}),e]}),Vd=({percentage:t})=>d.jsx("div",{className:"usage-bar",children:d.jsx("div",{className:"usage-fill",style:{width:`${Math.min(t,100)}%`}})}),jd=({dueDate:t,isFree:e})=>d.jsx("div",{className:"due-date",children:d.jsxs("span",{children:[e?"Free trial ends":"Resets",": ",new Date(t).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})]})}),Hd=({isPro:t,isActive:e,onUpgrade:n,onManage:r})=>e&&t?d.jsx("button",{className:"btn btn-secondary btn-full",onClick:r,children:"Manage Subscription"}):d.jsx("button",{className:"btn btn-primary btn-full",onClick:n,children:"Upgrade Now"}),$d=()=>{const{subscription:t,isLoading:e,error:n,fetchSubscription:r,hasLimit:i,isPro:s,isFree:o,isActive:a,isOverLimit:c,isCloseToLimit:u,isFreeTrialExpiringSoon:h,usagePercentage:p}=Ss();l.useEffect(()=>{!e&&!t&&r()},[r,e,t]);const f=async()=>{try{const y=await hu();window.open(y.url,"_blank")}catch(y){console.error("Failed to get pricing table URL:",y)}},m=async()=>{try{const y=await fu();window.open(y.url,"_blank")}catch(y){console.error("Failed to get portal URL:",y)}};if(e)return d.jsxs(d.Fragment,{children:[d.jsx(Rn,{title:"Subscription"}),d.jsx(gi,{planName:d.jsx(Ue,{style:{minHeight:"17px",border:"none",width:"120px"}})}),d.jsxs(kn,{children:[d.jsxs(vi,{children:[d.jsx(yi,{leftContent:d.jsx(Ue,{style:{minHeight:"17px",border:"none",width:"150px"}}),rightContent:d.jsx(Ue,{style:{minHeight:"17px",border:"none",width:"60px"}})}),d.jsx("div",{className:"usage-bar"}),d.jsx("div",{className:"due-date",children:d.jsx(Ue,{style:{minHeight:"14.5px",border:"none",width:"90px"}})})]}),d.jsx("button",{className:"btn btn-secondary btn-full",disabled:!0,children:"Manage Subscription"})]})]});if(n)return d.jsxs(d.Fragment,{children:[d.jsx(Rn,{title:"Subscription"}),d.jsxs(kn,{children:[d.jsxs("div",{className:"popup-error-message",style:{marginBottom:"30px"},children:[d.jsx(hs,{size:16}),d.jsx("span",{children:"Failed to load subscription status"})]}),d.jsx("button",{className:"btn btn-secondary btn-full",onClick:m,children:"Manage Subscription"})]})]});const g=(()=>{if(!a)return"You do not have an active subscription and emails are not being processed. Please upgrade to get 500 event proposals per month.";if(o)return c?"You have reached the free limit and emails are being missed. Upgrade now to get 500 event proposals per month.":u?"You are close to the free limit. Upgrade now to get 500 event proposals per month and avoid any emails being missed.":h?"Your free trial is close to expiring. Upgrade now to get 500 event proposals per month and avoid any emails being missed.":"Upgrade now to get 500 event proposals per month.";if(s){if(c)return"You have reached the usage limit and Yellow has stopped processing your emails for event proposals until the next billing period.";if(u)return"You are close to the usage limit. Once reached, Yellow will stop processing your emails for event proposals until the next billing period."}return""})();return d.jsxs(d.Fragment,{children:[d.jsx(Rn,{title:s?"Subscription":"Upgrade to Yellow Pro"}),d.jsx(gi,{planName:s?"Yellow Pro":"Free Trial"}),d.jsxs(kn,{children:[t&&d.jsxs(vi,{children:[a&&d.jsxs(d.Fragment,{children:[d.jsx(yi,{leftContent:d.jsx("span",{className:"usage-text",children:o?"Free usage":"Usage this billing period"}),rightContent:d.jsx("span",{className:"usage-text",children:i?`${t.action_item_count} / ${t.plan_limit}`:`${t.action_item_count}`}),showTooltip:!0}),d.jsx(Vd,{percentage:p}),t.due_to&&d.jsx(jd,{dueDate:t.due_to,isFree:o})]}),g&&d.jsx("div",{className:"usage-dashboard-info-text",children:g})]}),d.jsx(Hd,{isPro:s,isActive:a,onUpgrade:f,onManage:m})]})]})},Bd=()=>{const{user:t}=We(),{currentView:e,navigateTo:n,initialize:r,isInitialized:i}=tr();switch(l.useEffect(()=>{if(t!==void 0){if(!i){r(),n(t?"user-panel":"auth");return}if(t===null&&e!=="auth"){n("auth");return}t&&e==="auth"&&n("user-panel")}},[t,i,r,n,e]),e){case"auth":return d.jsx(zr,{});case"user-panel":return d.jsx(fs,{});case"subscription":return d.jsx($d,{});default:return d.jsx(zr,{})}},$s=({id:t})=>d.jsxs("filter",{id:t,filterUnits:"userSpaceOnUse",x:"-100",y:"-100",width:"1000",height:"1000",children:[d.jsx("feGaussianBlur",{in:"SourceGraphic",stdDeviation:"70",result:"blur"}),d.jsx("feColorMatrix",{in:"blur",type:"matrix",values:"1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 20 -10",result:"goo"}),d.jsx("feBlend",{in:"SourceGraphic",in2:"goo",result:"blended"}),d.jsx("feGaussianBlur",{in:"blended",stdDeviation:"35"})]}),Zd=()=>d.jsxs("svg",{className:"w-full h-full",viewBox:"0 0 800 800",xmlns:"http://www.w3.org/2000/svg",children:[d.jsxs("defs",{children:[d.jsxs("radialGradient",{id:"lava-gradient",cx:"0",cy:"1",r:"1",fx:"0.3",fy:"1",children:[d.jsx("stop",{offset:"30%",stopColor:"#FAC7AC",stopOpacity:"0.8"}),d.jsx("stop",{offset:"100%",stopColor:"#73CDF3",stopOpacity:"0.3"})]}),d.jsx($s,{id:"goo"})]}),d.jsx("mask",{id:"blob-mask1",children:d.jsxs("g",{filter:"url(#goo)",fill:"#ffffff",children:[d.jsx("circle",{className:"blob b1",cx:"300",cy:"320",r:"140"}),d.jsx("circle",{className:"blob b2",cx:"550",cy:"300",r:"130"}),d.jsx("circle",{className:"blob b3",cx:"500",cy:"550",r:"170"})]})}),d.jsx("rect",{x:"0",y:"0",width:"800",height:"800",fill:"url(#lava-gradient)",mask:"url(#blob-mask1)"}),d.jsx("style",{children:`
        .blob {
          transform-origin: 50% 50%;
          animation-duration: 8s;
          animation-iteration-count: infinite;
          animation-timing-function: ease-in-out;
        }
        .b1 { animation-name: move-b1; }
        .b2 { animation-name: move-b2; animation-delay: -3s; }
        .b3 { animation-name: move-b3; animation-delay: -1.5s; }

        @keyframes move-b1 {
          0%, 100% { transform: translate(0px, 0px) scale(1.05); }
          50%      { transform: translate(-80px, -50px) scale(0.9); }
        }
        @keyframes move-b2 {
          0%, 100% { transform: translate(0px, 0px) scale(1); }
          50%      { transform: translate(90px, -40px) scale(1.15); }
        }
        @keyframes move-b3 {
          0%, 100% { transform: translate(0px, 0px) scale(1); }
          50%      { transform: translate(-100px, 70px) scale(0.85); }
        }
    `})]}),Wd=()=>d.jsxs("svg",{className:"w-full h-full",viewBox:"0 0 800 800",xmlns:"http://www.w3.org/2000/svg",children:[d.jsxs("defs",{children:[d.jsxs("linearGradient",{id:"yellow-purple-gradient",x1:"0",y1:"0",x2:"0",y2:"1",children:[d.jsx("stop",{offset:"0%",stopColor:"#FFE600",stopOpacity:"0.4"}),d.jsx("stop",{offset:"100%",stopColor:"#5442FB",stopOpacity:"0.3"})]}),d.jsx($s,{id:"goo-2"})]}),d.jsx("mask",{id:"blob-mask2",children:d.jsxs("g",{filter:"url(#goo-2)",fill:"#ffffff",children:[d.jsx("circle",{className:"blob c1",cx:"380",cy:"370",r:"180"}),d.jsx("circle",{className:"blob c2",cx:"300",cy:"480",r:"190"})]})}),d.jsx("rect",{width:"800",height:"800",fill:"url(#yellow-purple-gradient)",mask:"url(#blob-mask2)"}),d.jsx("style",{children:`
        .blob {
            transform-origin: 50% 50%;
            animation-duration: 11s;
            animation-iteration-count: infinite;
            animation-timing-function: ease-in-out;
        }
        .c1 {
            animation-name: c1Move;
        }
        .c2 {
            animation-name: c2Move;
            animation-delay: -5.5s;
        }

        @keyframes c1Move {
            0%, 100% { transform: translate(0px, 0px) scale(1.); }
            50%      { transform: translate(-50px, -50px) scale(0.9); }
        }
        @keyframes c2Move {
            0%, 100% { transform: translate(0px, 0px) scale(1.); }
            50%      { transform: translate(90px, 30px) scale(1.1); }
        }
        `})]}),zd="0.3.0",Gd=({children:t})=>d.jsxs(d.Fragment,{children:[d.jsxs("div",{className:"popup-container",children:[d.jsx("div",{className:"lava-lamp-left",children:d.jsx(Wd,{})}),d.jsx("div",{className:"lava-lamp-right",children:d.jsx(Zd,{})}),d.jsx(l.Suspense,{fallback:d.jsx(Ue,{children:"Loading authentication..."}),children:t})]}),d.jsxs("div",{className:"version-text",children:["v",zd,""]})]}),Kd=Js.createRoot(document.getElementById("root"));Kd.render(d.jsx(lt.StrictMode,{children:d.jsx(Gd,{children:d.jsx(Bd,{})})}));
